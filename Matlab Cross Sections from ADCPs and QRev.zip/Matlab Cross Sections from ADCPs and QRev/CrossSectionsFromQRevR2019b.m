%% Generate Cross Sections From ADCP Data From Moving Boat Cross Sections Processed in QRev
%Hamish Biggs, NIWA, From: Drone Flow Project Software Toolbox, Updated 2022_05_11

%{
Exporting cross sections is easy to do from SxS through 
SxS Pro -> File -> CSV Summary File -> Export.

However, from Winriver2 it is messy as there is not good info on bank locations, where the river is in space, whether right to left, edge effects etc...
Also just referenced to a displacement, not to an absolute location. Also uncertainty whether to use GGA, VTG or BT.
There are also issues with use of TRDI and Sontek instruments.
 
QRev provides an excellent intermediary for processing data from both manufacturers.

However, there are not any good ways (that I could find) for exporting moving boat cross sections.
The main objectives are:
 - Projecting cross sections (rather than a meandering distance traveled path).
 - Avoiding issues with loops in paths.
 - Being invariant to the direction travelled (i.e. LB to RB vs RB to LB).
 - Accounting for bank shapes (i.e. Triangular vs Square) and distances to the banks.
 - Being able to visualise ADCP paths and selecting the best reference (i.e. BT vs GGA vs VTG).
 - Being able to scale cross sections to a mean cross section width.
 - Being able to scale cross sections to a user defined cross section width. This is particularly useful if cross sections are no orthogonal to the river flow direction (i.e. slightly diagonal cross sections) but river width is accurately measured (i.e. from remote sensing data).
 - Being able to average cross sections to obtain a more accurate mean cross section.
 - Being able to input a water level manually for relating cross sections to real world elevation coordinates.
 - Being able to easily export cross section data in a format that is suitable for use in software such as HydroSTIV.

This script addresses all of the objectives above. Basically, the overall principal is projection of the dead reckoning East and North displacements onto a cross section line between the first and last point in the cross section (transect).
Data is then orientated LB->RB and details of the bank shapes and offsets are added. Which reference to use can then be selected, along with scaling of the cross section data to a mean cross section width, or user defined cross section width.

Notes:
Run this script in Matlab. Or run the compiled .exe version of this (needs Matlab runtime library R2019b (9.7) installed https://www.mathworks.com/products/compiler/matlab-runtime.html).
This could be incorporated into QREV, or wrapped in a GUI in the future if needed.

This script was revised on 2022_05_11 to account for cases where ADCPs do not have GPS (i.e. bottom tracking only). Previously a separate script was provided for that case.

This script was revised on 2022_05_17 to only process 'checked transects' QRevData.meas_struct.transects(i).checked;  
%}

%% Code to build as standalone
if(~isdeployed())
    if(~isdir([pwd,'\','Compiled Code\']))
        mkdir([pwd,'\','Compiled Code\']);
    end
    mcc('-m','CrossSectionsFromQRevR2019b.m','-d',[pwd,'\','Compiled Code\']);
end
%Done

%% Select the file to process
clear all;
close all;

disp('Running CrossSectionsFromQRev.m');
[QRevFileName,inputPathname]=uigetfile({'*.*','All Files (*.*)'},'Select the QRev .mat file which contains the transects to process','MultiSelect','off',getPreviousDir());
writeCurrentDir(inputPathname);%Remember last used directory for next time script is run
%Done

%% Get the output directory
outputPathname=uigetdir(inputPathname,'Select or create folder for output cross sections');
outputPathname=[outputPathname,'\'];%Was missing slash at end.
%Done

%% Loading from the QREV data
QRevData=load([inputPathname,QRevFileName]);
%Remove transects that are not checked.
checkedTransects=logical([QRevData.meas_struct.transects.checked]);
QRevData.meas_struct.transects=QRevData.meas_struct.transects(checkedTransects);
%Done

%% Check if boat data contains GPS, or only bottom track.
if(isempty(QRevData.meas_struct.transects(1).gps))
    gpsBool=false;
    disp('GPS data not available for gauging, using bottom track only');
else
    gpsBool=true;
end
%Done

%% Process the QRev data
numTransects=length(QRevData.meas_struct.transects);
for i=1:numTransects%In WinRiver2 transect numbers start from 0. So these correspond to WinRiver2 transect ID's plus 1.
    %Extract ensDuration_sec and clean of NaN values.
    QRevData.('XS')(i,1).('ensDuration_sec_Cleaned')=[0,QRevData.meas_struct.transects(i).dateTime.ensDuration_sec(2:end)]';
    QRevData.XS(i).ensDuration_sec_Cleaned=repNaN_ensDuration(QRevData.XS(i).ensDuration_sec_Cleaned);%Loops through and redistributes time from subsequent elapsed time bin.
    %Done    
    
    %Clean any remaining NaN data. Use linear interpolation from neighbouring good values. [Most are already removed or replaced in QRev]
    %Possibly repNaN_Mean() may be better for velocities. I.e. if there are chunks of bad values, then the neighbouring 'good' ones may also be mildly contaminated.
    %Use linear for Depth as only a few missing values and needs to be interpolated from neighbours
    if(gpsBool)
        QRevData.('XS')(i,1).('VTG_East_Velocity_Cleaned_mps')=repNaN_Mean(QRevData.meas_struct.transects(i).boatVel.vtgVel.uProcessed_mps');
        QRevData.('XS')(i,1).('VTG_North_Velocity_Cleaned_mps')=repNaN_Mean(QRevData.meas_struct.transects(i).boatVel.vtgVel.vProcessed_mps');
        QRevData.('XS')(i,1).('GGA_East_Velocity_Cleaned_mps')=repNaN_Mean(QRevData.meas_struct.transects(i).boatVel.ggaVel.uProcessed_mps');
        QRevData.('XS')(i,1).('GGA_North_Velocity_Cleaned_mps')=repNaN_Mean(QRevData.meas_struct.transects(i).boatVel.ggaVel.vProcessed_mps');
    end
    QRevData.('XS')(i,1).('BT_East_Velocity_Cleaned_mps')=repNaN_Mean(QRevData.meas_struct.transects(i).boatVel.btVel.uProcessed_mps');
    QRevData.('XS')(i,1).('BT_North_Velocity_Cleaned_mps')=repNaN_Mean(QRevData.meas_struct.transects(i).boatVel.btVel.vProcessed_mps');
    QRevData.('XS')(i,1).('Depth_Cleaned_m')=repNaN_Linear(QRevData.meas_struct.transects(i).depths.vbDepths.depthProcessed_m');
    %Skip inclusion of GGA Lat Long. Ok to do for New Zealand, but other coordinate systems globally would be difficult (i.e. conversion to local Easting and Northing from WGS84).
    %Done
    
    %Convert boat velocities to displacements with ensDuration_sec. Remove any points that are a NaN for boat velocity or depth. (Not many of these as generally covered by Dave's filtering in QRev).
    if(gpsBool)
        QRevData.('XS')(i,1).('VTG_East_Displacement_m')=[0;cumsum(QRevData.XS(i).VTG_East_Velocity_Cleaned_mps.*QRevData.XS(i).ensDuration_sec_Cleaned)];
        QRevData.('XS')(i,1).('VTG_North_Displacement_m')=[0;cumsum(QRevData.XS(i).VTG_North_Velocity_Cleaned_mps.*QRevData.XS(i).ensDuration_sec_Cleaned)];
        QRevData.('XS')(i,1).('GGA_East_Displacement_m')=[0;cumsum(QRevData.XS(i).GGA_East_Velocity_Cleaned_mps.*QRevData.XS(i).ensDuration_sec_Cleaned)];
        QRevData.('XS')(i,1).('GGA_North_Displacement_m')=[0;cumsum(QRevData.XS(i).GGA_North_Velocity_Cleaned_mps.*QRevData.XS(i).ensDuration_sec_Cleaned)];
    end
    QRevData.('XS')(i,1).('BT_East_Displacement_m')=[0;cumsum(QRevData.XS(i).BT_East_Velocity_Cleaned_mps.*QRevData.XS(i).ensDuration_sec_Cleaned)];
    QRevData.('XS')(i,1).('BT_North_Displacement_m')=[0;cumsum(QRevData.XS(i).BT_North_Velocity_Cleaned_mps.*QRevData.XS(i).ensDuration_sec_Cleaned)];
    %Done
    
    %Calculate measurement span (where data recorded) and XS unit vector
    if(gpsBool)
        QRevData.('XS')(i,1).('VTG_MeasurementSpan_m')=((QRevData.XS(i).VTG_North_Displacement_m(end)-QRevData.XS(i).VTG_North_Displacement_m(1))^2+(QRevData.XS(i).VTG_East_Displacement_m(end)-QRevData.XS(i).VTG_East_Displacement_m(1))^2)^0.5;
        QRevData.('XS')(i,1).('VTG_UnitVector_E_N')=[QRevData.XS(i).VTG_East_Displacement_m(end)-QRevData.XS(i).VTG_East_Displacement_m(1);QRevData.XS(i).VTG_North_Displacement_m(end)-QRevData.XS(i).VTG_North_Displacement_m(1)]/QRevData.XS(i).VTG_MeasurementSpan_m;
        QRevData.('XS')(i,1).('GGA_MeasurementSpan_m')=((QRevData.XS(i).GGA_North_Displacement_m(end)-QRevData.XS(i).GGA_North_Displacement_m(1))^2+(QRevData.XS(i).GGA_East_Displacement_m(end)-QRevData.XS(i).GGA_East_Displacement_m(1))^2)^0.5;
        QRevData.('XS')(i,1).('GGA_UnitVector_E_N')=[QRevData.XS(i).GGA_East_Displacement_m(end)-QRevData.XS(i).GGA_East_Displacement_m(1);QRevData.XS(i).GGA_North_Displacement_m(end)-QRevData.XS(i).GGA_North_Displacement_m(1)]/QRevData.XS(i).GGA_MeasurementSpan_m;
    end
    QRevData.('XS')(i,1).('BT_MeasurementSpan_m')=((QRevData.XS(i).BT_North_Displacement_m(end)-QRevData.XS(i).BT_North_Displacement_m(1))^2+(QRevData.XS(i).BT_East_Displacement_m(end)-QRevData.XS(i).BT_East_Displacement_m(1))^2)^0.5;
    QRevData.('XS')(i,1).('BT_UnitVector_E_N')=[QRevData.XS(i).BT_East_Displacement_m(end)-QRevData.XS(i).BT_East_Displacement_m(1);QRevData.XS(i).BT_North_Displacement_m(end)-QRevData.XS(i).BT_North_Displacement_m(1)]/QRevData.XS(i).BT_MeasurementSpan_m;
    %Done
    
    %Calculate flow mean velocity and unit vector
    QRevData.('XS')(i,1).('MeanVelocity_E')=nanmean(QRevData.meas_struct.transects(i).wVel.uProcessed_mps(:));
    QRevData.('XS')(i,1).('MeanVelocity_N')=nanmean(QRevData.meas_struct.transects(i).wVel.vProcessed_mps(:));
    QRevData.('XS')(i,1).('MeanVelocity_UnitVector_E_N')=[QRevData.XS(i).MeanVelocity_E;QRevData.XS(i).MeanVelocity_N]/(QRevData.XS(i).MeanVelocity_N^2+QRevData.XS(i).MeanVelocity_E^2)^0.5;
    %Done
    
    %Compute angle from cross section unit vector to mean velocity unit vector (need signed output angle)
    if(gpsBool)
        QRevData.('XS')(i,1).('AngleVTGUnitVectorToMeanVelocityUnitVector_degrees')=vecangle360(QRevData.XS(i).VTG_UnitVector_E_N,QRevData.XS(i).MeanVelocity_UnitVector_E_N);
        QRevData.('XS')(i,1).('AngleGGAUnitVectorToMeanVelocityUnitVector_degrees')=vecangle360(QRevData.XS(i).GGA_UnitVector_E_N,QRevData.XS(i).MeanVelocity_UnitVector_E_N);
    end
    QRevData.('XS')(i,1).('AngleBTUnitVectorToMeanVelocityUnitVector_degrees')=vecangle360(QRevData.XS(i).BT_UnitVector_E_N,QRevData.XS(i).MeanVelocity_UnitVector_E_N);
    if(gpsBool)
        QRevData.('XS')(i,1).('AngleSignMode_VTG_GGA_BT')=mode([sign(QRevData.XS(i).AngleVTGUnitVectorToMeanVelocityUnitVector_degrees);sign(QRevData.XS(i).AngleGGAUnitVectorToMeanVelocityUnitVector_degrees);sign(QRevData.XS(i).AngleBTUnitVectorToMeanVelocityUnitVector_degrees)]);    
    else
        QRevData.('XS')(i,1).('AngleSignMode_VTG_GGA_BT')=sign(QRevData.XS(i).AngleBTUnitVectorToMeanVelocityUnitVector_degrees);%BT Only
    end
    if(QRevData.XS(i).AngleSignMode_VTG_GGA_BT>0)
        QRevData.XS(i).('XS_Direction')='LBToRB';
    elseif(QRevData.XS(i).AngleSignMode_VTG_GGA_BT<0)
        QRevData.XS(i).('XS_Direction')='RBToLB';
    else
        error(['Error the cross section unit vector and the flow unit vector are parellel, or NaN. Likely there are serious data problems for cross section ',QRevData.meas_struct.transects(i).fileName,'. Please remove this cross section by saving the QRev .mat file without this cross section ticked.']);
    end
    %Done
    
    if(gpsBool)
        %VTG Next project the measurement coordinates onto the cross section line. https://en.wikipedia.org/wiki/Vector_projection  a1=(a dot b_hat)b_hat   where a1 is the vector projection of a onto b_hat
        nPoints=length(QRevData.XS(i).Depth_Cleaned_m);
        QRevData.('XS')(i,1).('VTG_East_Displacement_Projected_m')=zeros(nPoints,1);
        QRevData.('XS')(i,1).('VTG_North_Displacement_Projected_m')=zeros(nPoints,1);
        QRevData.('XS')(i,1).('VTG_Linear_Displacement_Projected_m')=zeros(nPoints,1);
        QRevData.('XS')(i,1).('VTG_Linear_Displacement_Magnitude_Check_m')=zeros(nPoints,1);
        for j=1:nPoints
            %Calculate the vector projection
            aDotB_hat=dot([QRevData.XS(i).VTG_East_Displacement_m(j);QRevData.XS(i).VTG_North_Displacement_m(j)],QRevData.XS(i).VTG_UnitVector_E_N);
            QRevData.XS(i).VTG_East_Displacement_Projected_m(j)=aDotB_hat*QRevData.XS(i).VTG_UnitVector_E_N(1);
            QRevData.XS(i).VTG_North_Displacement_Projected_m(j)=aDotB_hat*QRevData.XS(i).VTG_UnitVector_E_N(2);
            %Done

            %Next convert the projection into linear distances. Use scalar projection and preserve the sign of displacement (i.e. rather than magnitude of vector) https://en.wikipedia.org/wiki/Scalar_projection
            %Important if the first and last points (that define the cross section) are not the min and max end of the cross section
            QRevData.XS(i).VTG_Linear_Displacement_Projected_m(j)=dot([QRevData.XS(i).VTG_East_Displacement_Projected_m(j);QRevData.XS(i).VTG_North_Displacement_Projected_m(j)],QRevData.XS(i).VTG_UnitVector_E_N);
            QRevData.XS(i).VTG_Linear_Displacement_Magnitude_Check_m(j)=(QRevData.XS(i).VTG_East_Displacement_Projected_m(j)^2+QRevData.XS(i).VTG_North_Displacement_Projected_m(j)^2)^0.5;
            %Done
        end
        %Done

        %GGA Next project the measurement coordinates onto the cross section line. https://en.wikipedia.org/wiki/Vector_projection  a1=(a dot b_hat)b_hat   where a1 is the vector projection of a onto b_hat
        nPoints=length(QRevData.XS(i).Depth_Cleaned_m);
        QRevData.('XS')(i,1).('GGA_East_Displacement_Projected_m')=zeros(nPoints,1);
        QRevData.('XS')(i,1).('GGA_North_Displacement_Projected_m')=zeros(nPoints,1);
        QRevData.('XS')(i,1).('GGA_Linear_Displacement_Projected_m')=zeros(nPoints,1);
        QRevData.('XS')(i,1).('GGA_Linear_Displacement_Magnitude_Check_m')=zeros(nPoints,1);

        for j=1:nPoints
            %Calculate the vector projection
            aDotB_hat=dot([QRevData.XS(i).GGA_East_Displacement_m(j);QRevData.XS(i).GGA_North_Displacement_m(j)],QRevData.XS(i).GGA_UnitVector_E_N);
            QRevData.XS(i).GGA_East_Displacement_Projected_m(j)=aDotB_hat*QRevData.XS(i).GGA_UnitVector_E_N(1);
            QRevData.XS(i).GGA_North_Displacement_Projected_m(j)=aDotB_hat*QRevData.XS(i).GGA_UnitVector_E_N(2);
            %Done

            %Next convert the projection into linear distances. Use scalar projection and preserve the sign of displacement (i.e. rather than magnitude of vector) https://en.wikipedia.org/wiki/Scalar_projection
            %Important if the first and last points (that define the cross section) are not the min and max end of the cross section
            QRevData.XS(i).GGA_Linear_Displacement_Projected_m(j)=dot([QRevData.XS(i).GGA_East_Displacement_Projected_m(j);QRevData.XS(i).GGA_North_Displacement_Projected_m(j)],QRevData.XS(i).GGA_UnitVector_E_N);
            QRevData.XS(i).GGA_Linear_Displacement_Magnitude_Check_m(j)=(QRevData.XS(i).GGA_East_Displacement_Projected_m(j)^2+QRevData.XS(i).GGA_North_Displacement_Projected_m(j)^2)^0.5;
            %Done
        end
        %Done
    end
    
    %BT Next project the measurement coordinates onto the cross section line. https://en.wikipedia.org/wiki/Vector_projection  a1=(a dot b_hat)b_hat   where a1 is the vector projection of a onto b_hat
    nPoints=length(QRevData.XS(i).Depth_Cleaned_m);
    QRevData.('XS')(i,1).('BT_East_Displacement_Projected_m')=zeros(nPoints,1);
    QRevData.('XS')(i,1).('BT_North_Displacement_Projected_m')=zeros(nPoints,1);
    QRevData.('XS')(i,1).('BT_Linear_Displacement_Projected_m')=zeros(nPoints,1);
    QRevData.('XS')(i,1).('BT_Linear_Displacement_Magnitude_Check_m')=zeros(nPoints,1);

    for j=1:nPoints
        %Calculate the vector projection
        aDotB_hat=dot([QRevData.XS(i).BT_East_Displacement_m(j);QRevData.XS(i).BT_North_Displacement_m(j)],QRevData.XS(i).BT_UnitVector_E_N);
        QRevData.XS(i).BT_East_Displacement_Projected_m(j)=aDotB_hat*QRevData.XS(i).BT_UnitVector_E_N(1);
        QRevData.XS(i).BT_North_Displacement_Projected_m(j)=aDotB_hat*QRevData.XS(i).BT_UnitVector_E_N(2);
        %Done

        %Next convert the projection into linear distances. Use scalar projection and preserve the sign of displacement (i.e. rather than magnitude of vector) https://en.wikipedia.org/wiki/Scalar_projection
        %Important if the first and last points (that define the cross section) are not the min and max end of the cross section
        QRevData.XS(i).BT_Linear_Displacement_Projected_m(j)=dot([QRevData.XS(i).BT_East_Displacement_Projected_m(j);QRevData.XS(i).BT_North_Displacement_Projected_m(j)],QRevData.XS(i).BT_UnitVector_E_N);
        QRevData.XS(i).BT_Linear_Displacement_Magnitude_Check_m(j)=(QRevData.XS(i).BT_East_Displacement_Projected_m(j)^2+QRevData.XS(i).BT_North_Displacement_Projected_m(j)^2)^0.5;
        %Done
    end
    %Done
    
    %Next sort the data (in case there are loops in the track, or the first and last points are not the min and max end of the cross section
    if(gpsBool)
        [QRevData.('XS')(i,1).('VTG_Linear_Displacement_Projected_Sorted_m'),sortIndices]=sort(QRevData.XS(i).VTG_Linear_Displacement_Projected_m);
        QRevData.('XS')(i,1).('VTG_Depth_Processed_Sorted_m')=QRevData.XS(i).Depth_Cleaned_m(sortIndices);
        [QRevData.('XS')(i,1).('GGA_Linear_Displacement_Projected_Sorted_m'),sortIndices]=sort(QRevData.XS(i).GGA_Linear_Displacement_Projected_m);
        QRevData.('XS')(i,1).('GGA_Depth_Processed_Sorted_m')=QRevData.XS(i).Depth_Cleaned_m(sortIndices);
    end
    [QRevData.('XS')(i,1).('BT_Linear_Displacement_Projected_Sorted_m'),sortIndices]=sort(QRevData.XS(i).BT_Linear_Displacement_Projected_m);
    QRevData.('XS')(i,1).('BT_Depth_Processed_Sorted_m')=QRevData.XS(i).Depth_Cleaned_m(sortIndices);
    %Done
    
    %Next add the bank data
    %EDITED THE ORDER OF THIS AS PROBLEMS DEFAULTING TO SQUARE
    if(strcmp(QRevData.XS(i).XS_Direction,'LBToRB'))
        if(gpsBool)
            QRevData.('XS')(i,1).('VTG_Linear_Displacement_Projected_Sorted_With_Edges_m')=[QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_m(1)-QRevData.meas_struct.transects(i).edges.left.dist_m;QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_m;QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_m(end)+QRevData.meas_struct.transects(i).edges.right.dist_m];
            QRevData.('XS')(i,1).('GGA_Linear_Displacement_Projected_Sorted_With_Edges_m')=[QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_m(1)-QRevData.meas_struct.transects(i).edges.left.dist_m;QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_m;QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_m(end)+QRevData.meas_struct.transects(i).edges.right.dist_m];
        end
        QRevData.('XS')(i,1).('BT_Linear_Displacement_Projected_Sorted_With_Edges_m')=[QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_m(1)-QRevData.meas_struct.transects(i).edges.left.dist_m;QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_m;QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_m(end)+QRevData.meas_struct.transects(i).edges.right.dist_m];
        
        if(strcmp(QRevData.meas_struct.transects(i).edges.left.type,'Square'))
            if(gpsBool)
                QRevData.('XS')(i,1).('VTG_Depth_Processed_Sorted_With_Edges_m')=[QRevData.XS(i).VTG_Depth_Processed_Sorted_m(1);QRevData.XS(i).VTG_Depth_Processed_Sorted_m;NaN];%Populate RB with NaN initially
                QRevData.('XS')(i,1).('GGA_Depth_Processed_Sorted_With_Edges_m')=[QRevData.XS(i).GGA_Depth_Processed_Sorted_m(1);QRevData.XS(i).GGA_Depth_Processed_Sorted_m;NaN];%Populate RB with NaN initially
            end
            QRevData.('XS')(i,1).('BT_Depth_Processed_Sorted_With_Edges_m')=[QRevData.XS(i).BT_Depth_Processed_Sorted_m(1);QRevData.XS(i).BT_Depth_Processed_Sorted_m;NaN];%Populate RB with NaN initially
        else%Triangular
            if(gpsBool)
                QRevData.('XS')(i,1).('VTG_Depth_Processed_Sorted_With_Edges_m')=[0;QRevData.XS(i).VTG_Depth_Processed_Sorted_m;NaN];%Populate RB with NaN initially
                QRevData.('XS')(i,1).('GGA_Depth_Processed_Sorted_With_Edges_m')=[0;QRevData.XS(i).GGA_Depth_Processed_Sorted_m;NaN];%Populate RB with NaN initially
            end
            QRevData.('XS')(i,1).('BT_Depth_Processed_Sorted_With_Edges_m')=[0;QRevData.XS(i).BT_Depth_Processed_Sorted_m;NaN];%Populate RB with NaN initially
        end
        if(strcmp(QRevData.meas_struct.transects(i).edges.right.type,'Square'))
            if(gpsBool)
                QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_m(end)=QRevData.XS(i).VTG_Depth_Processed_Sorted_m(end);%Populate the end value that was a NaN
                QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_m(end)=QRevData.XS(i).GGA_Depth_Processed_Sorted_m(end);%Populate the end value that was a NaN
            end
            QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_m(end)=QRevData.XS(i).BT_Depth_Processed_Sorted_m(end);%Populate the end value that was a NaN
        else%Triangular
            if(gpsBool)
                QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_m(end)=0;%Populate the end value that was a NaN
                QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_m(end)=0;%Populate the end value that was a NaN
            end
            QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_m(end)=0;%Populate the end value that was a NaN
        end
    else%RBToLB
        if(gpsBool)
            QRevData.('XS')(i,1).('VTG_Linear_Displacement_Projected_Sorted_With_Edges_m')=[QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_m(1)-QRevData.meas_struct.transects(i).edges.right.dist_m;QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_m;QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_m(end)+QRevData.meas_struct.transects(i).edges.left.dist_m];
            QRevData.('XS')(i,1).('GGA_Linear_Displacement_Projected_Sorted_With_Edges_m')=[QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_m(1)-QRevData.meas_struct.transects(i).edges.right.dist_m;QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_m;QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_m(end)+QRevData.meas_struct.transects(i).edges.left.dist_m];
        end
        QRevData.('XS')(i,1).('BT_Linear_Displacement_Projected_Sorted_With_Edges_m')=[QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_m(1)-QRevData.meas_struct.transects(i).edges.right.dist_m;QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_m;QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_m(end)+QRevData.meas_struct.transects(i).edges.left.dist_m];
        if(strcmp(QRevData.meas_struct.transects(i).edges.right.type,'Square'))
            if(gpsBool)
                QRevData.('XS')(i,1).('VTG_Depth_Processed_Sorted_With_Edges_m')=[QRevData.XS(i).VTG_Depth_Processed_Sorted_m(1);QRevData.XS(i).VTG_Depth_Processed_Sorted_m;NaN];%Populate LB with NaN initially
                QRevData.('XS')(i,1).('GGA_Depth_Processed_Sorted_With_Edges_m')=[QRevData.XS(i).GGA_Depth_Processed_Sorted_m(1);QRevData.XS(i).GGA_Depth_Processed_Sorted_m;NaN];%Populate LB with NaN initially
            end
            QRevData.('XS')(i,1).('BT_Depth_Processed_Sorted_With_Edges_m')=[QRevData.XS(i).BT_Depth_Processed_Sorted_m(1);QRevData.XS(i).BT_Depth_Processed_Sorted_m;NaN];%Populate LB with NaN initially
        else%Triangular
            if(gpsBool)
                QRevData.('XS')(i,1).('VTG_Depth_Processed_Sorted_With_Edges_m')=[0;QRevData.XS(i).VTG_Depth_Processed_Sorted_m;NaN];%Populate LB with NaN initially
                QRevData.('XS')(i,1).('GGA_Depth_Processed_Sorted_With_Edges_m')=[0;QRevData.XS(i).GGA_Depth_Processed_Sorted_m;NaN];%Populate LB with NaN initially
            end
            QRevData.('XS')(i,1).('BT_Depth_Processed_Sorted_With_Edges_m')=[0;QRevData.XS(i).BT_Depth_Processed_Sorted_m;NaN];%Populate LB with NaN initially
        end
        if(strcmp(QRevData.meas_struct.transects(i).edges.left.type,'Square'))
            if(gpsBool)
                QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_m(end)=QRevData.XS(i).VTG_Depth_Processed_Sorted_m(end);%Populate the end value that was a NaN
                QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_m(end)=QRevData.XS(i).GGA_Depth_Processed_Sorted_m(end);%Populate the end value that was a NaN
            end
            QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_m(end)=QRevData.XS(i).BT_Depth_Processed_Sorted_m(end);%Populate the end value that was a NaN
        else%Triangular
            if(gpsBool)
                QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_m(end)=0;%Populate the end value that was a NaN
                QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_m(end)=0;%Populate the end value that was a NaN
            end
            QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_m(end)=0;%Populate the end value that was a NaN
        end
    end
    %Done
 
    %Make regular cross sections (LBToRB) for all
    if(strcmp(QRevData.XS(i).XS_Direction,'LBToRB'))
        if(gpsBool)
            QRevData.('XS')(i,1).('VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_m-QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_m(1);
            QRevData.('XS')(i,1).('VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_m;
            QRevData.('XS')(i,1).('GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_m-QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_m(1);
            QRevData.('XS')(i,1).('GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_m;
        end
        QRevData.('XS')(i,1).('BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_m-QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_m(1);
        QRevData.('XS')(i,1).('BT_Depth_Processed_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_m;
    else%RBToLB
        if(gpsBool)
            QRevData.('XS')(i,1).('VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_m(end)-flipud(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_m);
            QRevData.('XS')(i,1).('VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m')=flipud(QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_m);
            QRevData.('XS')(i,1).('GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_m(end)-flipud(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_m);
            QRevData.('XS')(i,1).('GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m')=flipud(QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_m);
        end
        QRevData.('XS')(i,1).('BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m')=QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_m(end)-flipud(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_m);
        QRevData.('XS')(i,1).('BT_Depth_Processed_Sorted_With_Edges_LBToRB_m')=flipud(QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_m);
    end
    %Done
    
    %There is a problem if values are repeated (i.e. not unique). This particularly happens when no distance is entered for bank distances.
    %Use the convention of taking the minimum value of any non unique pairs since they will correspond to min depths (i.e. banks)
    if(gpsBool)
        %Clean VTG
        [uniqueDisplacements,firstUniqueIndex,~]=unique(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,'first');
        [~,lastUniqueIndex,~]=unique(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,'last');
        depthFirst=QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m(firstUniqueIndex);
        depthLast=QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m(lastUniqueIndex);
        QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m=uniqueDisplacements;
        QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m=min([depthFirst,depthLast],[],2);
        %Done

        %There is a problem if values are repeated (i.e. not unique). This particularly happens when no distance is entered for bank distances.
        %Use the convention of taking the minimum value of any non unique pairs since they will correspond to min depths (i.e. banks)
        %Clean GGA
        [uniqueDisplacements,firstUniqueIndex,~]=unique(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,'first');
        [~,lastUniqueIndex,~]=unique(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,'last');
        depthFirst=QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m(firstUniqueIndex);
        depthLast=QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m(lastUniqueIndex);
        QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m=uniqueDisplacements;
        QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m=min([depthFirst,depthLast],[],2);
        %Done
    end
    
    %There is a problem if values are repeated (i.e. not unique). This particularly happens when no distance is entered for bank distances.
    %Use the convention of taking the minimum value of any non unique pairs since they will correspond to min depths (i.e. banks)
    %Clean BT
    [uniqueDisplacements,firstUniqueIndex,~]=unique(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,'first');
    [~,lastUniqueIndex,~]=unique(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,'last');
    depthFirst=QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_LBToRB_m(firstUniqueIndex);
    depthLast=QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_LBToRB_m(lastUniqueIndex);
    QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m=uniqueDisplacements;
    QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_LBToRB_m=min([depthFirst,depthLast],[],2);
    %Done
    
    if(gpsBool)
        %Resample and smooth (use 1000 verticals for output cross section). Use a 7 point moving average for smoothing.
        %VTG
        QRevData.('XS')(i,1).('VTG_Displacement_Clean_XS_LBToRB_m')=linspace(min(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m),max(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m),1000)';
        if(~any(isnan(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m))&&~any(isnan(QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m))&&~any(isnan(QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m)));
            QRevData.('XS')(i,1).('VTG_Depth_Clean_XS_LBToRB_m')=interp1(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m);
            %QRevData.XS(i).VTG_Depth_Clean_XS_LBToRB_m=smooth(QRevData.XS(i).VTG_Depth_Clean_XS_LBToRB_m,7);%Not in available toolboxes.
            QRevData.XS(i).VTG_Depth_Clean_XS_LBToRB_m=smooth1D(QRevData.XS(i).VTG_Depth_Clean_XS_LBToRB_m,7,'Box','Truncated');
        else
            QRevData.XS(i).VTG_Depth_Clean_XS_LBToRB_m=nan*ones(size(QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m));
        end
        %Done

        %Resample and smooth (use 1000 verticals for output cross section). Use a 7 point moving average for smoothing.
        %GGA
        QRevData.('XS')(i,1).('GGA_Displacement_Clean_XS_LBToRB_m')=linspace(min(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m),max(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m),1000)';
        if(~any(isnan(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m))&&~any(isnan(QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m))&&~any(isnan(QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m)));
            QRevData.('XS')(i,1).('GGA_Depth_Clean_XS_LBToRB_m')=interp1(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m);
            %QRevData.XS(i).GGA_Depth_Clean_XS_LBToRB_m=smooth(QRevData.XS(i).GGA_Depth_Clean_XS_LBToRB_m,7);
            QRevData.XS(i).GGA_Depth_Clean_XS_LBToRB_m=smooth1D(QRevData.XS(i).GGA_Depth_Clean_XS_LBToRB_m,7,'Box','Truncated');
        else
            QRevData.XS(i).GGA_Depth_Clean_XS_LBToRB_m=nan*ones(size(QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m));
        end
        %Done
    end
    
    %Resample and smooth (use 1000 verticals for output cross section). Use a 7 point moving average for smoothing.
    %BT
    QRevData.('XS')(i,1).('BT_Displacement_Clean_XS_LBToRB_m')=linspace(min(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m),max(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m),1000)';
    if(~any(isnan(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m))&&~any(isnan(QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_LBToRB_m))&&~any(isnan(QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m)));
        QRevData.('XS')(i,1).('BT_Depth_Clean_XS_LBToRB_m')=interp1(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m);
        %QRevData.XS(i).BT_Depth_Clean_XS_LBToRB_m=smooth(QRevData.XS(i).BT_Depth_Clean_XS_LBToRB_m,7);
        QRevData.XS(i).BT_Depth_Clean_XS_LBToRB_m=smooth1D(QRevData.XS(i).BT_Depth_Clean_XS_LBToRB_m,7,'Box','Truncated');
    else
        QRevData.XS(i).BT_Depth_Clean_XS_LBToRB_m=nan*ones(size(QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m));
    end
    %Done
    
    %Rescale data by width. Use VTG if possible. Then use GGA. Then use BT.
    %This is only used for initial cross section visualisation and not final outputs. User selected reference.
    if(gpsBool)
        if(~isnan(QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m(end))&&(QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m(end)~=0))
            QRevData.('XS')(i,1).('VTG_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m;
            QRevData.('XS')(i,1).('GGA_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m*QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m(end)/QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m(end);
            QRevData.('XS')(i,1).('BT_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m*QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m(end)/QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m(end);
        elseif(~isnan(QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m(end))&&(QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m(end)~=0))
            QRevData.('XS')(i,1).('VTG_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m*QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m(end)/QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m(end);
            QRevData.('XS')(i,1).('GGA_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m;
            QRevData.('XS')(i,1).('BT_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m*QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m(end)/QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m(end);
        else
            QRevData.('XS')(i,1).('VTG_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m*QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m(end)/QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m(end);
            QRevData.('XS')(i,1).('GGA_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m*QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m(end)/QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m(end);
            QRevData.('XS')(i,1).('BT_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m;
        end
    else
        QRevData.('XS')(i,1).('BT_Displacement_Clean_Equalised_XS_LBToRB_m')=QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m;
    end
    %Done    
    
    %Visualise cross section and projected cross section East and North
    figure();
    hold on;
    %Ship tracks
    plot(QRevData.XS(i).BT_East_Displacement_m,QRevData.XS(i).BT_North_Displacement_m,'r','LineWidth',2);
    if(gpsBool)
        plot(QRevData.XS(i).GGA_East_Displacement_m,QRevData.XS(i).GGA_North_Displacement_m,'b','LineWidth',2);
        plot(QRevData.XS(i).VTG_East_Displacement_m,QRevData.XS(i).VTG_North_Displacement_m,'g','LineWidth',2);
    end
    %Projection line
    plot(QRevData.XS(i).BT_East_Displacement_Projected_m,QRevData.XS(i).BT_North_Displacement_Projected_m,'--r','LineWidth',1);
    if(gpsBool)
        plot(QRevData.XS(i).GGA_East_Displacement_Projected_m,QRevData.XS(i).GGA_North_Displacement_Projected_m,'--b','LineWidth',1);
        plot(QRevData.XS(i).VTG_East_Displacement_Projected_m,QRevData.XS(i).VTG_North_Displacement_Projected_m,'--g','LineWidth',1);
    end
    hold off;
    %Labels
    xlabel('East Displacement (m)');
    ylabel('North Displacement (m)');
    genericFigureScaling();
    if(gpsBool)
        legend({'Ref: BT';'Ref: GGA';'Ref: VTG'},'Location','EastOutside','FontSize',24);
    else
        legend({'Ref: BT'},'Location','EastOutside','FontSize',24);
    end
    title(['Transect ',QRevData.meas_struct.transects(i).fileName],'Interpreter','none','FontSize',24);
    axis equal;
    %Done
    
    %Visualise cross section depth and LB to RB linear displacement
    figure();
    hold on;
    %Raw cross sections
    %plot(QRevData.XS(i).BT_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).BT_Depth_Processed_Sorted_With_Edges_LBToRB_m,'r','LineWidth',2);
    %plot(QRevData.XS(i).GGA_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).GGA_Depth_Processed_Sorted_With_Edges_LBToRB_m,'b','LineWidth',2);
    %plot(QRevData.XS(i).VTG_Linear_Displacement_Projected_Sorted_With_Edges_LBToRB_m,QRevData.XS(i).VTG_Depth_Processed_Sorted_With_Edges_LBToRB_m,'g','LineWidth',2);
    %Smoothed cross sections (i.e.after resampling and smoothing)
    plot(QRevData.XS(i).BT_Displacement_Clean_XS_LBToRB_m,QRevData.XS(i).BT_Depth_Clean_XS_LBToRB_m,'r','LineWidth',2);
    if(gpsBool)
        plot(QRevData.XS(i).GGA_Displacement_Clean_XS_LBToRB_m,QRevData.XS(i).GGA_Depth_Clean_XS_LBToRB_m,'b','LineWidth',2);
        plot(QRevData.XS(i).VTG_Displacement_Clean_XS_LBToRB_m,QRevData.XS(i).VTG_Depth_Clean_XS_LBToRB_m,'g','LineWidth',2);
    end
    hold off;
    set(gca, 'YDir','reverse');
    xlabel('Linear Displacement LB->RB (m)');
    ylabel('Depth (m)');
    genericFigureScaling();
    if(gpsBool)
        legend({'Ref: BT';'Ref: GGA';'Ref: VTG'},'Location','EastOutside','FontSize',24);
    else
        legend({'Ref: BT'},'Location','EastOutside','FontSize',24);
    end
    title(['Transect ',QRevData.meas_struct.transects(i).fileName,' no equalisation scaling'],'Interpreter','none','FontSize',24);
    %Done
    
    %Visualise cross section depth and rescaled (equalised) LB to RB linear displacement
    figure();
    hold on;
    %Smoothed cross sections (i.e.after resampling, smoothing and rescaling/equalisation)
    plot(QRevData.XS(i).BT_Displacement_Clean_Equalised_XS_LBToRB_m,QRevData.XS(i).BT_Depth_Clean_XS_LBToRB_m,'r','LineWidth',2);
    if(gpsBool)
        plot(QRevData.XS(i).GGA_Displacement_Clean_Equalised_XS_LBToRB_m,QRevData.XS(i).GGA_Depth_Clean_XS_LBToRB_m,'b','LineWidth',2);
        plot(QRevData.XS(i).VTG_Displacement_Clean_Equalised_XS_LBToRB_m,QRevData.XS(i).VTG_Depth_Clean_XS_LBToRB_m,'g','LineWidth',2);
    end
    hold off;
    set(gca, 'YDir','reverse');
    xlabel('Linear Displacement LB->RB (m)');
    ylabel('Depth (m)');
    genericFigureScaling();
    title(['Transect ',QRevData.meas_struct.transects(i).fileName,' with equalisation scaling'],'Interpreter','none','FontSize',24);
    if(gpsBool)
        legend({'Ref: BT';'Ref: GGA';'Ref: VTG'},'Location','EastOutside','FontSize',24);
    else
        legend({'Ref: BT'},'Location','EastOutside','FontSize',24);
    end
    %Done  
    
    %Display progress
    disp(['Processed transect ',num2str(i),' of ',num2str(numTransects)]);
    %Done
end
%Done! Works well!

%% Wrap code below in while loop to check that user is satisfied with selections
finishedSelectingAveragingOptions=false;
while(~finishedSelectingAveragingOptions)
    %% List box to choose references to use. [Just command line for now. Much faster and code execution is sequential]
    if(gpsBool)
        distanceReferenceToUse='empty';
        while(~any(strcmp(distanceReferenceToUse,{'VTG','GGA','BT'})))
            distanceReferenceToUse=input([char(10),'Type distance reference to use, input options: VTG or GGA or BT (VTG is recommended). Then press enter.',char(10)],'s');
        end
    else
        distanceReferenceToUse='BT';
        disp('Using distance reference: BT');
    end
    %Done

    %% List box to choose cross sections to use.[Just command line for now. Much faster and code execution is sequential]
    disp([char(10),'Select the cross sections to use for averaging']);
    for i=1:numTransects
        disp([num2str(i),' = ',QRevData.meas_struct.transects(i).fileName]);
    end
    crossSectionIndicesToUse=nan;
    validCrossSectionIndices=(1:numTransects)';
    xsErrorBool=false;
    while(any(isnan(crossSectionIndicesToUse)))
            crossSectionIndicesToUse=str2num(['[',input([char(10),'Type the cross section indices to use. For multiple indices, use a comma separated list (e.g. 1  or 1,3,4,6 etc). Then press enter.',char(10)],'s'),']']); %#ok<*ST2NM,*CHARTEN>
            if(any(isempty(crossSectionIndicesToUse)))
                crossSectionIndicesToUse=nan;
            end
            for j=1:length(crossSectionIndicesToUse)
                if(~any(crossSectionIndicesToUse(j)==validCrossSectionIndices))
                    disp([char(10),num2str(crossSectionIndicesToUse(j)),' is not a valid cross section index.']);
                    xsErrorBool=true;
                end
            end
            if(xsErrorBool)
                crossSectionIndicesToUse=nan;
                xsErrorBool=false;
            end                
    end
    numCrossSectionsToUse=length(crossSectionIndicesToUse);
    %Done
    
    %% Input cross section width (if known).
    reply='empty';
    while(~any(strcmp(reply,{'Y','N','y','n'})))
        reply=input([char(10),'Use user input cross section width? Type: Y to proceed, or N to use average width from cross section reference that was previously selected (e.g. VTG). Then press enter.',char(10)],'s');
    end
    if(any(strcmp(reply,{'Y','y'})))
        useInputCrossSectionWidth=true;
        crossSectionWidthToUse_m=nan;
        while(isnan(crossSectionWidthToUse_m))
            crossSectionWidthToUse_m=str2num(input([char(10),'Type the cross section width in meters if manually measured. Then press enter.',char(10)],'s')); %#ok<*CHARTEN>
            if(any(isempty(crossSectionWidthToUse_m)))
                crossSectionWidthToUse_m=nan;
            end
            if(~isnan(crossSectionWidthToUse_m))
                if(crossSectionWidthToUse_m<=0)
                    crossSectionWidthToUse_m=nan;
                end
            end
        end
    else
        useInputCrossSectionWidth=false;
        crossSectionWidthToUse_m=nan;
    end
    %Done

    %% Extract final cross section data 
    if(strcmp(distanceReferenceToUse,'GGA'))
        disp([char(10),'Processing selected cross sections, from GGA data']);
        QRevData.('FinalRescaledCrossSections').('DistanceReference')='GGA';
        for i=1:numCrossSectionsToUse
            QRevData.('FinalRescaledCrossSections').('Displacement_Clean_XS_LBToRB_m')(i,1)={QRevData.XS(crossSectionIndicesToUse(i)).GGA_Displacement_Clean_XS_LBToRB_m};
            QRevData.('FinalRescaledCrossSections').('Depth_Clean_XS_LBToRB_m')(i,1)={QRevData.XS(crossSectionIndicesToUse(i)).GGA_Depth_Clean_XS_LBToRB_m};
            QRevData.('FinalRescaledCrossSections').('OriginalCrossSectionName')(i,1)={QRevData.meas_struct.transects(crossSectionIndicesToUse(i)).fileName};
            QRevData.('FinalRescaledCrossSections').('OriginalCrossSectionIndex')(i,1)=crossSectionIndicesToUse(i);
        end
    elseif(strcmp(distanceReferenceToUse,'VTG'))
        disp([char(10),'Processing selected cross sections, from VTG data']);
        QRevData.('FinalRescaledCrossSections').('DistanceReference')='VTG';
        for i=1:numCrossSectionsToUse
            QRevData.('FinalRescaledCrossSections').('Displacement_Clean_XS_LBToRB_m')(i,1)={QRevData.XS(crossSectionIndicesToUse(i)).VTG_Displacement_Clean_XS_LBToRB_m};
            QRevData.('FinalRescaledCrossSections').('Depth_Clean_XS_LBToRB_m')(i,1)={QRevData.XS(crossSectionIndicesToUse(i)).VTG_Depth_Clean_XS_LBToRB_m};
            QRevData.('FinalRescaledCrossSections').('OriginalCrossSectionName')(i,1)={QRevData.meas_struct.transects(crossSectionIndicesToUse(i)).fileName};
            QRevData.('FinalRescaledCrossSections').('OriginalCrossSectionIndex')(i,1)=crossSectionIndicesToUse(i);
        end
    else%Default to bottom track
        disp([char(10),'Processing selected cross sections, from BT data']);
        QRevData.('FinalRescaledCrossSections').('DistanceReference')='BT';
        for i=1:numCrossSectionsToUse
            QRevData.('FinalRescaledCrossSections').('Displacement_Clean_XS_LBToRB_m')(i,1)={QRevData.XS(crossSectionIndicesToUse(i)).BT_Displacement_Clean_XS_LBToRB_m};
            QRevData.('FinalRescaledCrossSections').('Depth_Clean_XS_LBToRB_m')(i,1)={QRevData.XS(crossSectionIndicesToUse(i)).BT_Depth_Clean_XS_LBToRB_m};
            QRevData.('FinalRescaledCrossSections').('OriginalCrossSectionName')(i,1)={QRevData.meas_struct.transects(crossSectionIndicesToUse(i)).fileName};
            QRevData.('FinalRescaledCrossSections').('OriginalCrossSectionIndex')(i,1)=crossSectionIndicesToUse(i);
        end
    end
    %Done
    
    % Then rescale and average.   
    if(useInputCrossSectionWidth)
        disp([char(10),'Rescaling cross sections based on user input width']);
        QRevData.('FinalRescaledCrossSections').('RescalingReference')='UserInput';
        QRevData.('FinalRescaledCrossSections').('UserInputWidth_m')=crossSectionWidthToUse_m;
        QRevData.('FinalRescaledCrossSections').('AverageWidth_m')=crossSectionWidthToUse_m;
    else
        disp([char(10),'Rescaling cross sections based on average ',QRevData.FinalRescaledCrossSections.DistanceReference,' width']);
        QRevData.('FinalRescaledCrossSections').('RescalingReference')=QRevData.FinalRescaledCrossSections.DistanceReference;
        QRevData.('FinalRescaledCrossSections').('UserInputWidth_m')=nan;
        tempWidths_m=zeros(numCrossSectionsToUse,1);
        for i=1:numCrossSectionsToUse
            tempData=QRevData.FinalRescaledCrossSections.Displacement_Clean_XS_LBToRB_m{i,1};
            tempWidths_m(i)=tempData(end);
        end
        QRevData.('FinalRescaledCrossSections').('AverageWidth_m')=mean(tempWidths_m);
    end
    tempDisplacementMatrix=zeros(length(QRevData.FinalRescaledCrossSections.Displacement_Clean_XS_LBToRB_m{1}),numCrossSectionsToUse);
    tempDepthMatrix=zeros(length(QRevData.FinalRescaledCrossSections.Depth_Clean_XS_LBToRB_m{1}),numCrossSectionsToUse);
    for i=1:numCrossSectionsToUse
        tempData=QRevData.FinalRescaledCrossSections.Displacement_Clean_XS_LBToRB_m{i};
        QRevData.('FinalRescaledCrossSections').('Displacement_Clean_Rescaled_XS_LBToRB_m'){i,1}=QRevData.FinalRescaledCrossSections.Displacement_Clean_XS_LBToRB_m{i}*(QRevData.FinalRescaledCrossSections.AverageWidth_m/tempData(end));
        tempDisplacementMatrix(:,i)=QRevData.FinalRescaledCrossSections.Displacement_Clean_Rescaled_XS_LBToRB_m{i};
        tempDepthMatrix(:,i)=QRevData.FinalRescaledCrossSections.Depth_Clean_XS_LBToRB_m{i};
    end
    QRevData.('FinalRescaledCrossSections').('Final_Displacement_Clean_Rescaled_Averaged_XS_LBToRB_m')=mean(tempDisplacementMatrix,2);
    QRevData.('FinalRescaledCrossSections').('Final_Depth_Clean_Averaged_XS_LBToRB_m')=mean(tempDepthMatrix,2);
    %Done

    %% Visualise cross sections and average cross section.
    figure();
    colourBins=jet(1000);
    colourBinIndices=round(linspace(100,900,numCrossSectionsToUse));%Use best range of jet colour map.
    hold on;
    legendStrings=cell(numCrossSectionsToUse+1,1);
    for i=1:numCrossSectionsToUse
        plot(QRevData.FinalRescaledCrossSections.Displacement_Clean_Rescaled_XS_LBToRB_m{i},QRevData.FinalRescaledCrossSections.Depth_Clean_XS_LBToRB_m{i},'Color',colourBins(colourBinIndices(i),:),'LineWidth',2);
        legendStrings{i}=['Index ',num2str(QRevData.FinalRescaledCrossSections.OriginalCrossSectionIndex(i)), ' file ',QRevData.FinalRescaledCrossSections.OriginalCrossSectionName{i}];
    end
    plot(QRevData.FinalRescaledCrossSections.Final_Displacement_Clean_Rescaled_Averaged_XS_LBToRB_m,QRevData.FinalRescaledCrossSections.Final_Depth_Clean_Averaged_XS_LBToRB_m,'Color','k','LineStyle','-.','LineWidth',2);
    legendStrings{end}='Average cross section';
    hold off;
    set(gca,'YDir','reverse');
    xlabel('Linear Displacement LB->RB (m)');
    ylabel('Depth (m)');
    genericFigureScaling();
    title('Final projected and rescaled transect cross sections','FontSize',24);
    legend(legendStrings,'Location','EastOutside','Interpreter','none','FontSize',24);
    %Done  
    
    %% Confirm want to output average cross section, or repeat selection step.
    reply='empty';
    while(~any(strcmp(reply,{'Y','N','y','n'})))
        reply=input([char(10),'Happy with cross section processing? Ready to output cross section data? Type: Y to proceed, or N to change selection options.',char(10)],'s');
    end
    if(any(strcmp(reply,{'Y','y'})))
        finishedSelectingAveragingOptions=true;
    else
        finishedSelectingAveragingOptions=false;
    end
    %Done
end
%Done

%% Output average cross section.
%Check how Hydro STIV wants cross section data. The user manual and quick start guides are very good. Wants a text file with 'Length' as column 1, and 'Height' as column 2.

%Get user input of water level (usually use zero if orthorectified imagery).
waterLevel_m=nan;
while(isnan(waterLevel_m))
    waterLevel_m=str2num(input([char(10),'Type the cross section water level in meters if manually measured (i.e. with GPS).',char(10),...
                                'It is usually set to zero for orthorectified drone imagery, but should be measured in real world coordinates for oblique imagery with ground control points.',char(10),...
                                'If a water level staff is used, then real world water level can be calculated from a GPS measurement of the staff zero point.',char(10),...
                                'Then press enter.',char(10)],'s')); %#ok<*CHARTEN>
    if(any(isempty(waterLevel_m)))
        waterLevel_m=nan;
    end
end
QRevData.FinalRescaledCrossSections.('waterLevel_m')=waterLevel_m;
%Done

%Save the QRevData structure
disp([char(10),'Saving the QRev data structure as ',outputPathname,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_QRevData.mat']);
save([outputPathname,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_QRevData.mat'],'QRevData');
%Done

%Save the individual cross sections
disp([char(10),'Saving the individual cross sections']);
numArrayElements=length(QRevData.FinalRescaledCrossSections.Depth_Clean_XS_LBToRB_m{1});
for i=1:numCrossSectionsToUse
    outputFileName=[outputPathname,QRevData.FinalRescaledCrossSections.OriginalCrossSectionName{i}(1:end-4),'_DistanceRef_',QRevData.FinalRescaledCrossSections.DistanceReference,'_RescalingRef_',QRevData.FinalRescaledCrossSections.RescalingReference,'_LBtoRB.csv'];
    outputCellStrArray=cell(numArrayElements+1,2);
    outputCellStrArray{1,1}='Length';
    outputCellStrArray{1,2}='Height';
    for j=1:numArrayElements
        outputCellStrArray{j+1,1}=num2str(QRevData.FinalRescaledCrossSections.Displacement_Clean_Rescaled_XS_LBToRB_m{i}(j),'%.5f');
        outputCellStrArray{j+1,2}=num2str(QRevData.FinalRescaledCrossSections.waterLevel_m-QRevData.FinalRescaledCrossSections.Depth_Clean_XS_LBToRB_m{i}(j),'%.5f');%Water level minus depth to give heights.
    end
    %writecell(outputCellStrArray,outputFileName);%Using Matlab 2018b currently
    cellStrMatrix2csvFaster(outputFileName,outputCellStrArray,',');
end
%Done

%Save the average cross sections
disp([char(10),'Saving the average cross section']);
numArrayElements=length(QRevData.FinalRescaledCrossSections.Depth_Clean_XS_LBToRB_m{1});
outputFileName=[outputPathname,'AverageCrossSection_DistanceRef_',QRevData.FinalRescaledCrossSections.DistanceReference,'_RescalingRef_',QRevData.FinalRescaledCrossSections.RescalingReference,'_LBtoRB.csv'];
outputCellStrArray=cell(numArrayElements+1,2);
outputCellStrArray{1,1}='Length';
outputCellStrArray{1,2}='Height';
for j=1:numArrayElements
    outputCellStrArray{j+1,1}=num2str(QRevData.FinalRescaledCrossSections.Final_Displacement_Clean_Rescaled_Averaged_XS_LBToRB_m(j),'%.5f');
    outputCellStrArray{j+1,2}=num2str(QRevData.FinalRescaledCrossSections.waterLevel_m-QRevData.FinalRescaledCrossSections.Final_Depth_Clean_Averaged_XS_LBToRB_m(j),'%.5f');%Water level minus depth to give heights.
end
%writecell(outputCellStrArray,outputFileName);%Not available in older versions of Matlab that some people may deploy
cellStrMatrix2csvFaster(outputFileName,outputCellStrArray,',');
%Done

%Save figures if needed
reply='empty';
while(~any(strcmp(reply,{'Y','N','y','n'})))
    reply=input([char(10),'Would you also like to save all the figures as images (useful for QC)? Type: Y to save figures, or N if figures are not needed.',char(10)],'s');
end
if(any(strcmp(reply,{'Y','y'})))
    saveFiguresPNG(outputPathname);
    disp([char(10),'Figures saved in a subdirectory in ',outputPathname]);
end
%Done

%Finished processing
disp([char(10),'CrossSectionsFromQRevR2019b has completed processing. Please close the application.']);
%Done

%% Functions
function output=vecangle360(v1,v2)
    %Angle from v1 to v2
    %Thanks to James Tursa for this handy function. Adjusted for 2D input vectors and a RHS coordinate system [E;N;Up]
    n=[0;0;1];
    v1=[v1;0];
    v2=[v2;0];
    x=cross(v1,v2);
    c=sign(dot(x,n))*norm(x);
    output=atan2d(c,dot(v1,v2));
    %Tested and works well
end

function cleanedData=repNaN_ensDuration(ensDurations_sec)
    %If durations are missed, then they are included in the next bin.
    %shuffle order of ensDuration so that first bin has a value. I.e. data in second bin indicates elapsed time to start of bin from start of previous good bin.
    %Remove the NaNs and subsequent time and replace with mean ensemble time
    
    %Flip it if needed
    if(~iscolumn(ensDurations_sec))
        ensDurations_sec=ensDurations_sec';
    end
    %Done
        
    %Get the nan locations
    nanBool=isnan(ensDurations_sec);
    sequentialNaNStarts=nanBool&~[0;nanBool(1:end-1)];
    %sequentialNaNEnds=nanBool&~[nanBool(2:end);0];%Dont need the ends of the NaN sequences    
    cumulativeBool=~nanBool&[0;nanBool(1:end-1)];%Do need the next bin where the summed duration data is stored.
    sequentialNaNStartsIndices=find(sequentialNaNStarts);
    %sequentialNaNEndsIndices=find(sequentialNaNEnds);
    cumulativeIndices=find(cumulativeBool);
    %Done
    
    %Fix the missing data
    nChunks=length(sequentialNaNStartsIndices);
    for i=1:nChunks
        ensDurations_sec(sequentialNaNStartsIndices(i):cumulativeIndices(i))=ensDurations_sec(cumulativeIndices(i))/(cumulativeIndices(i)-sequentialNaNStartsIndices(i)+1);
    end
    %Done
    
    %Output
    cleanedData=ensDurations_sec;
    %Done
end
%Done
    
function cleanedData=repNaN_Linear(inputArray)
    %This function performs linear interpolation and replicates nearest good value for start/end nans
    %Assumes regularly spaced data
    
    %Flip it if needed
    if(~iscolumn(inputArray))
        inputArray=inputArray';
    end
    %Done
        
    %Get the nan locations
    nPoints=length(inputArray);
    nanBool=isnan(inputArray);
    sequentialNaNStarts=nanBool&~[0;nanBool(1:end-1)];
    sequentialNaNEnds=nanBool&~[nanBool(2:end);0];
    sequentialNaNStartsIndices=find(sequentialNaNStarts);
    sequentialNaNEndsIndices=find(sequentialNaNEnds);
    sequentialNaNLGVIndices=sequentialNaNStartsIndices-1;%LGV = Last Good Value  (will be treated as a special case if exceeds array indices).
    sequentialNaNNGVIndices=sequentialNaNEndsIndices+1;%NGV = Next Good Value  (will be treated as a special case if exceeds array indices).
    %Done
    
    %Fix the missing data
    nChunks=length(sequentialNaNStartsIndices);
    for i=1:nChunks
        if((sequentialNaNLGVIndices(i)>=1)&&(sequentialNaNNGVIndices(i)<=nPoints))
            chunkLength=sequentialNaNEndsIndices(i)-sequentialNaNStartsIndices(i)+1;
            linearInterpTemp=linspace(inputArray(sequentialNaNLGVIndices(i)),inputArray(sequentialNaNNGVIndices(i)),chunkLength+2)';%chunkLength+2 since preserving the original data in it's original location and interpolating between
            inputArray(sequentialNaNStartsIndices(i):sequentialNaNEndsIndices(i))=linearInterpTemp(2:end-1);
        elseif((sequentialNaNLGVIndices(i)<1)&&(sequentialNaNNGVIndices(i)<=nPoints))
            inputArray(sequentialNaNStartsIndices(i):sequentialNaNEndsIndices(i))=inputArray(sequentialNaNNGVIndices(i));
        elseif((sequentialNaNNGVIndices(i)>nPoints)&&(sequentialNaNLGVIndices(i)>=1))
            inputArray(sequentialNaNStartsIndices(i):sequentialNaNEndsIndices(i))=inputArray(sequentialNaNLGVIndices(i));
        else
            warning('Warning bad data processed in repNaN_Linear() likely all input data points are NaN');
        end
    end
    %Done
    
    %Output
    cleanedData=inputArray;
    %Done
end

function cleanedData=repNaN_Mean(inputArray)
    %This function replaces NaNs with the mean of good values
    inputArray(isnan(inputArray))=mean(inputArray(~isnan(inputArray)));
    cleanedData=inputArray;
    %Done
end

%{
function cellStrMatrix2csvFaster(outputFullFileName,cellStrMatrix,delimiter)
    %Clean up output of text from matlab
    
    %Initialise
    fHandle=fopen(outputFullFileName, 'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        error(['Error in cellStrMatrix2csvFaster(), could not open or create the file ',outputFullFileName,' check it isn''t already open or similar']);
    end
    cellArrayHeight=size(cellStrMatrix, 1);
    cellArrayWidth=size(cellStrMatrix, 2);
    %Done
    
    %Loop and build char string
    inputSize=whos('cellStrMatrix');
    delimLength=length(delimiter);
    nlLength=length(char(10));
    temp=char(zeros(1,inputSize.bytes+2*inputSize.size(1)+inputSize.size(1)*inputSize.size(2)*delimLength+10000));%Storage size + row end chars + delimiters + bit extra
    counter=0;
    for i=1:cellArrayHeight
        for j=1:cellArrayWidth
            if(~ischar(cellStrMatrix{i,j}))%Safety check that not trying to write numeric values or similar
                error(['Error in cellStrMatrix2csvFaster() the cell in row ',num2str(i),' and column ',num2str(j),' does not contain a string']);
            end
            %fprintf(fHandle,'%s',cellStrMatrix{i,j});%Write data
            %temp{1}=[temp{1},cellStrMatrix{i,j}];
            dC=length(cellStrMatrix{i,j});
            temp(counter+1:counter+dC)=cellStrMatrix{i,j};
            counter=counter+dC;
            if(j==cellArrayWidth)%NL if end of row
                if(i~=cellArrayHeight)%Only put NL if it isn't the end of the file.
                    temp(counter+1:counter+nlLength)=char(10);
                    counter=counter+2;
                end
            else
                temp(counter+1:counter+delimLength)=delimiter;
                counter=counter+delimLength;
            end
        end
    end
    fprintf(fHandle,'%s',temp(1:counter));
    %Done
    
    %Close
    fclose(fHandle);
    %Done
    
    %Tested, works well.
    %There is also the function writecell(C,filename) that seems to be new [introduced in 2019a]? Also works well.
end

HydroSTIV doesn't like char(10)  changed to version below
%}

function cellStrMatrix2csvFaster(outputFullFileName,cellStrMatrix,delimiter)
    %Clean up output of text from matlab
    
    %Initialise
    fHandle=fopen(outputFullFileName, 'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        error(['Error in cellStrMatrix2csvFaster(), could not open or create the file ',outputFullFileName,' check it isn''t already open or similar']);
    end
    cellArrayHeight=size(cellStrMatrix, 1);
    cellArrayWidth=size(cellStrMatrix, 2);
    %Done
    
    %Loop and build char string
    inputSize=whos('cellStrMatrix');
    delimLength=length(delimiter);
    %nlLength=length(char(10));
    %nlLength=length('\n');
    %nlLength=length([char(13),char(10)]);%'\r\n'
    nlLength=length(char(13));%'\r\n'
    temp=char(zeros(1,inputSize.bytes+2*inputSize.size(1)+inputSize.size(1)*inputSize.size(2)*delimLength+10000));%Storage size + row end chars + delimiters + bit extra
    counter=0;
    for i=1:cellArrayHeight
        for j=1:cellArrayWidth
            if(~ischar(cellStrMatrix{i,j}))%Safety check that not trying to write numeric values or similar
                error(['Error in cellStrMatrix2csvFaster() the cell in row ',num2str(i),' and column ',num2str(j),' does not contain a string']);
            end
            %fprintf(fHandle,'%s',cellStrMatrix{i,j});%Write data
            %temp{1}=[temp{1},cellStrMatrix{i,j}];
            dC=length(cellStrMatrix{i,j});
            temp(counter+1:counter+dC)=cellStrMatrix{i,j};
            counter=counter+dC;
            if(j==cellArrayWidth)%NL if end of row
                if(i~=cellArrayHeight)%Only put NL if it isn't the end of the file.
                    %temp(counter+1:counter+nlLength)=char(10);
                    %temp(counter+1:counter+nlLength)='\n';
                    temp(counter+1:counter+nlLength)=char(13);
                    %counter=counter+2;
                    counter=counter+nlLength;
                end
            else
                temp(counter+1:counter+delimLength)=delimiter;
                counter=counter+delimLength;
            end
        end
    end
    fprintf(fHandle,'%s',temp(1:counter));
    %Done
    
    %Close
    fclose(fHandle);
    %Done
    
    %Tested, works well.
    %There is also the function writecell(C,filename) that seems to be new [introduced in 2019a]? Also works well.
end
function lastDir=getPreviousDir()
    %Function to read the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=mfilename('fullpath');
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'r');%Will open the file for reading if it exists
    if(fHandle==-1)
        lastDir=pwd;
    else
        allData=textscan(fHandle,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
        fclose(fHandle);
        if(iscell(allData))
            allData=allData{1};%Unpack it
        end
        if(iscell(allData))
            allData=allData{1};%Unpack it twice sometimes needed...
        end
        if(contains(allData,'\'))
            slashIndices=strfind(allData,'\');
            tempPath=allData(1:slashIndices(end));
            if(isfolder(tempPath))
                lastDir=tempPath;
            else
                lastDir=pwd;
            end            
        else
            lastDir=pwd;
        end
        %Done
    end
    %Done
end

function writeCurrentDir(currentDir)
    %Function to record the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=matlab.desktop.editor.getActiveFilename;
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        warning(['Could not write the last used directory to ',[scriptPath,nameOfStorageFile],' please check this file isn''t already open or similar']);
    else
        fprintf(fHandle,'%s',currentDir);
        fclose(fHandle);
    end
    %Done
end

%The Matlab function 'smooth()' is only available with some toolboxes. Hence another 1D smoothing function written by the author has been added here.
function outputSmoothedArray=smooth1D(inputArray,kernelWidth,kernelTypeString,paddingTypeString)
    %1D smoothing function
    %'Truncated' is the recommended method for averaging at the ends (i.e. no padding)
    %e.g. outputSmoothedArray=smooth1D(inputArray,5,'Box','Truncated')

    %Dimensional safety tests
    if(length(size(inputArray))>2||~any(size(inputArray)==1)||numel(inputArray)<=1)
        error('Error in smooth1D, inputArray is not a 1 dimensional array');
    end
    %Done

    %Flip row vectors to column vectors
    if(size(inputArray,1)==1&&size(inputArray,2)>1)
        inputArray=inputArray';
    end
    %Done

    %Check kernel size
    if(rem(kernelWidth,2)~=1)
        warning('Warning in smooth1D, kernel width is not an odd integer. Suggest values such as 3,5,7,9 etc');
    end
    %Done

    %Generate kernels
    if(strcmp(kernelTypeString,'Box'))
        kernel=ones(kernelWidth,1)/kernelWidth;
        %Done
    elseif(strcmp(kernelTypeString,'Gaussian'))
        %Now the only tricky thing is choosing the standard deviation
        %Assume that the full kernel width corresponds to 2 standard deviations
        %So sigma=ceil(kR/2);
        kR=(kernelWidth-1)/2;
        SD=ceil(kR/2);

        yTemp=[-kR:1:kR]';
        kernel=normpdf(yTemp,0,SD)/sum(normpdf(yTemp,0,SD));%Evaluates pdf at these points, so need to renormalise it for smoothing.
        %Done
    else
        error('Error in smooth1D() unknown kernel type');
        %Other kernels such as inverse distance can easily be added.
    end
    %Done

    %Next need to decide padding type
    if(strcmp(paddingTypeString,'Zeros'))
        paddedArray=[zeros(kernelWidth,1);inputArray;zeros(kernelWidth,1)];                
    elseif(strcmp(paddingTypeString,'Mirror'))
        paddedArray=[flipud(inputArray(1:kernelWidth));inputArray;flipud(inputArray(end-kernelWidth+1:end))]; 
    elseif(strcmp(paddingTypeString,'Mean'))
        paddedArray=[ones(kernelWidth,1)*mean(inputArray);inputArray;ones(kernelWidth,1)*mean(inputArray)]; 
    elseif(strcmp(paddingTypeString,'Truncated'))
        %No padded array is needed for this method
    else                
        error('Error in smooth1D() unknown padding method');
    end
    %Done

    %Then cross correlation with inbuilt function, or my own
    if(strcmp(paddingTypeString,'Truncated'))
        %This method uses no boundary mirroring etc, but just truncates the kernel to handle end regions.
        tempSmoothedArray=smooth1DTruncatedKernel(inputArray,kernel);
    else
        %Then perform cross correlation (just use convolution, but flip kernel). (not needed for symmetric kernels, but good habbit).
        tempArray=conv(paddedArray,flipud(kernel),'same');
        %Then extract central region away from padding
        tempSmoothedArray=tempArray(kernelWidth+1:end-kernelWidth);
    end
    %Done

    %Safety check and output
    if(length(tempSmoothedArray)~=length(inputArray))
        error('Error in smooth1D() length discrepancy');
    end
    outputSmoothedArray=tempSmoothedArray;
    %Done
end 
function outputSmoothedArray=smooth1DTruncatedKernel(inputArray,inputKernel)
    %This performs cross correlation itself, so may be very slow. Uses a truncated kernel so bias is introduced.
    %This is called from smooth1D with paddingTypeString set to 'Truncated'

    %Initialise
    inputArray=inputArray(:);%Force column vectors
    inputKernel=inputKernel(:);
    AL=length(inputArray);%ArrayLength
    KL=length(inputKernel);%KernelLength
    KR=(KL-1)/2;%KernelRadius
    KCI=(KL+1)/2;%KernelCentreIndex
    %Done

    %Safety check
    if(mod(KL,2)~=1)
        error('Error in smooth1DTruncatedKernel() kernel is not odd');
    end
    %Done

    %Initialise padded kernel and output array
    fullKernel=zeros(AL+2*KR,1);
    fullKernel(1:KL)=inputKernel;
    tempOutputArray=zeros(AL,1);
    %Done

    %Loop through array
    for i=1:AL
        extractedKernel=fullKernel(KR+1:KR+AL,1);
        normalisation=sum(extractedKernel);
        tempOutputArray(i)=sum(extractedKernel.*inputArray)/normalisation;
        fullKernel=circshift(fullKernel,1);
    end
    %Done

    %Output data
    outputSmoothedArray=tempOutputArray;
    %Done          
end

%Also add functionality for saving figures
function saveFiguresPNG(fullOutputDirectory)
%Another figure saving function

    %Check fullOutputDirectory
    if(fullOutputDirectory(end)~='/')
        fullOutputDirectory(end+1)='/';
    end
    %Done
    
    %Next make dir if it doesnt exist
    fullOutputDirectory=[fullOutputDirectory,datestr(now,'yyyymmddTHHMMSS'),'_Figures/'];
    if(~isdir(fullOutputDirectory))
        mkdir(fullOutputDirectory);
    end
    %Done
    
    %Get the figure handles
    figureHandles=findall(0,'Type','figure');
    %Done
    
    %Next cycle through all figure handles and export them
    for i=1:length(figureHandles)
        plotNumber=1+length(figureHandles)-i;%So they plot/save in the right order. (for some reason loading them loads them in reverse order)
        figure(figureHandles(i));
        set(figureHandles(i),'units','centimeters');
        outerPositionCM=get(figureHandles(i),'outerposition');
        set(figureHandles(i),'PaperUnits','centimeters');
        set(figureHandles(i),'PaperSize',[outerPositionCM(3),outerPositionCM(4)]);
        set(figureHandles(i),'PaperPosition',[0,0,outerPositionCM(3),outerPositionCM(4)]);
        %Done

        %Check an axis exists
        if(~isempty(findobj(gcf,'type','axes')))
            %Code for saving all individual ones
            disp(['Exporting individual figure ',num2str(i),' of ',num2str(length(figureHandles))]);
            saveNameIndividualPNG=[fullOutputDirectory,'Fig_',num2str(plotNumber),'.png'];
            print(gcf, '-dpng', saveNameIndividualPNG,'-r300');%Also tried 600dpi but not worth it for the filesize/time vs improvement 
            %Arghhh, matlab figure saving with white space etc.
            trimWhiteSpacePNG(saveNameIndividualPNG);
            %This fixes it well.
        end
        close(figureHandles(i));
    end
    %Done

    disp('All figures exported');
    %Works well! :)
    
    
    %Pull trimWhiteSpacePNG() out of printClass.
    function trimWhiteSpacePNG(saveNameIndividualPNG)
        %Function to circumvent matlabs stupid white space on saved figures.

        I=imread(saveNameIndividualPNG);
        notWhiteSpace=(I(:,:,1)~=255)|(I(:,:,2)~=255)|(I(:,:,3)~=255);

        topLimit=find(any(notWhiteSpace,2),1,'first');
        bottomLimit=find(any(notWhiteSpace,2),1,'last');
        leftLimit=find(any(notWhiteSpace,1),1,'first');
        rightLimit=find(any(notWhiteSpace,1),1,'last');

        crispyFigure=I(topLimit:bottomLimit,leftLimit:rightLimit,:);
        imwrite(crispyFigure,saveNameIndividualPNG);
        %Works well
    end
end

function genericFigureScaling()
    set(gca,'FontSize',30);
    set(gca,'FontWeight','Bold')
    set(gcf,'units','normalized');
    set(gcf,'outerposition',[0 0 1 1]);
    set(gca,'LineWidth',3);
    set(gca,'Box','on');
    fHandle=gcf;
    fHandle.Color=[1,1,1];
end