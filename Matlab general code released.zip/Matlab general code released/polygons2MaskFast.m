function [outputInsideMask,outputxGrid,outputyGrid]=polygons2MaskFast(inputPolygonsX,inputPolygonsY,xGrid_,yGrid_,dX_,dY_,polygonUnionHolesBool)
    %Function to speed up masking polygons.
    %inputPolygonsX and inputPolygonsY are cell arrays with size [n,1] where n is the number of polygons
    %If an auto grid is wanted, then leave xGrid and yGrid as blank (or constants) and specify dX and dY.
    %xGrid and yGrid are treated as bin centres (points) which are found to lie within, or outside the polygons.
    %Intersecting between polygons is accounted for. Self intersecting polygons are not accounted for and will show up as holes.
    
    %Input polygon sanity check
    if(~iscell(inputPolygonsX)||~iscell(inputPolygonsY)||~(length(inputPolygonsX)==length(inputPolygonsY)))
        error('Error in polygons2MaskFast() check polygon inputs to function. Expecting a cell array of polygons for inputPolygonsX and inputPolygonsY.');
    end
    %Done
    
    %Extract all polygon nodes
    xAll=[inputPolygonsX{:}];
    yAll=[inputPolygonsY{:}];
    %Done
    
    %Input grid sanity check
    if(length(xGrid_)>=2)||(length(yGrid_)>=2)
        dX_=xGrid_(2)-xGrid_(1);
        dY_=yGrid_(2)-yGrid_(1);
    elseif(((length(xGrid_)<2)||(length(yGrid_)<2))&&((dX_>0)&&(dY_>0)))
        bufferDelta=3;
        xGrid_=((round(min(xAll)/dX_)-bufferDelta)*dX_):dX_:((round(max(xAll)/dX_)+bufferDelta)*dX_);
        yGrid_=((round(min(yAll)/dY_)-bufferDelta)*dY_):dY_:((round(max(yAll)/dY_)+bufferDelta)*dY_);
    else
        error('Error in polygons2MaskFast() check grid or grid spacing inputs to function.  Expecting a numerical array for xGrid and yGrid, or these empty and numerical constants for dX and dY.');
    end
    %Done

    %Check vector orientation
    if(size(xGrid_,1)>size(xGrid_,2))
        xGrid_=xGrid_';
    end
    if(size(yGrid_,1)<size(yGrid_,2))
        yGrid_=yGrid_';
    end
    %Done
    
    %Initialise the masks
    if(polygonUnionHolesBool)
        maskUnionHoles=uint16(zeros(length(yGrid_),length(xGrid_)));
    else
        maskAll=false(length(yGrid_),length(xGrid_));
    end
    %Done
    
    %Check all the polygons. Some have dodgy NaNs within them. For split polygons. I.e. figure of 8. or some other way that they are formed. Some also terminated with NaN.
    cleanedPolygonsX=cell(size(inputPolygonsX));
    cleanedPolygonsY=cell(size(inputPolygonsY));
    cleanedPolygonIndex=1;
    blankMask=uint16(zeros(length(yGrid_),length(xGrid_)));
    onesUint16=uint16(ones(length(yGrid_),length(xGrid_)));
    for polyI_=1:length(inputPolygonsX)
        nanIndices=find(isnan(inputPolygonsX{polyI_}));
        if((length(nanIndices)==1)&&isnan(inputPolygonsX{polyI_}(end)))
            cleanedPolygonsX{cleanedPolygonIndex}=inputPolygonsX{polyI_}(1:end-1);
            cleanedPolygonsY{cleanedPolygonIndex}=inputPolygonsY{polyI_}(1:end-1);
            cleanedPolygonIndex=cleanedPolygonIndex+1;
        elseif(isempty(nanIndices))
            cleanedPolygonsX{cleanedPolygonIndex}=inputPolygonsX{polyI_}(1:end);
            cleanedPolygonsY{cleanedPolygonIndex}=inputPolygonsY{polyI_}(1:end);
            cleanedPolygonIndex=cleanedPolygonIndex+1;
        else
            if(nanIndices(1)==1)
                error('Error in polygons2MaskFast.m NaN at start of polygon');
            else
                cleanedPolygonsX{cleanedPolygonIndex}=inputPolygonsX{polyI_}(1:nanIndices(1)-1);
                cleanedPolygonsY{cleanedPolygonIndex}=inputPolygonsY{polyI_}(1:nanIndices(1)-1);
                cleanedPolygonIndex=cleanedPolygonIndex+1;
            end
            for nanIndex=1:(length(nanIndices)-1)
                cleanedPolygonsX{cleanedPolygonIndex}=inputPolygonsX{polyI_}(nanIndices(nanIndex)+1:nanIndices(nanIndex+1)-1);
                cleanedPolygonsY{cleanedPolygonIndex}=inputPolygonsY{polyI_}(nanIndices(nanIndex)+1:nanIndices(nanIndex+1)-1);
                cleanedPolygonIndex=cleanedPolygonIndex+1;
            end
            if(nanIndices(end)~=length(inputPolygonsX{polyI_}))
                cleanedPolygonsX{cleanedPolygonIndex}=inputPolygonsX{polyI_}(nanIndices(end):end);
                cleanedPolygonsY{cleanedPolygonIndex}=inputPolygonsY{polyI_}(nanIndices(end):end);
                cleanedPolygonIndex=cleanedPolygonIndex+1;
            end
        end
    end
    %This is messy and annoying, but pretty important to handle these situations properly.
    %Done
    
    %Loop all the polygons (Note: some polygons terminated with NaN).
    for polyI_=1:length(cleanedPolygonsX)
        maskPoly_=blankMask;
        %Pull out poly data
        polyX_=cleanedPolygonsX{polyI_};
        polyY_=cleanedPolygonsY{polyI_};
        %Done
        
        %Check that it is even a closed polygon (must have 4 or more vertices, since self terminates).
        if((length(polyX_)<4)||(length(polyX_)~=length(polyY_))||(polyX_(1)~=polyX_(end))||(polyY_(1)~=polyY_(end)))
            save('wtf.mat');
            error('Error in polygons2MaskFast() passing in a dodgy polygon, check inputs. Saving wtf.mat');
        end
        %Done
        
        %Now loop the line segments
        for lineI_=1:(length(polyY_)-1)
            %Get the line segment y and x.
            yLine_=[polyY_(lineI_);polyY_(lineI_+1)];
            xLine_=[polyX_(lineI_);polyX_(lineI_+1)];
            %Done
            
            %Find equation of the line.
            %Notes: Use slope point form of line, which can be rearranged to handle vertical lines easily.
            %(y-y1)=m(x-x1)
            %x=y/m-y1/m+x1
            m_=(yLine_(2)-yLine_(1))/(xLine_(2)-xLine_(1));
            %Done
            
            %Skip horizontal lines, since they dont have a projection.
            if(m_~=0)
                %Find rows between or on the line segment.
                %Need to account for nodes exactly being on lines and only counting them once.
                if(yLine_(2)>yLine_(1))%Line angled up, so top point is second point, so do less than or equal to. (i.e. include second node of every line segment to check)
                    yRowsBool_=(yGrid_>min(yLine_))&(yGrid_<=max(yLine_));
                else%Else line angled down (horizontal lines are skipped anyway with m=0)
                    yRowsBool_=(yGrid_>min(yLine_))&(yGrid_<=max(yLine_));
                end
                yRowsIndices_=find(yRowsBool_);
                yRowsIntercepts_=yGrid_(yRowsBool_);
                %Done

                %Find the x points where the line intercepts the rows
                xIntercepts_=(yRowsIntercepts_-yLine_(1))/m_+xLine_(1);
                for rowI_=1:length(xIntercepts_)
                    xRowBool_=xGrid_>=xIntercepts_(rowI_);
                    xIndices_=find(xRowBool_);
                    maskPoly_(yRowsIndices_(rowI_),xIndices_(1):end)=maskPoly_(yRowsIndices_(rowI_),xIndices_(1):end)+1;
                end
                %Done
            end
            %Done
        end
        %Done

        %Set the maskPoly for inside points (i.e. odd number of crossings)
        %maskPoly_=rem(maskPoly_,2);%Super slow, have moved to bitwise operations. :)
        maskPoly_=bitand(maskPoly_,onesUint16);
        %Done
        
        %Update the masks of all polygons
        if(polygonUnionHolesBool)
            maskUnionHoles=maskUnionHoles+maskPoly_;
            maskUnionHoles=rem(maskUnionHoles,2);
        else
            maskAll=maskAll|(maskPoly_==1);
        end
        %Done
    end
    %Done
    
    %Output data
    outputxGrid=xGrid_;
    outputyGrid=yGrid_;
    if(polygonUnionHolesBool)
        outputInsideMask=(maskUnionHoles==1);
    else
        outputInsideMask=maskAll;
    end
    %Done
end