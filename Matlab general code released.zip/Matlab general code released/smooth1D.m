function outputSmoothedArray=smooth1D(inputArray,kernelWidth,kernelTypeString,paddingTypeString)
    %1D smoothing function
    %'Truncated' is the recommended method for averaging at the ends (i.e. no padding)
    %e.g. outputSmoothedArray=smooth1D(inputArray,5,'Box','Truncated')

    %Dimensional safety tests
    if(length(size(inputArray))>2||~any(size(inputArray)==1)||numel(inputArray)<=1)
        error('Error in smooth1D, inputArray is not a 1 dimensional array');
    end
    %Done

    %Flip row vectors to column vectors
    if(size(inputArray,1)==1&&size(inputArray,2)>1)
        inputArray=inputArray';
    end
    %Done

    %Check kernel size
    if(rem(kernelWidth,2)~=1)
        warning('Warning in smooth1D, kernel width is not an odd integer. Suggest values such as 3,5,7,9 etc');
    end
    %Done

    %Generate kernels
    if(strcmp(kernelTypeString,'Box'))
        kernel=ones(kernelWidth,1)/kernelWidth;
        %Done
    elseif(strcmp(kernelTypeString,'Gaussian'))
        %Now the only tricky thing is choosing the standard deviation
        %Assume that the full kernel width corresponds to 2 standard deviations
        %So sigma=ceil(kR/2);
        kR=(kernelWidth-1)/2;
        SD=ceil(kR/2);

        yTemp=[-kR:1:kR]';
        kernel=normpdf(yTemp,0,SD)/sum(normpdf(yTemp,0,SD));%Evaluates pdf at these points, so need to renormalise it for smoothing.
        %Done
    else
        error('Error in smooth1D() unknown kernel type');
        %Other kernels such as inverse distance can easily be added.
    end
    %Done

    %Next need to decide padding type
    if(strcmp(paddingTypeString,'Zeros'))
        paddedArray=[zeros(kernelWidth,1);inputArray;zeros(kernelWidth,1)];                
    elseif(strcmp(paddingTypeString,'Mirror'))
        paddedArray=[flipud(inputArray(1:kernelWidth));inputArray;flipud(inputArray(end-kernelWidth+1:end))]; 
    elseif(strcmp(paddingTypeString,'Mean'))
        paddedArray=[ones(kernelWidth,1)*mean(inputArray);inputArray;ones(kernelWidth,1)*mean(inputArray)]; 
    elseif(strcmp(paddingTypeString,'Truncated'))
        %No padded array is needed for this method
    else                
        error('Error in smooth1D() unknown padding method');
    end
    %Done

    %Then cross correlation with inbuilt function, or my own
    if(strcmp(paddingTypeString,'Truncated'))
        %This method uses no boundary mirroring etc, but just truncates the kernel to handle end regions.
        tempSmoothedArray=mathClass.smooth1DTruncatedKernel(inputArray,kernel);
    else
        %Then perform cross correlation (just use convolution, but flip kernel). (not needed for symmetric kernels, but good habbit).
        tempArray=conv(paddedArray,flipud(kernel),'same');
        %Then extract central region away from padding
        tempSmoothedArray=tempArray(kernelWidth+1:end-kernelWidth);
    end
    %Done

    %Safety check and output
    if(length(tempSmoothedArray)~=length(inputArray))
        error('Error in smooth1D() length discrepancy');
    end
    outputSmoothedArray=tempSmoothedArray;
    %Done

    %These functions were both inside a class, but have been separated out, and smooth1DTruncatedKernel() is contained within smooth1D()
    function outputSmoothedArray=smooth1DTruncatedKernel(inputArray,inputKernel)
        %This performs cross correlation itself, so may be very slow. Uses a truncated kernel so bias is introduced.
        %This is called from smooth1D with paddingTypeString set to 'Truncated'

        %Initialise
        inputArray=inputArray(:);%Force column vectors
        inputKernel=inputKernel(:);
        AL=length(inputArray);%ArrayLength
        KL=length(inputKernel);%KernelLength
        KR=(KL-1)/2;%KernelRadius
        KCI=(KL+1)/2;%KernelCentreIndex
        %Done

        %Safety check
        if(mod(KL,2)~=1)
            error('Error in smooth1DTruncatedKernel() kernel is not odd');
        end
        %Done

        %Initialise padded kernel and output array
        fullKernel=zeros(AL+2*KR,1);
        fullKernel(1:KL)=inputKernel;
        tempOutputArray=zeros(AL,1);
        %Done

        %Loop through array
        for i=1:AL
            extractedKernel=fullKernel(KR+1:KR+AL,1);
            normalisation=sum(extractedKernel);
            tempOutputArray(i)=sum(extractedKernel.*inputArray)/normalisation;
            fullKernel=circshift(fullKernel,1);
        end
        %Done

        %Output data
        outputSmoothedArray=tempOutputArray;
        %Done          

        %Done
    end
end       