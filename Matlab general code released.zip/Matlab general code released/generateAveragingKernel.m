function outputKernel=generateAveragingKernel(kernelTypeString,kernelDiameter,kernelShape,kernelParameter)
    %kernelType supports 'Box', 'Inverse Distance','Inverse Distance Squared', 'Gaussian' and 'StudentsT' (This is basically the averaging kernel)
    %kernelDiameter is how big it should be kernelDiameter=2*radius+1
    %kernelShape supports 'Square' (default) or 'Circle' (This is basically whether 'kernelRadius' is strictly true. I.e. averaging from a box rather than a circle incorporates data from \sqrt(2)*radius away. I.e. on the diagonals)
    %kernelParameter is standard deviation for gaussian (default is matrix radius is 2SD) or degrees of freedom for teachers (Default is 5?)
    %Taken from generateSmoothingKernel(kernelDiameter,kernelTypeString,scalingFactor)
    %Creates smoothing kernels. Symmetric with sum of scalingFactor.
     
    %The inverse distance ones are pretty mint and have good physical validity too.    
   
    %Safety test
    if(rem(kernelDiameter,2)~=1)
       error('Error in generateAveragingKernel() supplied a kernel diameter that is not odd. Use 5 for example.');
    end
    %Done
    
    %Generate kernel indices for more complex kernels
    kR=(kernelDiameter-1)/2;
    yTemp=[-kR:1:kR]';
    xTemp=[-kR:1:kR];
    yfull=repmat(yTemp,[1,kernelDiameter]);
    xfull=repmat(xTemp,[kernelDiameter,1]);
    %Done
    
    %Now make the kernels
    if(strcmp(kernelTypeString,'Box'))
        kernel=ones(kernelDiameter,kernelDiameter)/(kernelDiameter^2);
        %Done
    elseif(strcmp(kernelTypeString,'Gaussian'))
        %Now the only tricky thing is choosing the standard deviation
        if(~isnan(kernelParameter)&&(kernelParameter~=0))
            SD=kernelParameter;
        else
            %Default: Assume that the full kernel with corresponds to 2 standard deviations
            %So sigma=ceil(kR/2);
            SD=ceil(kR/2);
        end
        tempPDF2D=mvnpdf([xfull(:),yfull(:)],[0,0],[SD,SD]);%Just saw this and dont remember why x is first?
        tempPDF2D=reshape(tempPDF2D,[kernelDiameter,kernelDiameter]);
        normPDF2D=tempPDF2D/sum(tempPDF2D(:));
        kernel=normPDF2D;
        %Done
    elseif(strcmp(kernelTypeString,'Inverse Distance'))
        tempKernel=1./((yfull.^2+xfull.^2).^0.5);
        %Set centre weighting to 2 as it will be NaN or INF from division by zero. Arbitrary, but can't think of a more valid one off the top of my head.
        tempKernel(kR+1,kR+1)=2;
        normTempKernel=tempKernel/sum(tempKernel(:));
        kernel=normTempKernel;
        %Done
    elseif(strcmp(kernelTypeString,'Inverse Distance Squared'))
        tempKernel=1./(yfull.^2+xfull.^2);
        %Set centre weighting to 2 as it will be NaN or INF from division by zero. Arbitrary, but can't think of a more valid one off the top of my head.
        tempKernel(kR+1,kR+1)=2;
        normTempKernel=tempKernel/sum(tempKernel(:));
        kernel=normTempKernel;
        %Done
    elseif(strcmp(kernelTypeString,'StudentsT'))%Mjahhh, don't recommend using this one...
        %Bandwidth (i.e. degrees of freedom kDOF) can be provided, but usually will not and is hardcoded.
        if(~isnan(kernelParameter)&&(kernelParameter~=0))
            kDOF=kernelParameter;
        else
            %Solve to find the 1% probability at the full radius level?
            %Nah, don't waste time. Just bung in an arbitrary value
            
            %Bandwidth increases as binNumber increases.
            %I.e. Low degrees of freedom corresponds to a wide bandwidth
            kDOF=200/kernelDiameter;
        end
        tempPDF2D=mvtpdf([xfull(:),yfull(:)],[1,0.05;0.05,1],kDOF);%Dont remember what this correlation matrix thing is...
        tempPDF2D=reshape(tempPDF2D,[kernelDiameter,kernelDiameter]);
        normPDF2D=tempPDF2D/sum(tempPDF2D(:));
        kernel=normPDF2D;
        %Done
        %studentsTPDF=mvtpdf(xTemp(:),1,kDOF);%1D implementation
    else
        error(['Error in generateAveragingKernel() supplied an unknown kernel type of ',kernelTypeString]);
    end
    %Done
    
    %Next check output shape, since extracted data is in a square form, so adjust if want circular
    if(strcmp(kernelShape,'Circle'))
        distanceMask=(yfull.^2+xfull.^2).^0.5;
        distanceMask(distanceMask<=kR)=1;
        distanceMask(distanceMask>kR)=0;
        kernel=kernel.*distanceMask;
        
        %Then need to renormalise, since kernel points have been removed.
        kernel=kernel/sum(kernel(:));
    end
    %Done
    
    %Output   
    outputKernel=kernel;
    %Done
    
    %Done, works well.
end