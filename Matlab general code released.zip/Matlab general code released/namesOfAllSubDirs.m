function outputDirCellArray=namesOfAllSubDirs(topDirString)
    %Function to recursively go through all subdirs and get their paths. Works well. :)
    
    %Check input topDirString is sensible
    if(iscell(topDirString))
        if(size(topDirString,1)*size(topDirString,2)~=1)
            error('Error in namesOfAllSubDirs() passed in a cell string array or matrix');
        end
        topDirString=topDirString{1};
    end
    if(topDirString(end)~='\')
        topDirString(end+1)='\';
    end
    %Done
    
    %Go through subdirs as levels. Deep recursion.
    stillLooping=true;
    currentLevel=1;
    dirIndex=1;
    dirCellArray{dirIndex,1}=topDirString;
    dirCellArray{dirIndex,2}=currentLevel;
    while(stillLooping)
        dirsToSearch=dirCellArray(([dirCellArray{:,2}]==currentLevel)',1);
        currentLevel=currentLevel+1;
        nDirs=length(dirsToSearch);
        if(nDirs>0)
            dirCounter=1;
            while(dirCounter<=nDirs)
                dirData=dir(dirsToSearch{dirCounter});
                subFolderBool=([dirData.isdir])'&(~strcmp({dirData.name},'.'))'&(~strcmp({dirData.name},'..'))';
                pathsToAdd={dirData(subFolderBool).folder}';
                subDirsToAdd={dirData(subFolderBool).name}';
                numNewSubDirs=length(pathsToAdd);
                newSubDirCounter=1;
                if(numNewSubDirs>0)
                    while(newSubDirCounter<=numNewSubDirs)
                        dirIndex=dirIndex+1;
                        dirCellArray{dirIndex,1}=[pathsToAdd{newSubDirCounter},'\',subDirsToAdd{newSubDirCounter},'\'];
                        dirCellArray{dirIndex,2}=currentLevel;
                        newSubDirCounter=newSubDirCounter+1;
                    end
                end
                dirCounter=dirCounter+1;
            end
        else
            stillLooping=false;
        end
    end
    %Done

    %Output
    outputDirCellArray=dirCellArray(:,1);
    %Done
end