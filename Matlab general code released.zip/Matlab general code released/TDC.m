%TurbidityDespikingClass
classdef TDC
    methods(Static)
        %despikeTurbidityData is the pilot function that runs despiking based on user selected options
        function [outputData,outputDataSmoothed,spikePercentage]=despikeTurbidityData(inputData,replacementMethod,plotDataBool,smoothRadius,smoothType,totalTune)
            %This function controls the despiking process.
            %replacementMethod:'LI' linear interpolation 'LGV' last good value 'MMA' Modified Moving Average (recommended).
            %despikeMethod is 'mPST'.
            %plotDataBool: 'true' shows phase space plots of the data before and after despiking.
            %movingMedianSmoothRadius: 5 (default), kernelDiameter=2*radius+1, useful to smooth the signal. Moving avearge would also be effective, however median doesn't let any residual spikes skew the smoothing.
            %smoothType:'Median' (recommended and default),'Box' (e.g. standard moving average),'Gaussian','Inverse Distance'
            %totalTune: 1 (no tuning), 0->1 (more sensitive to spikes), 1+ (less sensitive to spikes)
            
            %Note1: 'POLY' polynomial replacement has been removed as very wide spike events and choosing too high a degree, AND/OR not enough data points can blow up.
            %Note2: 'MA' Moving average removed. Just use MMA. Not reliable to have a defined radius width for large spikes.
            %Note3: There may be a couple of residual spikes visible in the phase space plot after despiking. This occurs for spiky data when the replaced spike is re-detected as a spike.
            
            %Initialise
            maxLoops=100;
            spikesToRemovePerIteration=zeros(maxLoops,1);
            spikesToRemovePerIteration(1)=1;
            %spikeLocationsIteration=cell(maxLoops,1);
            stabilityCounter=1;
            tSpikes=0;
            despikedData=inputData;
            tSpikeLocationsIteration=false(size(despikedData));
            tSpikeLocations=false(size(despikedData));
            tSpikeLocationsPreviousIteration=false(size(despikedData));
            numPoints=length(despikedData);
            firstLoop=true;
            spikeRedetectionCounter=0;
            %Done
            
            %Add tuning parameters. Havn't found them necessary, but leave for potential future use.
            velTune=1;
            FOCDTune=1;
            SOCDTune=1;
            %totalTune=1;
            %Done
            
            %Loop to keep running until all data points satisfy thresholds (inside phase space elipsoid), or a loop counter reaches 1000.
            while(stabilityCounter<maxLoops)
                %This is to keep track of how many spike points are found for each iteration
                if(firstLoop)
                    firstLoop=false;
                else
                    stabilityCounter=stabilityCounter+1;
                    tSpikeLocationsPreviousIteration=tSpikeLocationsIteration;
                end
                %Done
                
                %This is to update all mean, sd, threshold etc for each of the phase space components
                t=TDC.updateDataPST(despikedData,'VEL');
                tFOCD=TDC.updateDataPST(despikedData,'FOCD');
                tSOCD=TDC.updateDataPST(despikedData,'SOCD');
                %Done
                
                %If first loop copy for plotting
                if(stabilityCounter==1)
                    tPlot=t;
                    tFOCDPlot=tFOCD;
                    tSOCDPlot=tSOCD;
                end
                %Done
                
                %This implements the PST method by checking whether despiked data points are outside phase space elipsoid.
                %Tuning parameters have been added to raise or decrease the sensitivity to certain components.
                %They will not normally be used, however they are present if needed.
                %Could modify to use medians, but mean seems to work well. :)
                tSpikeLocationsIteration=((t.workingData-t.mean).^2)./(velTune*(t.SD*t.universalThreshold).^2)+((tFOCD.workingData-tFOCD.mean).^2)./(FOCDTune*(tFOCD.SD*tFOCD.universalThreshold).^2)+((tSOCD.workingData-tSOCD.mean).^2)./(SOCDTune*(tSOCD.SD*tSOCD.universalThreshold).^2)>1*totalTune;
                 
                %Update number of spikes to replace.
                spikesToRemovePerIteration(stabilityCounter)=sum(tSpikeLocationsIteration);
                %spikeLocationsIteration{stabilityCounter}=find(tSpikeLocationsIteration);%Store spike locations
                
                %This updates the total spike location mask
                tSpikeLocations=tSpikeLocations|tSpikeLocationsIteration;
                tSpikes=sum(tSpikeLocations);
               
                %Check spike redetection
                if(tSpikeLocationsPreviousIteration==tSpikeLocationsIteration)
                    spikeRedetectionCounter=spikeRedetectionCounter+1;
                else
                    spikeRedetectionCounter=0;
                end
                
                %Now replace spikes or break if there are no spikes to replace, or same spikes have been redetected 3 times.
                if((spikesToRemovePerIteration(stabilityCounter)>0)&&(spikeRedetectionCounter<3))
                    despikedData=TDC.replaceSpikes(despikedData,tSpikeLocationsIteration,replacementMethod);
                else
                    break;
                end
            end
            %Done
            
            %% Plot phase space ellipsoid
            if(plotDataBool)
                axisExpansion=3;%i.e. see 3 times larger than the volume defined by the elipsoid
            
                %Before data cleaned
                figure();
                hold on;
                tempColourMagnitude=((tPlot.workingData-tPlot.mean).^2)./((tPlot.SD*tPlot.universalThreshold).^2)+((tFOCDPlot.workingData-tFOCDPlot.mean).^2)./((tFOCDPlot.SD*tFOCDPlot.universalThreshold).^2)+((tSOCDPlot.workingData-tSOCDPlot.mean).^2)./((tSOCDPlot.SD*tSOCDPlot.universalThreshold).^2);
                scatter3(tPlot.workingData,tFOCDPlot.workingData,tSOCDPlot.workingData,25,tempColourMagnitude,'+');
                title(['$Phase \ space \ plot \ for \ raw \ turbidity \ data \ with \ spike \ percentage \ = \ ',num2str(100*tSpikes/numPoints,3),'\%$'],'interpreter','latex');
                xlabel('$Turbidity \ (NTU)$','interpreter','latex');
                ylabel('$\Delta \ Turbidity \ (NTU)$','interpreter','latex');
                zlabel('$\Delta^2 \ Turbidity \ (NTU)$','interpreter','latex');
                view(-60,30);
                caxis([totalTune,totalTune+1]);
                axis([tPlot.mean-axisExpansion*tPlot.SD*tPlot.universalThreshold,tPlot.mean+axisExpansion*tPlot.SD*tPlot.universalThreshold,tFOCDPlot.mean-axisExpansion*tFOCDPlot.SD*tFOCDPlot.universalThreshold,tFOCDPlot.mean+axisExpansion*tFOCDPlot.SD*tFOCDPlot.universalThreshold,tSOCDPlot.mean-axisExpansion*tSOCDPlot.SD*tSOCDPlot.universalThreshold,tSOCDPlot.mean+axisExpansion*tSOCDPlot.SD*tSOCDPlot.universalThreshold]);
                h = colorbar();
                ylabel(h,strcat(num2str(totalTune),' is the cutoff for points inside the phase space ellipsoid'));
                [x,y,z] = ellipsoid(tPlot.mean,tFOCDPlot.mean,tSOCDPlot.mean,velTune*tPlot.SD*tPlot.universalThreshold,FOCDTune*tFOCDPlot.SD*tFOCDPlot.universalThreshold,SOCDTune*tSOCDPlot.SD*tSOCDPlot.universalThreshold);
                y=abs(y);
                ellipsoidSurface=surf(x, y, z);
                set(ellipsoidSurface, 'FaceColor',[0.5 0.5 0.5]);
                hold off;
                TDC.genericFigureScaling();
                %Done
                
                %After data cleaned
                figure();
                hold on;
                tempColourMagnitude=((t.workingData-t.mean).^2)./((t.SD*t.universalThreshold).^2)+((tFOCD.workingData-tFOCD.mean).^2)./((tFOCD.SD*tFOCD.universalThreshold).^2)+((tSOCD.workingData-tSOCD.mean).^2)./((tSOCD.SD*tSOCD.universalThreshold).^2);
                scatter3(t.workingData,tFOCD.workingData,tSOCD.workingData,25,tempColourMagnitude,'+');
                title(['$Phase \ space \ plot \ for \ despiked \ turbidity \ data \ with \ spike \ percentage \ = \ ',num2str(100*tSpikes/numPoints,3),'\%$'],'interpreter','latex');
                xlabel('$Turbidity \ (NTU)$','interpreter','latex');
                ylabel('$\Delta \ Turbidity \ (NTU)$','interpreter','latex');
                zlabel('$\Delta^2 \ Turbidity \ (NTU)$','interpreter','latex');
                view(-60,30);
                caxis([totalTune,totalTune+1]);
                axis([t.mean-axisExpansion*t.SD*t.universalThreshold,t.mean+axisExpansion*t.SD*t.universalThreshold,tFOCD.mean-axisExpansion*tFOCD.SD*tFOCD.universalThreshold,tFOCD.mean+axisExpansion*tFOCD.SD*tFOCD.universalThreshold,tSOCD.mean-axisExpansion*tSOCD.SD*tSOCD.universalThreshold,tSOCD.mean+axisExpansion*tSOCD.SD*tSOCD.universalThreshold]);
                h = colorbar();
                ylabel(h,strcat(num2str(totalTune),' is the cutoff for points inside the phase space ellipsoid'));
                [x,y,z] = ellipsoid(t.mean,tFOCD.mean,tSOCD.mean,t.SD*t.universalThreshold,tFOCD.SD*tFOCD.universalThreshold,tSOCD.SD*tSOCD.universalThreshold);
                y=abs(y);
                ellipsoidSurface=surf(x, y, z);
                set(ellipsoidSurface, 'FaceColor',[0.5 0.5 0.5]);
                hold off;
                TDC.genericFigureScaling();
                %Done
            end
            %Done
            
            %Check smoothing parameters
            if(smoothRadius<=0)
                smoothRadius=5;
                disp(['In TDC.despikeTurbidityData() smoothRadius set to default of ',num2string(smoothRadius)]);
            end
            if(~any(strcmp(smoothType,{'Median';'Box';'Gaussian';'Inverse Distance'})))
                smoothType='Median';
                disp(['In TDC.despikeTurbidityData() smoothType set to default of ',smoothType]);
            end
            %Done
            
            %Outputs
            outputData=despikedData;
            outputDataSmoothed=TDC.kernelSmooth1D(despikedData,smoothRadius,smoothType);
            spikePercentage=(100/numPoints)*tSpikes;
            %Done            
        end
           
        function OD=updateDataPST(despikedData,method)
            %Calculate despiking parameters
            numPoints=length(despikedData);
            if(strcmp(method,'VEL'))
                %Next copy the despikedDataArray to workingData
                workingData=despikedData;
                %Done
            elseif(strcmp(method,'FOCD'))
                %Get the psudo derivatives from first order central difference
                %This is a one way to vectorise uFOCD(i)=(rawData(i+1)-rawData(i-1))/2;
                workingData=0.5*(circshift(despikedData,-1)-circshift(despikedData,1));%Note that a reverse circ shift is needed to get the i+1 value and forward for (i-1)
                workingData(1)=despikedData(2)-despikedData(1);%Forward difference at start
                workingData(end)=despikedData(end)-despikedData(end-1);%Backward difference at end
                %Done
            elseif(strcmp(method,'SOCD'))
                %Get the psudo derivatives from second order central difference
                %This is a one way to vectorise uSOCD(i)=(rawData(i+2)-2*rawData(i)+rawData(i-2))/4;
                workingData=0.25*(circshift(despikedData,-2)-2*despikedData+circshift(despikedData,+2));
                
                %{
                Ends of data with combined forward and backward differences
                y=      [a;                 b;                      c;                          d;                      e]
                dy/dx=  [b-a;               0.5c-0.5a;              0.5d-0.5b;                  0.5e-0.5c;              e-d]
                d2y/dx2=[(0.5c-0.5a)-(b-a); ((0.5d-0.5b)-(b-a))/2;  ((0.5e-0.5c)-(0.5c-0.5a)/2; ((e-d)-(0.5d-0.5b))/2;  (e-d)-(0.5e-0.5c)]
                d2y/dx2=[0.5c+0.5a-b;       0.25d-0.75b+0.5a;       0.25e-0.5c+0.25a;           0.25b-0.75d+0.5e;       0.5e+0.5c-d]
                %}
                workingData(1)=0.5*despikedData(3)+0.5*despikedData(1)-despikedData(2);%Forward difference of forward difference and central difference
                workingData(2)=0.25*despikedData(4)-0.75*despikedData(2)+0.5*despikedData(1);%Central difference of forward difference and central difference
                workingData(end-1)=0.25*despikedData(end-3)-0.75*despikedData(end-1)+0.5*despikedData(end);%Central difference of backward difference and central difference
                workingData(end)=0.5*despikedData(end)+0.5*despikedData(end-2)-despikedData(end-1);%Backward difference of backward difference and central difference
                %Done
            else
               error(['Error in updateDataPST, no method exists for ',method]);
            end
            %Done
            
            %Now calculate the universalThreshold components
            OD.('workingData')=workingData;
            OD.('mean')=mean(workingData);
            OD.('SD')=std(workingData);
            OD.('universalThreshold')=(2*log(numPoints))^0.5;
            OD.('expectedAbsoluteMaximum')=OD.mean+OD.SD*OD.universalThreshold;
            OD.('expectedAbsoluteMinimum')=OD.mean-OD.SD*OD.universalThreshold;
            %Done
        end
        
        function outputDespikedData=replaceSpikes(despikedData,tSpikeLocationsIteration,replacementMethod)
            %This function controls the replacement of spikes.
            %replacementMethod: 'LI' - linear interpolation, 'LGV' - last good value, 'MMA' - replaces spikes with modified moving average 
            %Note: 'POLY' - i.e. 12 point polynomial has been removed as it frequently blows up with turbidity data.
            
            if(strcmp(replacementMethod,'LI'))
                %This is another simple replacement technique where spikes are replaced with a linear interpolation between good data.
                %If the first/last, or first/last few data points are bad, then first good value values will propogate backwards in time to fill these.
                despikedData=TDC.linearInterpolationReplacement(despikedData,tSpikeLocationsIteration); 
                %Done
            elseif(strcmp(replacementMethod,'LGV'))
                %This is the simplistic replacement technique where bad values are replaced with the previous good one in time.
                %If the first, or first few data points are bad, then replacement values will propogate backwards in time to fill these.
                despikedData=TDC.lastGoodValueReplacement(despikedData,tSpikeLocationsIteration);
                %Done
            elseif(strcmp(replacementMethod,'MMA'))
                %This just fits through a specified number of points, not a specified radius. E.g. the number of closest good data points used is MMAdataPoints.
                MMAdataPoints=14;
                weightedMeanBool=true;%Recommended to weight data to closest non-spike data to the spike being replaced.
                despikedData=TDC.modifiedMovingAverageReplacement(despikedData,tSpikeLocationsIteration,MMAdataPoints,weightedMeanBool);
                %Done
            else    
                error(['Error in TDC.replaceSpikes() no method found for method ',replacementMethod]);               
            end

            outputDespikedData=despikedData;
            %Looks good
        end
        
        %Despiking internal function linearInterpolationReplacement
        function outputData=linearInterpolationReplacement(inputData,inputSpikeMask)
            %Easy replacement technique, spikes are interpolated from two neighbouring good data points.
            %Spikes on the first or last data point are replaced with nearest good neighbours.
            
            %Check if any NaN values have been passed to the function and make them also spikes to be replaced
            inputSpikeMask=inputSpikeMask|isnan(inputData)|isnan(inputSpikeMask);
            %Done
            
            %Linear interpolation
            despikedData=interp1(find(~inputSpikeMask),inputData(~inputSpikeMask),(1:length(inputData))','linear');
            %Works for interpolation between points, however the 'extrap' method they support is not nearest neighbour, but extrapolation based on gradient.
            if(isnan(despikedData(1)))
                indexOfFirstNonNaN=find(~isnan(despikedData),1,'first');
                despikedData(1:indexOfFirstNonNaN-1)=despikedData(indexOfFirstNonNaN);
            end
            if(isnan(despikedData(end)))
                indexOfLastNonNaN=find(~isnan(despikedData),1,'last');
                despikedData(indexOfLastNonNaN+1:end)=despikedData(indexOfLastNonNaN);
            end
            outputData=despikedData;
            %Done
        end
        
        %Despiking internal function lastGoodValueReplacement
        function outputData=lastGoodValueReplacement(inputData,inputSpikeMask)
            %Easiest replacement technique, time only moves in one direction, so replace a spike with the previous good value.
            %Spikes on the first slot are replaced with backwards propogating values
            
            %Check if any NaN values have been passed to the function and make them also spikes to be replaced
            inputSpikeMask=inputSpikeMask|isnan(inputData)|isnan(inputSpikeMask);
            %Done
            
            %Initialise
            despikedData=inputData;
            despikedData(inputSpikeMask)=NaN;
            %Done
            
            %Handle NaNs at start of data
            if(isnan(despikedData(1)))
                indexOfFirstNonNaN=find(~isnan(despikedData),1,'first');
                despikedData(1:indexOfFirstNonNaN-1)=despikedData(indexOfFirstNonNaN);
            end
            %Done
            
            %Loop through and replace all others where needed
            %Faster/more elegant
            spikeIndices=find(isnan(despikedData));
            for i=1:length(spikeIndices)
                despikedData(spikeIndices(i))=despikedData(spikeIndices(i)-1);
            end
            %Done
            
            %Output
            outputData=despikedData;
            %Done
        end
        
        %Despiking internal function modifiedMovingAverageReplacement
        function outputData=modifiedMovingAverageReplacement(inputData,inputSpikeMask,MMAdataPoints,weightedMeanBool)
            %Variable radius, but fixed number of data points moving average.
            %Centred on the spike point. So if big spike event to one side may be skewed to data on the good side
            %The advantage of this is that it avoids NaN issues, and you can use the minimum points needed to find a replacement.
            %Also it works as a linear interpolation on a slope, a LGV at the start of a big spike event, a NGV at the end of a big spike event, and an interpolation at the middle of a spike event
            %It is also physically valid as it is based on the surrounding values.
            %MMAdataPoints: 10
            %weightedMeanBool:true (weighted by proximty to replaced data point)
            %Note: Choose an even number for the MMAdataPoints is advised to maintain symmetry around single isolated spikes.
            
            %Function rewrittento be more elegant
            
            %Check if any NaN values have been passed to the function and make them also spikes to be replaced
            inputSpikeMask=inputSpikeMask|isnan(inputData)|isnan(inputSpikeMask);
            %Done
            
            %Initialise
            maskedData=inputData;
            maskedData(inputSpikeMask)=NaN;
            spikeIndices=find(isnan(maskedData));
            goodDataIndices=find(~isnan(maskedData));
            goodData=maskedData(goodDataIndices);
            despikedData=maskedData;
            %Done
            
            %Loop through and replace all spikes
            for i=1:length(spikeIndices)
                %Need to find the MMAdataPoints number of closest good data points
                distanceFromSpikeToAllGoodData=abs(goodDataIndices-spikeIndices(i));
                [sortedDistanceFromSpikeToAllGoodData,I] = sort(distanceFromSpikeToAllGoodData);
                replacementData=goodData(I(1:MMAdataPoints));
                if(weightedMeanBool)%Weight by inverse distance
                    despikedData(spikeIndices(i))=sum(replacementData./sortedDistanceFromSpikeToAllGoodData(1:MMAdataPoints))/sum(1./sortedDistanceFromSpikeToAllGoodData(1:MMAdataPoints));
                else
                    despikedData(spikeIndices(i))=mean(replacementData);
                end
            end
            %Done
            
            %Output
            outputData=despikedData;
            %Done
        end
        
        %Useful function
        function outputData=kernelSmooth1D(inputData,kernelRadius,kernelTypeString)
            %Smoothing function
            %kernelTypeString:'Median','Box' (e.g. standard moving average),'Gaussian','Inverse Distance'
            
            %Sanity check
            if((kernelRadius<=0)||(rem(kernelRadius,1)~=0))
                error(['Error in TDC.kernelSmooth1D() the supplied radius of ',num2str(kernelRadius),' is not a natural number']);
            end
            %Done
            
            %Initialise
            nSamples=length(inputData);
            paddedData=[flipud(inputData(1:kernelRadius));inputData;flipud(inputData(end-kernelRadius:end))];
            smoothedData=zeros(size(inputData));
            %Done
            
            %Handle Median smoothing first
            if(strcmp(kernelTypeString,'Median'))
                for i=1:nSamples
                    paddedDataIndex=i+kernelRadius;
                    smoothedData(i)=median(paddedData(paddedDataIndex-kernelRadius:paddedDataIndex+kernelRadius));        
                end
                %Done
            else
                smoothingKernel=TDC.generateSmoothingKernel1D(kernelRadius,kernelTypeString);
                %Cross correlation with same output size as original. So just use convolution with flipped kernel.
                smoothedPaddedData=conv(paddedData(:),flipud(smoothingKernel),'same');
                smoothedData=smoothedPaddedData(kernelRadius+1:kernelRadius+nSamples);
            end
            %Done
            
            %Output data
            outputData=smoothedData;
            %Done
        end
        
        %Useful function
        function outputSmoothingKernel=generateSmoothingKernel1D(kernelRadius,kernelTypeString)
            %Creates smoothing kernels (with vertical orientation). e.g. column vectors.
            
            %Initialise
            kR=kernelRadius;
            kernelDiameter=2*kernelRadius+1;
            %Done
            
            %Generate kernels
            if(strcmp(kernelTypeString,'Box'))
                kernel=ones(kernelDiameter,1)/kernelDiameter;
                %Done
            elseif(strcmp(kernelTypeString,'Gaussian'))
                %Now the only tricky thing is choosing the standard deviation
                %Assume that the full kernel width corresponds to 2 standard deviations
                %So sigma=ceil(kR/2);
                yTemp=(-kR:1:kR)';
                SD=ceil(kR/2);
                tempPDF=mvnpdf(yTemp,0,SD);
                kernel=tempPDF/sum(tempPDF);
                %Done
            elseif(strcmp(kernelTypeString,'Inverse Distance'))
                yTemp=(-kR:1:kR)';
                tempKernel=1./abs(yTemp);
                %Set centre weighting to 2 as it will be NaN or INF from division by zero.
                tempKernel(kR+1)=2;
                kernel=tempKernel/sum(tempKernel(:));
                %Done
            else
                error(['Error in TDC.generateSmoothingKernel1D() supplied an unknown kernel type of ',kernelTypeString]);
            end
            
            outputSmoothingKernel=kernel;
            
            %Done, tested and finished.
        end
        
        %Useful function
        function genericFigureScaling()
            set(gca,'FontSize',30);
            set(gca,'FontWeight','Bold')
            set(gcf,'units','normalized');
            set(gcf,'outerposition',[0 0 1 1]);
            set(gca,'LineWidth',3);
            set(gca,'Box','on');
            fHandle=gcf;
            fHandle.Color=[1,1,1];
        end
        
        %Crude despiking
        function outputData=crudeDespike(inputData,movingMinRadius,movingAverageRadius)
            %Data is still a mess with more advance despiking and need to relate it to the clean data.
            
            nPoints=length(inputData);
            temp=zeros(nPoints,1);
            
            %Moving min first for crude despiking
            for i=1:nPoints
                if(i<=movingMinRadius)
                    temp(i)=min(inputData(1:i+movingMinRadius));
                elseif(nPoints-i<=movingMinRadius)
                    temp(i)=min(inputData(i-movingMinRadius:end));
                else
                    temp(i)=min(inputData(i-movingMinRadius:i+movingMinRadius));
                end
            end
            %Done
            
            %Then moving average to smooth twice
            temp=TDC.kernelSmooth1D(temp,movingAverageRadius,'Box');
            temp=TDC.kernelSmooth1D(temp,movingAverageRadius,'Box');
            %Done
            
            outputData=temp;
            %Done
        end
        
        %Resample to min
        function outputData=resampleToMin(inputData,inputTimeStamps,resampleTimeStamps)
            %Function to resample data based on time stamps and extract the min.
            %Not elegant or efficient, but should do the job.
            
            nPoints=length(resampleTimeStamps);
            temp=zeros(nPoints,1);
            
            for i=1:nPoints
                %Find lower time limit of the search bin (excluded).
                if(i==1)
                    tLower=resampleTimeStamps(1)-0.5*(resampleTimeStamps(2)-resampleTimeStamps(1));
                else
                    tLower=resampleTimeStamps(i)-0.5*(resampleTimeStamps(i)-resampleTimeStamps(i-1));
                end
                
                %Find the upper time limit of the search bin (included).
                if(i==nPoints)
                    tUpper=resampleTimeStamps(end)+0.5*(resampleTimeStamps(end)-resampleTimeStamps(end-1));
                else
                    tUpper=resampleTimeStamps(i)+0.5*(resampleTimeStamps(i+1)-resampleTimeStamps(i));
                end
                
                %Extraction logical vector and exract
                extraction=(inputTimeStamps>tLower)&(inputTimeStamps<=tUpper);
                temp(i)=min(inputData(extraction));
            end
            %Done
            
            %Output
            outputData=temp;
            %Done           
        end
        
        %Resample to median
        function outputData=resampleToMedian(inputData,inputTimeStamps,resampleTimeStamps)
            %Function to resample data based on time stamps and extract the min.
            %Not elegant or efficient, but should do the job.
            
            nPoints=length(resampleTimeStamps);
            temp=zeros(nPoints,1);
            
            for i=1:nPoints
                %Find lower time limit of the search bin (excluded).
                if(i==1)
                    tLower=resampleTimeStamps(1)-0.5*(resampleTimeStamps(2)-resampleTimeStamps(1));
                else
                    tLower=resampleTimeStamps(i)-0.5*(resampleTimeStamps(i)-resampleTimeStamps(i-1));
                end
                
                %Find the upper time limit of the search bin (included).
                if(i==nPoints)
                    tUpper=resampleTimeStamps(end)+0.5*(resampleTimeStamps(end)-resampleTimeStamps(end-1));
                else
                    tUpper=resampleTimeStamps(i)+0.5*(resampleTimeStamps(i+1)-resampleTimeStamps(i));
                end
                
                %Extraction logical vector and exract
                extraction=(inputTimeStamps>tLower)&(inputTimeStamps<=tUpper);
                temp(i)=median(inputData(extraction));
            end
            %Done
            
            %Output
            outputData=temp;
            %Done           
        end
        
        %Despike manually
        function [outputData,outputSpikeMask]=despikeManually(inputData,inputTimeStamps)
            %Function for time consuming manual despiking
            
            figure();
            
            nPoints=length(inputData);
            spikeMask=false(nPoints,1);
            goodMask=false(nPoints,1);
            plotRadius=20;
            
            %Keyboard input
            for i=1:nPoints
                minPlotIndex=i-plotRadius;
                if(minPlotIndex<=0)
                    minPlotIndex=1;
                end
                maxPlotIndex=i+plotRadius;
                if(maxPlotIndex>=nPoints)
                    maxPlotIndex=nPoints;
                end
                plot(inputTimeStamps(minPlotIndex:maxPlotIndex),inputData(minPlotIndex:maxPlotIndex),'r','LineWidth',2);
                hold on;
                genericFigureScaling();
                goodMask(i)=true;
                plot(inputTimeStamps(goodMask),inputData(goodMask),'-*g','LineWidth',2,'MarkerSize',10);
                ylim([0,4*median(inputData(minPlotIndex:maxPlotIndex))]);
                xlim([inputTimeStamps(minPlotIndex),inputTimeStamps(maxPlotIndex)]);
                
                disp('Press s for spike, any other key for non spike');
                warning('off','MATLAB:nargchk:deprecated');
                inputString=getkey(1);
                %inputString=input('Press s for spike, or any other key for non spike','s');
                if(inputString==char(27))
                    disp('Escape pressed, exiting selection');
                    break;
                elseif(inputString=='s')
                    spikeMask(i)=true;
                    goodMask(i)=false;
                else
                    goodMask(i)=true;
                    spikeMask(i)=false;
                end
                hold off;
            end
            %Done
            
            %Ok, manual selection works well. (Although time consuming)
            
            %Output data
            outputSpikeMask=spikeMask;
            outputData=TDC.linearInterpolationReplacement(inputData,spikeMask);
            %Done
        end
        
        function [outputData,outputSpikeMask]=spikesToZero(inputData,threshold)
            %Used for data with mean of zero but spikes occuring.
            %Cleans all spikes back to their last zero crossing point.
            
            zeroCrossingBool=[1;((inputData(2:end-1)>0)&(inputData(1:end-2)<=0))|((inputData(2:end-1)<0)&(inputData(1:end-2)>=0));1];%Ends of data treated as zero crossing points
            zeroCrossingIndices=find(zeroCrossingBool);
            spikeMask=false(length(inputData),1);
            
            for i=1:length(zeroCrossingIndices)-1
                if(any((inputData(zeroCrossingIndices(i):zeroCrossingIndices(i+1))>threshold)|(inputData(zeroCrossingIndices(i):zeroCrossingIndices(i+1))<-threshold)))
                    spikeMask(zeroCrossingIndices(i):zeroCrossingIndices(i+1))=true;
                end
            end
            
            inputData(spikeMask)=0;
            outputData=inputData;
            outputSpikeMask=spikeMask;
            %Done
        end
    end
end




