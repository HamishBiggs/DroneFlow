function [polygonXCellArray,polygonYCellArray,binCentresX,binCentresY]=createPolygonBinsFromOrthogonalUnitVectors(unitVectorsX,unitVectorsY,originsX,originsY,binDiameter)
    %Function to create polygon bins that extend out from the river centreline.
    
    %Initialise bin centres and other variables
    binCentresX=(originsX(1:end-1)+originsX(2:end))/2;
    binCentresY=(originsY(1:end-1)+originsY(2:end))/2;
    nBins=length(binCentresX);
    polygonXCellArray=cell(nBins,1);
    polygonYCellArray=cell(nBins,1);
    %Done
    
    %Find points on either side of the unitVectors.
    side1X=originsX+(binDiameter/2)*unitVectorsX;
    side2X=originsX-(binDiameter/2)*unitVectorsX;
    side1Y=originsY+(binDiameter/2)*unitVectorsY;
    side2Y=originsY-(binDiameter/2)*unitVectorsY;
    %Done
    
    %Loop through polygons. (nBins is length(unitVectors)-1)
    for i=1:nBins
        %Create polygons
        polygonXCellArray{i}=[originsX(i);side1X(i);side1X(i+1);originsX(i+1);side2X(i+1);side2X(i);originsX(i)];
        polygonYCellArray{i}=[originsY(i);side1Y(i);side1Y(i+1);originsY(i+1);side2Y(i+1);side2Y(i);originsY(i)];
        %Done
        
        %Matlab polygon convention is that external boundaries are clockwise
        if(~ispolycw(polygonXCellArray{i},polygonYCellArray{i}))
            polygonXCellArray{i}=flipud(polygonXCellArray{i});
            polygonYCellArray{i}=flipud(polygonYCellArray{i});
        end
        %Done
    end
    %Done
end