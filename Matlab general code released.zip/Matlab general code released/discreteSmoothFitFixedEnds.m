function [outputX,outputY]=discreteSmoothFitFixedEnds(inputX,inputY,smoothingIterations,curvatureParameter,maxOutputPoints)
    %Curvature parameter left at 1 for standard, greater than 1 for sharper turns (recommend 2).
    %This function is the discrete equivalent of perfectly fitting continuous curves through data points
    %but allowing for smoothness.
    %This hits all the original data points, unlike splines etc.
    %The number of smoothing iterations determines how large and smooth the output data is.
    %WARNING: data size grows exponentially, so be careful how many smoothing iterations needed.
    %nOutputPoints=0 will use smoothingIterations, else will compute that number of output points.

    %Dimensional safety tests
    if(any(size(inputX)~=size(inputY))||length(size(inputX))>2||~any(size(inputX)==1)||numel(inputX)<=1)
        error('Error in cleanSmooth, inputX or inputY are not 1 dimensional arrays');
    end
    %Done

    %Force column vector
    inputX=inputX(:);
    inputY=inputY(:);
    %Done

    %Choose smoothing iterations if num output points known. (See "Data size safety test" for derivation of formula)
    if(maxOutputPoints~=0)
        smoothingIterations=floor(log((maxOutputPoints-1)/(length(inputX)-1))/log(2));
    end
    %To get an exact number of data points, they need to be linearly interpolated along the natural coordinate. 
    %Done

    %Data size safety test (since data grows exponentially)
    maxBytes=1*10^9;
    numVarsApprox=10;
    maxVarBytes=maxBytes/numVarsApprox;
    specifiedVarBytes=(2^(smoothingIterations)*(length(inputX))-2^smoothingIterations+1)*8;%*8 since doubles
    %N0=N0; N1=N0+(N0-1)=2*N0-1, N2=N1+(N1-1)=(2*N0-1)+(2*N0-2)=4*N0-3, N3=4*N0-3+4*N0-4=8*N0-7, N4=8*N0-7+8*N0-8=16N0-15
    if(specifiedVarBytes>maxVarBytes)
        %2^(smoothingIterations)*(length(inputX)*8-1)=maxVarBytes-1;
        %2^(smoothingIterations)=(maxVarBytes-1)/(length(inputX)*8-1);
        maxSmoothingIterations=log((maxVarBytes-1)/(length(inputX)*8-1))/log(2);
        smoothingIterations=floor(maxSmoothingIterations);
        warning(['Warning in cleanSmooth(), number of smoothing iterations will result in data larger than maxBytes, using ',num2str(smoothingIterations),' smoothing iterations']);
    end
    %Done

    %Project extra end points (Use 2 extra) Force gradient at ends the same as from P1 to P2, and PEnd-1 to PEnd
    rawX=inputX;rawY=inputY;
    proportionalSpacing=0.05;%Tweak this for how far end influence propogates
    R1=((inputY(2)-inputY(1))^2+(inputX(2)-inputX(1))^2)^0.5;
    REnd=((inputY(end)-inputY(end-1))^2+(inputX(end)-inputX(end-1))^2)^0.5;

    theta0BackProj=atan2d(inputY(1)-inputY(2),inputX(1)-inputX(2));
    theta0ForwardProj=atan2d(inputY(2)-inputY(1),inputX(2)-inputX(1));
    thetaEndBackProj=atan2d(inputY(end-1)-inputY(end),inputX(end-1)-inputX(end));
    thetaEndForwardProj=atan2d(inputY(end)-inputY(end-1),inputX(end)-inputX(end-1));

    X1=R1*proportionalSpacing*cosd(theta0BackProj)+inputX(1);
    X3=R1*proportionalSpacing*cosd(theta0ForwardProj)+inputX(1);

    XEndM1=REnd*proportionalSpacing*cosd(thetaEndBackProj)+inputX(end);
    XEndP1=REnd*proportionalSpacing*cosd(thetaEndForwardProj)+inputX(end);

    Y1=R1*proportionalSpacing*sind(theta0BackProj)+inputY(1);
    Y3=R1*proportionalSpacing*sind(theta0ForwardProj)+inputY(1);

    YEndM1=REnd*proportionalSpacing*sind(thetaEndBackProj)+inputY(end);
    YEndP1=REnd*proportionalSpacing*sind(thetaEndForwardProj)+inputY(end);

    inputX=[X1;inputX(1);X3;inputX(2:end-1);XEndM1;inputX(end);XEndP1];
    inputY=[Y1;inputY(1);Y3;inputY(2:end-1);YEndM1;inputY(end);YEndP1];
    %Done

    %Now need to work out how to remove this data when outputting, do it after

    %Now loop through smoothing iterations (all other code is vectorised)
    oldXData=inputX;
    oldYData=inputY;
    for i=1:smoothingIterations
        newXData=zeros(2*length(oldXData)-1,1);
        newYData=zeros(2*length(oldYData)-1,1);
        oldDataIndices=1:2:length(newXData);
        newDataIndices=2:2:length(newXData)-1;
        newXData(oldDataIndices)=oldXData;
        newYData(oldDataIndices)=oldYData;

        thetaSegments01=atan2d(oldYData(2:end)-oldYData(1:end-1),oldXData(2:end)-oldXData(1:end-1));
        thetaSegments43=atan2d(oldYData(1:end-1)-oldYData(2:end),oldXData(1:end-1)-oldXData(2:end));

        thetaNodes01=[thetaSegments01(1);findCentreAngle(thetaSegments01(1:end-1),thetaSegments01(2:end),'Degrees');NaN];
        thetaNodes43=[NaN;findCentreAngle(thetaSegments43(1:end-1),thetaSegments43(2:end),'Degrees');thetaSegments43(end)];

        R=((oldYData(2:end)-oldYData(1:end-1)).^2+(oldXData(2:end)-oldXData(1:end-1)).^2).^0.5;

        CPX=(oldXData(2:end)+oldXData(1:end-1))/2;%Centre point
        CPY=(oldYData(2:end)+oldYData(1:end-1))/2;

        proj1X=(R/2).*cosd(thetaNodes01(1:end-1))+oldXData(1:end-1);
        proj1Y=(R/2).*sind(thetaNodes01(1:end-1))+oldYData(1:end-1);

        proj3X=(R/2).*cosd(thetaNodes43(2:end))+oldXData(2:end);
        proj3Y=(R/2).*sind(thetaNodes43(2:end))+oldYData(2:end);

        newXData(newDataIndices)=(curvatureParameter*CPX+proj1X+proj3X)/(2+curvatureParameter);
        newYData(newDataIndices)=(curvatureParameter*CPY+proj1Y+proj3Y)/(2+curvatureParameter);

        oldXData=newXData;
        oldYData=newYData;
        %if(i==1)
        %    save('Test')
        %end
    end
    %Done

    %Remove end fixing and output original part of data
    linearIndices=(1:length(newXData))';%Column vector
    startIndex=linearIndices(newXData==rawX(1)&newYData==rawY(1));
    endIndex=linearIndices(newXData==rawX(end)&newYData==rawY(end));
    %Done

    %Output data
    outputX=newXData(startIndex:endIndex);
    outputY=newYData(startIndex:endIndex);

    %Good, works well.
    
    %For the case without constrained ends see: 'discreteSmoothFit.m'
    
    %Functions previously contained in 'mathClass.m' but copied here to make it self sufficient.
    function [outputAngleArray]=findAngleBetweenTwoVectors(V1Matrix,V2Matrix,angleTypeString,signedAngle2DBool)
        %Supports 3D or 2D vectors
        %The input matrix must be of the form [x1,y1,z1;x2,y2,z2;etc] or [x1,y1;x2,y2; etc]
        %Also supports single vectors i.e. [x1,y1], but not [x1;y1]
        %angleTypeString='Degrees' or 'Radians'
        %signedAngle2DBool=true if the desired output is angle from A1 to A2.  Or false, if just the magnitude is needed.
        %Note: Right handed coordinate system is assumed for signed rotations in the xy plane.
        %I.e. Positive z vector is out of the page on a standard x(horizontal) y(vertical) plot.
        %So a positive z vector indicates a positive (counter clockwise) rotation. i.e. from theta=45degrees to theta=70degrees etc.

        %Check sizes
        if((signedAngle2DBool&&size(V1Matrix,2)~=2)||(signedAngle2DBool&&size(V2Matrix,2)~=2))
            error('Error in findAngleBetweenTwoVectors() input matrix dimensions dont match use of signedAngle2DBool');
        end
        if(size(V1Matrix,2)==2)
            V1Matrix(:,3)=0;
        end
        if(size(V2Matrix,2)==2)
            V2Matrix(:,3)=0;
        end
        if(size(V1Matrix,2)~=3||size(V2Matrix,2)~=3)
            error('Error in findAngleBetweenTwoVectors() check matrix sizes');
        end
        %Done

        %Compute cross product and value to define matrix sign.
        crossV1V2=cross(V1Matrix,V2Matrix,2);
        if(signedAngle2DBool)
            signMatrix=sign(crossV1V2(:,3));
            signMatrix(signMatrix==0)=1;%To handle co-linear vectors
        else
            signMatrix=ones(size(V1Matrix,1),1);
        end
        %Done

        %Now compute and output
        if(strcmp(angleTypeString,'Degrees'))
            outputAngleArray=atan2d(magnitude(crossV1V2,2),dot(V1Matrix,V2Matrix,2)).*signMatrix;
        elseif(strcmp(angleTypeString,'Radians'))
            outputAngleArray=atan2(magnitude(crossV1V2,2),dot(V1Matrix,V2Matrix,2)).*signMatrix;
        else
            error('Error in findAngleBetweenTwoVectors() unknown angle type');
        end
        %Done
    end
    function [outputAngleArray]=findAngleBetweenTwoAngles(A1Array,A2Array,angleTypeString,signedAngle2DBool)
        %Angle arrays are column vectors. I.e. [angle1;angle2;angle3 etc]
        %angleTypeString='Degrees' or 'Radians'
        %signedAngle2DBool=true if the desired output is angle from A1 to A2.  Or false, if just the magnitude is needed.

        %Check sizes
        if(size(A1Array,2)~=1||size(A2Array,2)~=1||size(A1Array,1)~=size(A2Array,1))
            error('Error in findAngleBetweenTwoAngles() check matrix sizes');
        end
        %Done

        %Generate vectors
        V1Matrix=zeros(size(A1Array,1),2);
        V2Matrix=zeros(size(A2Array,1),2);
        if(strcmp(angleTypeString,'Degrees'))
            V1Matrix(:,1)=1*cosd(A1Array);%x
            V1Matrix(:,2)=1*sind(A1Array);%y
            V2Matrix(:,1)=1*cosd(A2Array);%x
            V2Matrix(:,2)=1*sind(A2Array);%y
            outputAngleArray=findAngleBetweenTwoVectors(V1Matrix,V2Matrix,angleTypeString,signedAngle2DBool);
        elseif(strcmp(angleTypeString,'Radians'))
            V1Matrix(:,1)=1*cos(A1Array);%x
            V1Matrix(:,2)=1*sin(A1Array);%y
            V2Matrix(:,1)=1*cos(A2Array);%x
            V2Matrix(:,2)=1*sin(A2Array);%y
            outputAngleArray=findAngleBetweenTwoVectors(V1Matrix,V2Matrix,angleTypeString,signedAngle2DBool);
        else
            error('Error in findAngleBetweenTwoVectors() unknown angle type');
        end
        %Done
    end
    function [outputCentreAngle]=findCentreAngle(A1Array,A2Array,angleTypeString)
        %This used to be wrong. Redo it by finding the signed angle between two angles, then adding half of this to the first angle.
        %Angle arrays are column vectors. I.e. [angle1;angle2;angle3 etc]
        %angleTypeString='Degrees' or 'Radians'
        %signedAngle2DBool=true if the desired output is angle from D1 to D2.  Or false, if just the magnitude is needed.

        %Check sizes
        if(size(A1Array,2)~=1||size(A2Array,2)~=1||size(A1Array,1)~=size(A2Array,1))
            error('Error in findCentralAngle() check matrix sizes');
        end
        %Done

        %Find angular separation
        [signedAnglularSeparationArray]=findAngleBetweenTwoAngles(A1Array,A2Array,angleTypeString,true);
        %Done

        %Output central angle
        outputCentreAngle=A1Array+0.5*signedAnglularSeparationArray;
        %Done
    end
    function outputMatrix=magnitude(inputMatrix,dimension)
        %Output data
        outputMatrix=(sum(inputMatrix.^2,dimension)).^0.5;
        %Done
    end
end