function saveFiguresPNG(fullOutputDirectory)
%Another figure saving function

    %Check fullOutputDirectory
    if(fullOutputDirectory(end)~='/')
        fullOutputDirectory(end+1)='/';
    end
    %Done
    
    %Next make dir if it doesnt exist
    fullOutputDirectory=[fullOutputDirectory,datestr(now,'yyyymmddTHHMMSS'),'_Figures/'];
    if(~isdir(fullOutputDirectory))
        mkdir(fullOutputDirectory);
    end
    %Done
    
    %Get the figure handles
    figureHandles=findall(0,'Type','figure');
    %Done
    
    %Next cycle through all figure handles and export them
    for i=1:length(figureHandles)
        plotNumber=1+length(figureHandles)-i;%So they plot/save in the right order. (for some reason loading them loads them in reverse order)
        figure(figureHandles(i));
        set(figureHandles(i),'units','centimeters');
        outerPositionCM=get(figureHandles(i),'outerposition');
        set(figureHandles(i),'PaperUnits','centimeters');
        set(figureHandles(i),'PaperSize',[outerPositionCM(3),outerPositionCM(4)]);
        set(figureHandles(i),'PaperPosition',[0,0,outerPositionCM(3),outerPositionCM(4)]);
        %Done

        %Check an axis exists
        if(~isempty(findobj(gcf,'type','axes')))
            %Code for saving all individual ones
            disp(['Exporting individual figure ',num2str(i),' of ',num2str(length(figureHandles))]);
            saveNameIndividualPNG=[fullOutputDirectory,'Fig_',num2str(plotNumber),'.png'];
            print(gcf, '-dpng', saveNameIndividualPNG,'-r300');%Also tried 600dpi but not worth it for the filesize/time vs improvement 
            %Arghhh, matlab figure saving with white space etc.
            trimWhiteSpacePNG(saveNameIndividualPNG);
            %This fixes it well.
        end
        close(figureHandles(i));
    end
    %Done

    disp('All figures exported');
    %Works well! :)
    
    
    %Pull trimWhiteSpacePNG() out of printClass.
    function trimWhiteSpacePNG(saveNameIndividualPNG)
        %Function to circumvent matlabs stupid white space on saved figures.

        I=imread(saveNameIndividualPNG);
        notWhiteSpace=(I(:,:,1)~=255)|(I(:,:,2)~=255)|(I(:,:,3)~=255);

        topLimit=find(any(notWhiteSpace,2),1,'first');
        bottomLimit=find(any(notWhiteSpace,2),1,'last');
        leftLimit=find(any(notWhiteSpace,1),1,'first');
        rightLimit=find(any(notWhiteSpace,1),1,'last');

        crispyFigure=I(topLimit:bottomLimit,leftLimit:rightLimit,:);
        imwrite(crispyFigure,saveNameIndividualPNG);
        %Works well
    end
end