%% Script to extract frames from a video
%{
Overview:
1st Version:
Choose a video to process
Choose how much of the video to process
Choose the frame interval
Choose the directory to save frames
Run

Behind the scenes:
Opens video.
Extracts frames with known temporal spacing.

Future Version Updrades to do:
May be useful to output the timestamp of the frame in the image filename.
Frame overlap percentage
Check for blurry frames
Check for key frames
Improve image quality
Checks for bad GPS data? Bathymetry is dodgy?
Remove particles, laser beams and other bright spots that are not fixed to the bed.
%}

%% Initialise
clear all;
close all;
%profile on;
previewVideoBool=false;
imageTypeSuffix='.png';%Can also use .jpg or .tif

%Load video
lastDir=[pwd(),'\'];
disp('Select video to open');
[videoFilename, videoPathname] = uigetfile([lastDir,'*.*'],'Select video to open');
lastDir=videoPathname;
%Done

%Select output folder
disp('Select or create output directory');
[outputPathname] = uigetdir(lastDir,'Select or create output directory');
outputPathname=[outputPathname,'\'];
lastDir=outputPathname;
%Done

%% Load video
%videoInfo=mmfileinfo([videoPathname,videoFilename]);
videoObject=VideoReader([videoPathname,videoFilename]);
%Done

%% Get user input of frame rate, start time and end time, then extract frames
videoStartTime=videoObject.CurrentTime;
videoEndTime=videoObject.Duration;
minFPS=2/videoEndTime;
maxFPS=videoObject.FrameRate;

%Get FPS
disp([char(10),'Get FPS']);
extractionFPS=0;
while((extractionFPS<minFPS)||(extractionFPS>maxFPS))
    extractionFPS=str2double(input([char(10),'Type extraction FPS between ',num2str(minFPS),' and ',num2str(maxFPS),char(10)],'s'));
end
%Done

%Get extraction times
disp('Get extraction times');
reply='empty';
while(~any(strcmp(reply,{'Y','N','y','n'})))
    reply=input([char(10),'Extract frames from entire video? Type: Y or N',char(10)],'s');
end
if(any(strcmp(reply,{'Y','y'})))
    extractionStartTime=videoStartTime;
    extractionEndTime=videoEndTime;
else
    extractionStartTime=videoStartTime-1;
    extractionEndTime=videoEndTime+1;
    while((extractionStartTime<videoStartTime)||(extractionStartTime>videoEndTime))
        extractionStartTime=str2double(input([char(10),'Type extraction start time between ',num2str(videoStartTime),' and ',num2str(videoEndTime),char(10)],'s'));
    end
    while((extractionEndTime<extractionStartTime)||extractionEndTime>videoEndTime)
        extractionEndTime=str2double(input([char(10),'Type extraction end time between ',num2str(extractionStartTime),' and ',num2str(videoEndTime),char(10)],'s'));
    end
end
%Done

%% Extract frames
%Loop through all frames within the section of video wanted.
wantedExtractionTimes=(extractionStartTime:(1/extractionFPS):extractionEndTime)';
actualExtractionTimes=zeros(size(wantedExtractionTimes));
dotIndex=strfind(videoFilename,'.');
imageNamePrefix=videoFilename(1:dotIndex(1)-1);
timeToStartVideo=wantedExtractionTimes(1)-2;%Start the video 2 seconds before to ensure clean
if(timeToStartVideo<videoStartTime)
    timeToStartVideo=videoStartTime;
end
timeToEndVideo=wantedExtractionTimes(end)+1;%End the video 1 seconds later to ensure clean
if(timeToEndVideo>videoEndTime)
    timeToEndVideo=videoEndTime;
end
numFramesToLoop=(timeToEndVideo-timeToStartVideo)*videoObject.FrameRate;%Check in seconds.
numFramesToSave=length(wantedExtractionTimes);
savedFrameCounter=1;
videoObject.CurrentTime=timeToStartVideo;
newTempFrame=zeros(videoObject.Height,videoObject.Width,3,'uint8');
oldTempFrame=zeros(videoObject.Height,videoObject.Width,3,'uint8');
newCurrentTime=0;
oldCurrentTime=0;
fileNamesCellStr=cell(numFramesToSave,1);
%Note: Will find the next closest frame to the desired extraction time, so also save the actualExtractionTimes

for i=1:numFramesToLoop
    %Get frame and extraction time
    newTempFrame=readFrame(videoObject);
    %Read point in file should be: wantedExtractionTimes(i) -> rounded up to nearest frame -> frame gets read -> videoObject.CurrentTime moves to the next frame   [So need to take the Current time and deduct the time for 1 frame]
    newCurrentTime=videoObject.CurrentTime-(1/videoObject.FrameRate);
    %Done
    
    %Preview frame
    if(previewVideoBool)
        warning('off','images:initSize:adjustingMag');
        imshow(newTempFrame);
        title(num2str(newCurrentTime));
        pause(1/videoObject.FrameRate);%For smooth video viewing
    end
    %Done
    
    %Next compare wanted extraction times with the current and previous frame times
    %Also that there are frames left to save.
    %Extracted frame times will fall between the previous and current times. 
    if(savedFrameCounter<=numFramesToSave)
        if((wantedExtractionTimes(savedFrameCounter)>oldCurrentTime)&&(wantedExtractionTimes(savedFrameCounter)<newCurrentTime))
            saveFileName=[outputPathname,imageNamePrefix,'_',sprintf('%0.6d',savedFrameCounter),imageTypeSuffix];
            fileNamesCellStr{i}=saveFileName;
            %Then find closest out of previous frame and current frame.
            if(abs(wantedExtractionTimes(savedFrameCounter)-oldCurrentTime)<abs(wantedExtractionTimes(savedFrameCounter)-newCurrentTime))
                actualExtractionTimes(savedFrameCounter)=oldCurrentTime;
                imwrite(oldTempFrame,saveFileName);
                disp(['Saved image ',saveFileName]);
            else
                actualExtractionTimes(savedFrameCounter)=newCurrentTime;
                imwrite(newTempFrame,saveFileName);
                disp(['Saved image ',saveFileName]);
            end
            savedFrameCounter=savedFrameCounter+1;
        end
    end
    %Done
    
    %Copy new data to old data
    oldTempFrame=newTempFrame;
	oldCurrentTime=newCurrentTime;
    %Done
end
%Done, works well.

%profile viewer