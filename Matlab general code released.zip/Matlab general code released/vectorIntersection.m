function [intersectionsX,intersectionsY,intersectionsToP1Distance,intersectionsToP2Distance]=vectorIntersection(vec1X,vec1Y,vec1u,vec1v,vec2X,vec2Y,vec2u,vec2v)
    %Function to find where vectors intersect.
    
    %Check all input vars are column arrays and not cells.
    if(iscell(vec1X)||iscell(vec1Y)||iscell(vec1u)||iscell(vec1v)||iscell(vec2X)||iscell(vec2Y)||iscell(vec2u)||iscell(vec2v))
        error('Error in vectorIntersection() input was of type cell');
    end
    if(~iscolumn(vec1X)||~iscolumn(vec1Y)||~iscolumn(vec1u)||~iscolumn(vec1v)||~iscolumn(vec2X)||~iscolumn(vec2Y)||~iscolumn(vec2u)||~iscolumn(vec2v))
        error('Error in vectorIntersection() input was not a column array');
    end
    nPairs=length(vec1X);
    lengthCheck=[length(vec1X),length(vec1Y),length(vec1u),length(vec1v),length(vec2X),length(vec2Y),length(vec2u),length(vec2v)];
    if(any(lengthCheck~=nPairs))
        error('Error in vectorIntersection() input column array lengths are not equal');
    end
    %Done
    
    %Make the line equations, where m comes from the vectors
    %(y-y1)=m(x-x1)
    %m=(dv/du)
    %y=mx+c (c=y1-m*x1)
    m1=vec1v./vec1u;
    c1=vec1Y-m1.*vec1X;
    m2=vec2v./vec2u;
    c2=vec2Y-m2.*vec2X;
    %Done

    %Solve line equations for intersections
    %yI=m1*.xI+c1=m2*.xI+c2
    %m1*.xI-m2*.xI=c2-c1
    %(m1-m2)*.xI=(c2-c1)
    %xI=(c2-c1)./(m1-m2)
    intersectionsX=(c2-c1)./(m1-m2);%Parallel lines will return inf.
    intersectionsY=m1.*intersectionsX+c1;
    intersectionsToP1Distance=((intersectionsX-vec1X).^2+(intersectionsY-vec1Y).^2).^0.5;
    intersectionsToP2Distance=((intersectionsX-vec2X).^2+(intersectionsY-vec2Y).^2).^0.5;
    %Done
end