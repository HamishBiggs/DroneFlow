%DroneFlow Camera Class for stereo camera data.

classdef DF_Cam
    properties
        %Lens parameters
        lens_mm;
        %Done
        
        %Intrinsic parameters for primary and secondary cameras from stereo calibration
        stereoParams;
        %Done
        
        %Estimation errors for intrinsics for primary and secondary cameras (should be less than 1 pixel mean error)
        estimationErrors;
        %Done
        
        %Images pairs used for calibration
        primaryCameraCalibrationImageFilenamesAndPaths;
        secondaryCameraCalibrationImageFilenamesAndPaths;
        %Done
        
        %Image pairs to process
        primaryCameraFilenames;
        primaryCameraFilePath;
        secondaryCameraFilenames;
        secondaryCameraFilePath;
        %Done
    end
    methods(Static)
        function [primaryCameraFilenames,primaryCameraFilePath,secondaryCameraFilenames,secondaryCameraFilePath]=selectStereoImages()
            % Select stereo images to process
            
            %Select primary images
            global lastInputPathname; %#ok<*NUSED>
            if(isempty(lastInputPathname))
                lastInputPathname='O:\END19505\Working\Hardware\Stereoscopic camera\Calibration\';
            end
            [primaryCameraFilenames,primaryCameraFilePath]=selectInputImages('Select images from primary camera to process');
            lastInputPathname=primaryCameraFilePath;
            nImagePairs=length(primaryCameraFilenames);
            %Done

            %Select secondary images
            [secondaryCameraFilenames,secondaryCameraFilePath]=selectInputImages('Select images from secondary camera to process');
            lastInputPathname=secondaryCameraFilePath;
            if(length(secondaryCameraFilenames)~=nImagePairs)
                error('Error in DF_Cam.selectStereoImages() number of primary images not equal to number of secondary images');
            end
            %Done

            %% Get image numbers and compare to ensure all the pairs are the same
            %Expected format: DF_PRIMARY_00414.tiff or DF_PRIMARY_00414.jpg
            imageNumsPrimary=zeros(nImagePairs,1);
            imageNumsSecondary=zeros(nImagePairs,1);
            for i=1:nImagePairs
                primaryUnderscores=strfind(primaryCameraFilenames{i},'_');
                secondaryUnderscores=strfind(secondaryCameraFilenames{i},'_');
                imageNumsPrimary(i)=str2double(primaryCameraFilenames{i}(primaryUnderscores(end)+1:primaryUnderscores(end)+5));
                imageNumsSecondary(i)=str2double(secondaryCameraFilenames{i}(secondaryUnderscores(end)+1:secondaryUnderscores(end)+5));
            end
            if(sum(imageNumsPrimary==imageNumsSecondary)~=nImagePairs)
                error('Error in DF_Cam.selectStereoImages() image pairs do not correspond, function designed to select all corresponding image pairs. Redesign function if internal pair matching wanted.');
            end
            %Done
            
            %Subfunction to clean up image selection
            function [filenamesOfImages,pathnameOfImages]=selectInputImages(selectImageString)
                %global lastInputPathname;%Retain directory locations for faster processing of multiple folders.

                if isempty(lastInputPathname) 
                    % First time calling 'uigetfile', use the pwd
                    [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                    selectImageString, ...
                    'MultiSelect', 'on');
                    lastInputPathname=pathnameOfImages;
                else
                    %Repeated call to 'uigetfile', start at the same directory as last selection
                    [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                    selectImageString, ...
                    'MultiSelect', 'on',lastInputPathname);
                    lastInputPathname=pathnameOfImages;
                end
                if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
                    filenamesOfImages={filenamesOfImages};
                end
                %Done
            end
        end
        function preProcessRaw(searchStartPath,imageWidth,imageHeight)
            % This function converts raw images to .tiff and saves in folders for the two cameras
            % Based on the filename convention of Drone-Flow-1-PRIMARY-61332817080-1005.RAW
            % For no inputs call as: DF_Cam.preProcessRaw([],[],[])

            %Select images
            if isempty(searchStartPath) 
                % First time calling 'uigetfile', use the pwd
                [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                'Select .RAW images to process', ...
                'MultiSelect', 'on');
            else
                %Repeated call to 'uigetfile', start at the same directory as last selection
                [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                'Select .RAW images to process', ...
                'MultiSelect', 'on',searchStartPath);
            end
            if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
                filenamesOfImages={filenamesOfImages};
            end
            %Done
            nImages=length(filenamesOfImages);
            %Done

            %Get the size of the images
            %Width = 2448, Height = 2048, File header size = 0, 24 Bytes per pixel, Colour order RGB, Interleaved RGB
            if(isempty(imageWidth))
                imWidth=2448;
            else
                imWidth=imageWidth;
            end
            if(isempty(imageHeight))
                imHeight=2048;
            else
                imHeight=imageHeight;
            end
            %Done

            %Make output directories
            outputPathnamePrimary=[pathnameOfImages,'PRIMARY\'];
            if(~isfolder(outputPathnamePrimary))
                mkdir(outputPathnamePrimary);
            end
            outputPathnameSecondary=[pathnameOfImages,'SECONDARY\'];
            if(~isfolder(outputPathnameSecondary))
                mkdir(outputPathnameSecondary);
            end
            %Done

            %Loop through images and reformat
            for i=1:nImages
                disp(['Processing image ',num2str(i),' of ',num2str(nImages)]);
                %Open raw data and structure it
                fid = fopen([pathnameOfImages,filenamesOfImages{i}],'r');
                if(fid == -1)
                  error('Cannot open file: %s', FileName);
                end
                rawData = uint8(fread(fid,imWidth*imHeight*3,'uint8'));
                fclose(fid);
                rgbImage = uint8(zeros(imWidth,imHeight,3));
                rgbImage(:,:,1)=reshape(rawData([1:3:length(rawData)]),[imWidth,imHeight,1]);
                rgbImage(:,:,2)=reshape(rawData([2:3:length(rawData)]),[imWidth,imHeight,1]);
                rgbImage(:,:,3)=reshape(rawData([3:3:length(rawData)]),[imWidth,imHeight,1]);
                rgbImage=fliplr(imrotate(rgbImage,-90));
                %Done
                
                %Template input filename: Drone-Flow-1-PRIMARY-61332817080-1005.RAW
                
                %Parse file names with - or . separators between fields
                dashIndices=strfind(filenamesOfImages{i},'-')';
                dotIndices=strfind(filenamesOfImages{i},'.')';
                endIndices=[0;length(filenamesOfImages{i})+1];
                fieldIndices=sort([dashIndices;dotIndices;endIndices]);
                nFields=length(fieldIndices)-1;
                filenameFields=cell(nFields,1);
                fCounter=1;
                while(fCounter<=nFields)
                    filenameFields{fCounter}=filenamesOfImages{i}(fieldIndices(fCounter)+1:fieldIndices(fCounter+1)-1);
                    fCounter=fCounter+1;
                end
                %expectedFields={'Drone';'Flow';'imageNumber';'CameraString';'ImageSaveTime';'ShutterTime';'ImageType'};
                %                   1       2        3               4              5              6            7
                %Done
                
                %Check number of fields
                if(~contains(filenamesOfImages{i},'Drone-Flow-'))
                    error(['Error in preProcessRaw unexpected file format of ',filenamesOfImages{i}]);
                elseif(nFields~=7)
                    warning(['Warning in in preProcessRaw unexpected file format of ',filenamesOfImages{i},' expected file format of type Drone-Flow-1-PRIMARY-61332817080-1005.RAW with 7 fields separated by - or .']);
                end
                %Done
                
                %Select output directory
                if(contains(filenamesOfImages{i},'PRIMARY'))
                    outputPathname=outputPathnamePrimary;
                elseif(contains(filenamesOfImages{i},'SECONDARY'))
                    outputPathname=outputPathnameSecondary;
                else
                    error(['Error in preProcessRaw unexpected file format of ',filenamesOfImages{i},' expected file format of type Drone-Flow-1-PRIMARY-61332817080-1005.RAW including PRIMARY or SECONDARY designators']);
                end
                %Done
                
                %Save images and data tags as .tiff, for clean PIV.
                %Output filename format 'DF_PRIMARY_00001.tiff'
                outputFilename=['DF_',filenameFields{4},'_',sprintf('%05d',str2double(filenameFields{3})),'.tiff'];%Correct for updated filenames
                imageDescription=['cameraString,',filenameFields{3},',imageNumber,',sprintf('%05d',str2double(filenameFields{4})),',imageSaveTime,',filenameFields{5},',shutterTime,',filenameFields{6},',originalFilename,',filenamesOfImages{i}];
                imwrite(rgbImage,[outputPathname,outputFilename],'Compression','lzw','Description',imageDescription);
                %'Compression': 'packbits' (default for nonbinary images) 'none' 'lzw' 'deflate' 'jpeg' 'ccitt' (binary images only, and the default for such images) 'fax3' (binary images only) 'fax4' (binary images only)
                %'jpeg' is a lossy compression scheme; other compression modes are lossless. Also, if you specify 'jpeg' compression, you must specify the 'RowsPerStrip' parameter and the value must be a multiple of 8.
                %Example: 'Compression','none'
                %Tiff packbits provides almost no size saving from raw. Tiff LZW (apparently most common) saves around 30% of size. .jpg at 100% quality is pretty good. Down to 2MB ish. :)
                %Done
            end
            %Done, works well.
        end
        function [outputImage,maskOfTracers]=filterRedTracers(inputImage)
            %This function masks non tracers, while tracers remain in RGB
            
            % Convert RGB image to HSV
            hsvImage=rgb2hsv(inputImage(:,:,1:3));

            % Define thresholds for hue based on histogram settings
            hueMin=0.95;
            hueMax=0.05;

            % Define thresholds for saturation based on histogram settings
            saturationMin=0.3;
            saturationMax=1.000;

            % Define thresholds for value based on histogram settings
            valueMin=0.01;
            valueMax=1.000;

            % Create mask based on chosen histogram thresholds
            maskOfTracers=((hsvImage(:,:,1)>=hueMin)|(hsvImage(:,:,1)<=hueMax)) & ...
                            (hsvImage(:,:,2)>=saturationMin)&(hsvImage(:,:,2)<=saturationMax) & ...
                            (hsvImage(:,:,3)>=valueMin)&(hsvImage(:,:,3)<=valueMax);
            
            % Initialize output masked image based on input image.
            outputImage=inputImage;
            outputImage(repmat(~maskOfTracers,[1, 1, size(outputImage,3)])) = 0;
            %Done
        end
    end
end           
        