function [xShift,yShift,crossCorrelationOutput]=getImageShiftMono(baseImage,shiftedImage,maxXShift,maxYShift)
    %Original was very slow!
    %Sped up version thanks to xcorr2_fft() from Alessandro Masullo (https://www.mathworks.com/matlabcentral/fileexchange/53570-xcorr2_fft-a-b)
    %Safety checks
    
    if((size(baseImage,3)~=1)||(size(shiftedImage,3)~=1))
        error('Error in getImageShiftMono() not designed for multilayer (e.g. RGB) images');
    end
    if((size(baseImage,1)~=size(shiftedImage,1))||(size(baseImage,2)~=size(shiftedImage,2)))
        error('Error in getImageShiftMono() not designed for images of two sizes');
    end
    %Done
    
    %Initialise shifted image
    baseImage=double(baseImage);
    shiftedImage=double(shiftedImage);
    xShiftVector=-maxXShift:maxXShift;
    yShiftVector=(-maxYShift:maxYShift)';
    xShiftMatrix=ones(length(yShiftVector),1)*xShiftVector;
    yShiftMatrix=yShiftVector*ones(1,length(xShiftVector));
    croppedShiftedImage=shiftedImage((maxYShift+1):(end-maxYShift),(maxXShift+1):(end-maxXShift));
    %Done
    
    %Perform xcorr2 on the whole images.
    %cc = xcorr2(baseImage,croppedShiftedImage);%Still so slow. 300 seconds + for only 6 images
    cc = xcorr2_fft(baseImage,croppedShiftedImage);%Wow!!! This is lightning fast. Alessandro is a legend! 2.44 seconds for 6 images. Wohooo!
    crossCorrelationResult=cc((round(size(cc,1)/2)-maxYShift):(round(size(cc,1)/2)+maxYShift),(round(size(cc,2)/2)-maxXShift):(round(size(cc,2)/2)+maxXShift));
    %Done    
    
    %Get the correlation peak
    [~,linearIndex]=max(crossCorrelationResult,[],'all','linear','omitnan');
    xShift=xShiftMatrix(linearIndex);
    yShift=yShiftMatrix(linearIndex);
    crossCorrelationOutput=crossCorrelationResult;
    %Done
end