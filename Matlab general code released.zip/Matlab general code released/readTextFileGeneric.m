function outputCellMatrix=readTextFileGeneric(inputFilename,delimiter,removeConsecutiveDelimitersBool)
    %Read whole file into a cell column array
    fileID=fopen(inputFilename,'r');
    allDataCol=textscan(fileID,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
    allDataCol=allDataCol{1};%Unpack it
    fclose(fileID);
    %Done
    
    %Now need to find the row with most delimiters (also check for empty rows)
    maxDelims=0;
    emptyRows=false(size(allDataCol));
    for i=1:length(allDataCol)
        delimLocations=strfind(allDataCol{i},delimiter);%Gives indices in the string where the delimiter is
        
        %Some files might have multiple connected delims which could be a headache, so combine them.
        if(removeConsecutiveDelimitersBool&&(length(delimLocations)>1))
            %Check if delims are adjacent
            adjacentDelimsBool=[false,(delimLocations(2:end)-delimLocations(1:end-1))==1];
            %Done
            
            %Then if any are adjacent fix them
            if(sum(adjacentDelimsBool)>0)
                %Get the indices of the adjacent delims
                adjacentDelimsIndices=delimLocations(adjacentDelimsBool);
                %Done
                
                %Get the good chars and fix
                goodChars=true(1,length(allDataCol{i}));
                goodChars(adjacentDelimsIndices)=0;
                allDataCol{i}=allDataCol{i}(goodChars); 
                %Done
                
                %Update the delimLocations
                delimLocations=strfind(allDataCol{i},delimiter);%Gives indices in the string where the delimiter is
                %Done
            end
            %Done
        elseif(isempty(allDataCol{i}))%If there is not more than 1 delimeter, then also check whether there is any data in that row. E.g. no delimeters and no data
            emptyRows(i)=true;
        end
        %Done
        
        %Next count how many delims in the line and update maxDelims if larger
        if(length(delimLocations)>maxDelims)
            maxDelims=length(delimLocations);
        end
        %Done
    end
    %Done
    
    %Remove empty rows
    allDataCol=allDataCol(~emptyRows);
    %Done
    
    %Next initialise the cell matrix
    tempCellMatrix=cell(length(allDataCol),maxDelims);
    %Done
    
    %Now loop through and populate the cells
    for i=1:length(allDataCol)
        %Find delim locations for the text row
        delimLocations=strfind(allDataCol{i},delimiter);
        %Done
        
        %Check there are delims for the row. Move whole row if not.
        if(isempty(delimLocations))
            tempCellMatrix{i,1}=allDataCol{i};
        else
            %Now loop through and move all the contents    
            %Think dynamic loops dont work, so use while
            loopCounter=1;
            numCells=length(delimLocations)+1;
            while(loopCounter<=numCells)
                if(loopCounter==1)
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(1:delimLocations(1)-1);
                elseif(loopCounter==numCells)
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(delimLocations(end)+1:end);
                else
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(delimLocations(loopCounter-1)+1:delimLocations(loopCounter)-1);
                end
                loopCounter=loopCounter+1;
            end
            %Done
        end
        %Done
    end
    %Done
    
    %Output data
    outputCellMatrix=tempCellMatrix;
    %Done

    %Works well! The consecutive delim removal also works well. :)
end