%% checkGCPLocations.m
%{
Useful to visualise the locations of GCPs in imagery and real world coordinates. Useful to check for errors or outliers. Or incorrect surveying and assignment of indices.
%}

clear all;
close all;

%Options
viewPoints=true;
viewGCPLocations=true;
%Done

%Select input video
disp('Select video to check GCP locations');
[inputVideoFilename,inputVideoPathname] = uigetfile([getPreviousDir(),'*.*'],'Select video to check GCP locations','MultiSelect','off');
writeCurrentDir(inputVideoPathname);%Remember last used directory for loading more videos
%Done

%Select input GCP file
disp('Select GCP file. Match the formatting of a HydroSTIV input file');
[inputGCPFilename,inputGCPPathname] = uigetfile([inputVideoPathname,'*.*'],'Select GCP file with HydroSTIV formatting','MultiSelect','off');
%Done

%% Load GCP file
GCPFile.('CellMatrix')=readTextFileGeneric([inputGCPPathname,inputGCPFilename],',',0);
GCPFile.('GCPNames')=GCPFile.CellMatrix(2:end,1);
GCPFile.('Easting')=str2double(GCPFile.CellMatrix(2:end,2));
GCPFile.('Northing')=str2double(GCPFile.CellMatrix(2:end,3));
GCPFile.('Elevation')=str2double(GCPFile.CellMatrix(2:end,4));
GCPFile.('xPix')=str2double(GCPFile.CellMatrix(2:end,5));
GCPFile.('yPix')=str2double(GCPFile.CellMatrix(2:end,6));
nPoints=length(GCPFile.GCPNames);
labelDX=10;
labelDY=0;
labelDX_m=0.2;
labelDY_m=0;
labelDZ_m=0;
labelPointsFontSize=20;
labelGCPsFontSize=18;
%Done

%% Load Video and Open Save File
hVideoSrc=vision.VideoFileReader([inputVideoPathname,inputVideoFilename]);
videoInfo=info(hVideoSrc);
%Done

%Get first Image
colorImgA=step(hVideoSrc);
% Try to Convert to Grayscale
try
    imgA=rgb2gray(colorImgA);
    RGB=true;
catch % Image is not RGB
    imgA=colorImgA;
    RGB=false;
end
%Done

%Show GCPs on image
if(viewPoints)
    figHandlePoints=figure();
    imshow(colorImgA);
    hold on;
    scatter(GCPFile.xPix,GCPFile.yPix,91,'r','x');
    for i=1:nPoints
        text(GCPFile.xPix(i)+labelDX,GCPFile.yPix(i)+labelDY,GCPFile.GCPNames{i},'Fontsize',labelPointsFontSize);
    end 
    hold off;
    title('GCP locations');
    genericFigureScaling();
end
%Done

%Show GCP Locations
if(viewGCPLocations)
    figHandleGCPLocations=figure();
    hold on;
    scatter3(GCPFile.Easting,GCPFile.Northing,GCPFile.Elevation,121,'r','x');
    for i=1:nPoints
        text(GCPFile.Easting(i)+labelDX_m,GCPFile.Northing(i)+labelDY_m,GCPFile.Elevation(i)+labelDZ_m,GCPFile.GCPNames{i},'Fontsize',labelGCPsFontSize);
    end 
    hold off;
    xlabel('Easting (m)');
    ylabel('Northing (m)');
    zlabel('Elevation (m)');
    title('GCP locations');
    genericFigureScaling();
end
%Done

%Close the video
release(hVideoSrc);
%Done

function lastDir=getPreviousDir()
    %Function to read the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    scriptNameAndPath=mfilename('fullpath');
    slashIndices=strfind(scriptNameAndPath,'\');
    scriptPath=scriptNameAndPath(1:slashIndices(end));
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'r');%Will open the file for reading if it exists
    if(fHandle==-1)
        lastDir=pwd;
    else
        allData=textscan(fHandle,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
        fclose(fHandle);
        if(iscell(allData))
            allData=allData{1};%Unpack it
        end
        if(iscell(allData))
            allData=allData{1};%Unpack it twice sometimes needed...
        end
        if(contains(allData,'\'))
            slashIndices=strfind(allData,'\');
            tempPath=allData(1:slashIndices(end));
            if(isfolder(tempPath))
                lastDir=tempPath;
            else
                lastDir=pwd;
            end            
        else
            lastDir=pwd;
        end
        %Done
    end
    %Done
end

function writeCurrentDir(currentDir)
    %Function to record the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    scriptNameAndPath=matlab.desktop.editor.getActiveFilename;
    slashIndices=strfind(scriptNameAndPath,'\');
    scriptPath=scriptNameAndPath(1:slashIndices(end));
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        warning(['Could not write the last used directory to ',[scriptPath,nameOfStorageFile],' please check this file isn''t already open or similar']);
    else
        fprintf(fHandle,'%s',currentDir);
        fclose(fHandle);
    end
    %Done
end

function outputCellMatrix=readTextFileGeneric(inputFilename,delimiter,removeConsecutiveDelimitersBool)
    %Read whole file into a cell column array
    fileID=fopen(inputFilename,'r');
    allDataCol=textscan(fileID,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
    allDataCol=allDataCol{1};%Unpack it
    fclose(fileID);
    %Done
    
    %Now need to find the row with most delimiters (also check for empty rows)
    maxDelims=0;
    emptyRows=false(size(allDataCol));
    for i=1:length(allDataCol)
        delimLocations=strfind(allDataCol{i},delimiter);%Gives indices in the string where the delimiter is
        
        %Some files might have multiple connected delims which could be a headache, so combine them.
        if(removeConsecutiveDelimitersBool&&(length(delimLocations)>1))
            %Check if delims are adjacent
            adjacentDelimsBool=[false,(delimLocations(2:end)-delimLocations(1:end-1))==1];
            %Done
            
            %Then if any are adjacent fix them
            if(sum(adjacentDelimsBool)>0)
                %Get the indices of the adjacent delims
                adjacentDelimsIndices=delimLocations(adjacentDelimsBool);
                %Done
                
                %Get the good chars and fix
                goodChars=true(1,length(allDataCol{i}));
                goodChars(adjacentDelimsIndices)=0;
                allDataCol{i}=allDataCol{i}(goodChars); 
                %Done
                
                %Update the delimLocations
                delimLocations=strfind(allDataCol{i},delimiter);%Gives indices in the string where the delimiter is
                %Done
            end
            %Done
        elseif(isempty(allDataCol{i}))%If there is not more than 1 delimeter, then also check whether there is any data in that row. E.g. no delimeters and no data
            emptyRows(i)=true;
        end
        %Done
        
        %Next count how many delims in the line and update maxDelims if larger
        if(length(delimLocations)>maxDelims)
            maxDelims=length(delimLocations);
        end
        %Done
    end
    %Done
    
    %Remove empty rows
    allDataCol=allDataCol(~emptyRows);
    %Done
    
    %Next initialise the cell matrix
    tempCellMatrix=cell(length(allDataCol),maxDelims);
    %Done
    
    %Now loop through and populate the cells
    for i=1:length(allDataCol)
        %Find delim locations for the text row
        delimLocations=strfind(allDataCol{i},delimiter);
        %Done
        
        %Check there are delims for the row. Move whole row if not.
        if(isempty(delimLocations))
            tempCellMatrix{i,1}=allDataCol{i};
        else
            %Now loop through and move all the contents    
            loopCounter=1;
            numCells=length(delimLocations)+1;
            while(loopCounter<=numCells)
                if(loopCounter==1)
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(1:delimLocations(1)-1);
                elseif(loopCounter==numCells)
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(delimLocations(end)+1:end);
                else
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(delimLocations(loopCounter-1)+1:delimLocations(loopCounter)-1);
                end
                loopCounter=loopCounter+1;
            end
            %Done
        end
        %Done
    end
    %Done
    
    %Output data
    outputCellMatrix=tempCellMatrix;
    %Done
end
