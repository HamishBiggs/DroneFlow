function fixFileNumbering()
    %% First, select all files to fix.
    global lastPathnameOfFiles %Retain directory locations for faster processing of multiple folders.
    if isempty(lastPathnameOfFiles) 
        % First time calling 'uigetfile', use the pwd
        [filenamesToFix,pathnameToFix] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all files to fix naming', ...
        'MultiSelect', 'on');
        lastPathnameOfFiles=pathnameToFix;
    else
        %Repeated call to 'uigetfile', start at the same directory as last selection
        [filenamesToFix,pathnameToFix] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all files to fix naming', ...
        'MultiSelect', 'on',lastPathnameOfFiles);
        lastPathnameOfFiles=pathnameToFix;
    end
    if(~iscell(filenamesToFix))%If only one file is selected it returns a char array not a cell. So place inside a cell.
        filenamesToFix={filenamesToFix};
    end
    %Done
    
    %Next select number string that needs fixing by obtaining the indices of start and finish of the number string.
    numString='';
    for i=1:length(filenamesToFix{1})
        numString=[numString,filenamesToFix{1}(i),'[',num2str(i),']'];
    end
    startExplanationString = ['Type start index of number field ',numString,'\n'];%Easier just to get the user to choose the start and finish indices
    startIndex=input(startExplanationString);
    finishExplanationString = ['Type finish index of number field ',numString,'\n'];%Easier just to get the user to choose the start and finish indices
    finishIndex=input(finishExplanationString);
    %Done
    
    %Next define equation how to fix it.
    %{
        E.g. Image_00202.jpg
        y=(x+1000)
        And selecting 6 output chars
        Becomes Image_001202.jpg
    %}
   	equationsExplanationString='Type an equation of the form y=(x+1000) where y is the fixed number and x is the original number.\n';
    equationString=input(equationsExplanationString,'s');
    %Done

    %Next define the number of characters for the fixed number string
    numCharsExplanationString='Type the number of chars for the output number (which is padded with leading zeros).\n';
    numCharsString=input(numCharsExplanationString,'s');
    %Done
    
    %Now fix them! :)
    nFiles=length(filenamesToFix);
    for i=1:nFiles
        x=str2double(filenamesToFix{i}(startIndex:finishIndex));
        y=eval(equationString(3:end));
        yPaddedString=sprintf(['%0',num2str(numCharsString),'d'],y);
        if(startIndex==1)%Note: Filenames assumed to include extensions. Add more options if for some reason this is not the case.
            newFileName=[yPaddedString,filenamesToFix{i}(finishIndex+1:end)];
        else
            newFileName=[filenamesToFix{i}(1:startIndex-1),yPaddedString,filenamesToFix{i}(finishIndex+1:end)];
        end
        movefile([pathnameToFix,filenamesToFix{i}],[pathnameToFix,newFileName]);
    end
    %Done
    disp('Done');
end