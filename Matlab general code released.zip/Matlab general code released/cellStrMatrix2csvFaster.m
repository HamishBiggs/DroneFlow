function cellStrMatrix2csvFaster(outputFullFileName,cellStrMatrix,delimiter)
    %Clean up output of text from matlab
    
    %Initialise
    fHandle=fopen(outputFullFileName, 'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        error(['Error in cellStrMatrix2csvFaster(), could not open or create the file ',outputFullFileName,' check it isn''t already open or similar']);
    end
    cellArrayHeight=size(cellStrMatrix, 1);
    cellArrayWidth=size(cellStrMatrix, 2);
    %Done
    
    %Loop and build char string
    inputSize=whos('cellStrMatrix');
    delimLength=length(delimiter);
    nlLength=length(char(10));
    temp=char(zeros(1,inputSize.bytes+2*inputSize.size(1)+inputSize.size(1)*inputSize.size(2)*delimLength+10000));%Storage size + row end chars + delimiters + bit extra
    counter=0;
    for i=1:cellArrayHeight
        for j=1:cellArrayWidth
            if(~ischar(cellStrMatrix{i,j}))%Safety check that not trying to write numeric values or similar
                error(['Error in cellStrMatrix2csvFaster() the cell in row ',num2str(i),' and column ',num2str(j),' does not contain a string']);
            end
            %fprintf(fHandle,'%s',cellStrMatrix{i,j});%Write data
            %temp{1}=[temp{1},cellStrMatrix{i,j}];
            dC=length(cellStrMatrix{i,j});
            temp(counter+1:counter+dC)=cellStrMatrix{i,j};
            counter=counter+dC;
            if(j==cellArrayWidth)%NL if end of row
                if(i~=cellArrayHeight)%Only put NL if it isn't the end of the file.
                    temp(counter+1:counter+nlLength)=char(10);
                    counter=counter+2;
                end
            else
                temp(counter+1:counter+delimLength)=delimiter;
                counter=counter+delimLength;
            end
        end
    end
    fprintf(fHandle,'%s',temp(1:counter));
    %Done
    
    %Close
    fclose(fHandle);
    %Done
    
    %Works well.
    
    %There is now also a function writecell(C,filename) that seems to be new [introduced in 2019a]? Also works well.
end