%% Script to calculate discharge from surface velocity and cross section data
%{
%Matlab script processing
%Load .csv files for surface velocities and cross section into Matlab
%Remember to ensure that both surface velocities and cross section are in the same reference system (i.e. LB to RB, or RB to LB).
%}

%% Initialise and load data
clear all;
close all;
ouputDataDir='O:\END19505\Working\Fieldwork\Waimakariri\2022-02-10 Flood Gauging\GPR\JM Emails and Data\';
outputFigureDir='O:\END19505\Working\Fieldwork\Waimakariri\2022-02-10 Flood Gauging\GPR\JM Emails and Data\Matlab Plots\';
saveDataBool=true;
saveFiguresBool=true;
Discharge.('crossSectionCSV')=readTextFileGeneric('O:\END19505\Working\Fieldwork\Waimakariri\2022-02-10 Flood Gauging\GPR\JM Emails and Data\2022_04_26_15_47_18_GPR_CrossSection_DisplacementDepth_LBtoRB.csv',',',false);
Discharge.('surfaceVelocitiesCSV')=readTextFileGeneric('O:\END19505\Working\Fieldwork\Waimakariri\2022-02-10 Flood Gauging\GPR\JM Emails and Data\SurfaceVelocitiesFromHydroSTIVCombinedLBtoRB.csv',',',false);
%Done

%% Unpack data
Discharge.('XS_Distance_m')=str2double(Discharge.crossSectionCSV(2:end,1));
Discharge.('XS_Depth_m')=str2double(Discharge.crossSectionCSV(2:end,2));
Discharge.('SV_Distance_m')=str2double(Discharge.surfaceVelocitiesCSV(2:end,1));
Discharge.('SV_Velocity_mps')=str2double(Discharge.surfaceVelocitiesCSV(2:end,2));
%Done

%% Create centre points on the cross section for discharge bins
Discharge.('binCentres_Distance_m')=(Discharge.XS_Distance_m(2:end)+Discharge.XS_Distance_m(1:end-1))/2;
Discharge.('binWidths_m')=Discharge.XS_Distance_m(2:end)-Discharge.XS_Distance_m(1:end-1);
%Done

%% Get the mean depth of the bin centres [i.e. rectangular bins]
Discharge.('binCentres_Depth_m')=(Discharge.XS_Depth_m(2:end)+Discharge.XS_Depth_m(1:end-1))/2;
%Done

%% Interpolate the SV data to match the bin centres
Discharge.('binCentres_SV_mps')=interp1(Discharge.SV_Distance_m,Discharge.SV_Velocity_mps,Discharge.binCentres_Distance_m,'Linear');
%Done

%% Plot depth and surface velocities vs cross stream displacement
figure();
hold on;
yyaxis left;
plot(Discharge.binCentres_Distance_m,Discharge.binCentres_SV_mps,'r','LineWidth',3);
ylabel('Surface velocity (m/s)','Color','r');
xlabel('Cross stream distance (m)');
set(gca,'ycolor','r');
yyaxis right;
plot(Discharge.XS_Distance_m,Discharge.XS_Depth_m,'b','LineWidth',3);
ylabel('Depth (m)');
set(gca,'ycolor','b');
set(gca, 'YDir','reverse')
hold off;
title('Surface velocity and depth vs cross stream distance');
genericFigureScaling();
%Done

%% Next apply 'alpha coefficient' to get depth averaged velocity [consult Biggs, H., Smart G., Doyle, M., Holwerda, H., McDonald, M. & Ede, M. (2021). River discharge from surface velocity measurements - A field guide for selecting alpha. Envirolink Advice Report, Christchurch, New Zealand.]
%We have no further information on the site characteristics (i.e. slope, roughness, velocity profiles, etc) so assume 0.90 since it is a deep flow.
Discharge.('binCentres_SV_depthAveraged_mps')=Discharge.binCentres_SV_mps*0.90;
%Done

%% Calculate discharge
Discharge.('DischargeWithAlpha_m3ps')=sum(Discharge.binWidths_m.*Discharge.binCentres_Depth_m.*Discharge.binCentres_SV_depthAveraged_mps);
Discharge.('DischargeNoAlpha_m3ps')=sum(Discharge.binWidths_m.*Discharge.binCentres_Depth_m.*Discharge.binCentres_SV_mps);
%Done

%% Compare with ECAN discharge of 813.695 m3/s at 17:50. (interp from Tony Gray)
%Our discharge with default alpha included is: 749.6746 m3/s [Alpha is too low since deep flow]
%Our discharge without alpha is 832.972 m3/s
%Site alpha from reference discharge divided by discharge with alpha = 1  is: 0.977   (i.e. Biggs et al., 2021)
%This is pretty bloody good! Usually deep flows have alpha closer to 1. I.e. surface velocity dip and lower than sub surface velocity.
%Similar to Tekapo Canal which is also deep.
%Definitely promising, and particulalry if cross sections from GPR are improved. We seem to be missing some bathymetry near the edges of the channel, and near the central dry area.
%Including these areas would increase the discharge and decrease alpha. It is probably around 0.90 which would be a SV discharge of 904.10 m3/s.
%There are also uncertainties in the discharge from ECAN. Need to repeat it with reference data from jet boat (or similar) and look at ways to remove reflections from solid objects etc.

%% Save the data
%Save the matlab structure
save([ouputDataDir,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_GPR_Discharge.mat'],'Discharge');
%Done

%% Save figures
if(saveFiguresBool)
    saveFiguresPNG2(outputFigureDir);
end
%Done