%% Script to batch process multispec images for alignment and cropping to regular view
%{
Info:
- Shifts files based on regular expressions
- Example, ' 11-00-',' 12-00-'

%}

%% Choose input files
global lastInputPathname; %#ok<*NUSED>
[filenamesOfImages,pathnameOfImages]=selectInputImages();
nImages=length(filenamesOfImages);
%Done

%% Choose output directory for aligned images
global lastOutputPathname;
outputPathname=selectOutputDirectory('Select output directory for copied images');
%Done

%% Get regular expression to match
regularExpression=input([char(10),'Type regular expression such as 11-00- for copying files',char(10)],'s');
%Done

%% Copy files
filesToCopy=filenamesOfImages(contains(filenamesOfImages,regularExpression));
for i=1:length(filesToCopy)
    %Check can open file
    fHandle=fopen([pathnameOfImages,filesToCopy{i}]);
    while(~fHandle)
        disp([[pathnameOfImages,filesToCopy{i}],' is open in another program. Close the file now.']);
        pause(2);
        fHandle=fopen([pathnameOfImages,filesToCopy{i}]);
    end
    fclose(fHandle);
    %Done
    
    %Copy the file.
    status=copyfile([pathnameOfImages,filesToCopy{i}],[outputPathname,filesToCopy{i}]);
    if(~status)
        error('Error in copyFilesWithRegularExpression() copy file was unsuccessful');
    end
    disp(['Running copyFilesWithRegularExpression(). Copied ',num2str(i),' of ',num2str(length(filesToCopy)),' files.']);
    %Done
end
%Done

%% Function wrapper: selectInputImages()
function [filenamesOfImages,pathnameOfImages]=selectInputImages()
    global lastInputPathname;%Retain directory locations for faster processing of multiple folders.
    
    if isempty(lastInputPathname) 
        % First time calling 'uigetfile', use the pwd
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files', ...
        'MultiSelect', 'on');
        lastInputPathname=pathnameOfImages;
    else
        %Repeated call to 'uigetfile', start at the same directory as last selection
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files', ...
        'MultiSelect', 'on',lastInputPathname);
        lastInputPathname=pathnameOfImages;
    end
    if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
        filenamesOfImages={filenamesOfImages};
    end
    %Done
end

%% Function wrapper: selectOutputDirectory()
function outputPathname=selectOutputDirectory(selectionString)
    global lastInputPathname lastOutputPathname %Retain directory locations for faster processing of multiple folders.
    
    %Then select the output directory
    if isempty(lastOutputPathname) 
        outputPathname=uigetdir(lastInputPathname,selectionString);
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    else
        outputPathname=uigetdir(lastOutputPathname,selectionString);
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    end
    %Done
end
%Done
