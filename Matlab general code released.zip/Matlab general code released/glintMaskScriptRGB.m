%% Script to batch process images to mask sunglint
%{
Info:
 - Run script
 - File selection through GUI.
 - Select output type through GUI. Suggest .jpg mask
 - Tweak mask shinking and growth parameter "threshStart"
 - Edit values in function sunglintThresholdMask(inputImage) if needed.
 - Supress the display of figures in the loop below.
 - Added functionality to remove small misclassified regions. I.e. found that the bright GCPs were being masked previously.

To do:
 - Could add a function to output threshold parameters as a text file.

%}

%% Initialise and set thresholding and filtering parameters
%clear all;
%close all;
%Thresholds of areas to remove
%hueRange=[0;1];%For RGB
%saturationRange=[0;0.067];%For RGB
%valueRange=[0.913;1];%For RGB
multispecSunglintThreshold=50000;

%Parameters for tuning for growing mask areas
%shrinkMaskThreshold=0.4;
shrinkMaskThreshold=0.1;
shrinkMaskSizes=[51;45;39;33;27];%;21;15;9];
growMaskSizes=[9;15;21;27;33];%;39;45;51;57];
growMaskThreshold=0.1;  
%growMaskThreshold=0.01;
showImagesOfMaskingProcess=true;%Turn this off to make it run fast
saveOutputMaskedImageVisualisation=true;
pauseTime=0.1;
removeSmallMisclassifiedRegions=true;
minimumPixelsForSunglintArea=100*100;%Recommended
%minimumPixelsForSunglintArea=1;

onlyDoBasicMaskingBool=false;

%Note: Take screenshot of parameters after processing data. If needed can write function to output them as a text file.
%Done

%% Choose input images
global lastInputPathname; %#ok<*NUSED>
[filenamesOfImages,pathnameOfImages]=selectInputImages();
nImages=length(filenamesOfImages);
%Done

%% Choose output directory for masks
global lastOutputPathname;
outputPathname=selectOutputDirectory();
%Done

%% Mask images and output
%Initialise choice of output type
outputTypes={'.tiff_binary','.tiff_255','.bmp_binary','.bmp_255','.jpg','.png'};%Warning .jpg is lossy (even at 100% quality) with problems at mask boundaries. The .png files have an alpha layer but are very large.
outputTypeStrings={'.tiff_binary is a 0/1 single channel single bit mask','.tiff_255 is a 0/255 single channel single byte mask',...
                   '.bmp_binary is a 0/1 single channel single bit mask','.bmp_255 is a 0/255 single channel single byte mask',...
                   '.jpg is a 0->255 single channel mask (note: problems around mask borders due to .jpg compression algorithm)'};
outputIndex = listdlg('PromptString','Select output mask type','ListString',outputTypeStrings,'SelectionMode','single','ListSize',[600,500]);
tempImageContainer=0*imread([pathnameOfImages,filenamesOfImages{1}]);
%Done

%Choose output directory for masked images to visualise
if(saveOutputMaskedImageVisualisation)
    global lastOutputImageVisualisationPathname;
    outputMaskVisualisationPathname=selectOutputDirectoryForVisualisation();
end
%Done

%Loop through all images
for i=1:nImages
    %Display progress
    disp(['Processing file ',num2str(i),' of ',num2str(nImages)]);
    %Done
    
    %Read in the image
    tempImageContainer=imread([pathnameOfImages,filenamesOfImages{i}]);
    %Done
    
    %Generate the initial mask
    sunglintMask=sunglintThresholdMaskMultispec(tempImageContainer,multispecSunglintThreshold);
    %Done
    
    if(~onlyDoBasicMaskingBool)
        %Show initial mask if needed
        if(showImagesOfMaskingProcess)
            warning('off','images:initSize:adjustingMag');
            imshow(uint8(double(sunglintMask).*double(tempImageContainer)));
            %set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
            pause(pauseTime);
        end
        %Done

        %Shrink mask and clean errors
        for j=1:length(shrinkMaskSizes)
            sunglintMask=smoothMasks(sunglintMask,shrinkMaskSizes(j),shrinkMaskThreshold,'Gaussian');
            if(showImagesOfMaskingProcess)
                imshow(uint8(double(sunglintMask).*double(tempImageContainer)));
                %set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
                pause(pauseTime);
            end
        end
        %Done

        %Grow mask
        for j=1:length(growMaskSizes)
            sunglintMask=smoothMasks(sunglintMask,growMaskSizes(j),growMaskThreshold,'Gaussian');
            if(showImagesOfMaskingProcess)
                imshow(uint8(double(sunglintMask).*double(tempImageContainer)));
                %set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
                pause(pauseTime);
            end
        end
        %Done

        %Remove small misclassified regions
        if(removeSmallMisclassifiedRegions)
            sunglintMask=double(bwareaopen(sunglintMask==0,minimumPixelsForSunglintArea,8)==0);
            if(showImagesOfMaskingProcess)
                imshow(uint8(double(sunglintMask).*double(tempImageContainer)));
                %set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
                pause(pauseTime);
            end
        end
        %Done
    end

    %Safety check, since had a few 2's turn up in output masks (likely due to original .jpg compression)
    if(any((sunglintMask(:)~=1)&(sunglintMask(:)~=0)))
        save('wtf.mat');
        error('Error in glintMaskScript() some values of sunglintMask were not 0 or 1. Saved wtf.mat');
    end
    %Done

    %Output images
    if(outputIndex==1)
        binaryMask=sunglintMask==1;
        outputFilenameAndPath=[outputPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_mask.tiff'];
        imwrite(binaryMask,outputFilenameAndPath);%Single Channel 0->1

        %Also write masked image for inspection only. DO NOT USE THESE IMAGES FOR PROCESSING!!! Have not copied EXIF information to these masked images. Also not good to rewrite JPG if not sure of compression settings.
        if(saveOutputMaskedImageVisualisation)
            imwrite(uint16(double(sunglintMask).*double(tempImageContainer)),[outputMaskVisualisationPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_masked_visualisation_do_not_process.tif']);
        end
    elseif(outputIndex==2)
        outputFilenameAndPath=[outputPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_mask.tiff'];
        imwrite(uint8(sunglintMask*255),outputFilenameAndPath);%Single Channel 0->255

        %Also write masked image for inspection only. DO NOT USE THESE IMAGES FOR PROCESSING!!! Have not copied EXIF information to these masked images. Also not good to rewrite JPG if not sure of compression settings.
        if(saveOutputMaskedImageVisualisation)
            imwrite(uint16(double(sunglintMask).*double(tempImageContainer)),[outputMaskVisualisationPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_masked_visualisation_do_not_process.tif']);
        end
    elseif(outputIndex==3)
        binaryMask=sunglintMask==1;
        outputFilenameAndPath=[outputPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_mask.bmp'];
        imwrite(binaryMask,outputFilenameAndPath);%Single Channel 0->1

        %Also write masked image for inspection only. DO NOT USE THESE IMAGES FOR PROCESSING!!! Have not copied EXIF information to these masked images. Also not good to rewrite JPG if not sure of compression settings.
        if(saveOutputMaskedImageVisualisation)
            imwrite(uint16(double(sunglintMask).*double(tempImageContainer)),[outputMaskVisualisationPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_masked_visualisation_do_not_process.tif']);
        end
    elseif(outputIndex==4)
        outputFilenameAndPath=[outputPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_mask.bmp'];
        imwrite(uint8(sunglintMask*255),outputFilenameAndPath);%Single Channel 0->255

        %Also write masked image for inspection only. DO NOT USE THESE IMAGES FOR PROCESSING!!! Have not copied EXIF information to these masked images. Also not good to rewrite JPG if not sure of compression settings.
        if(saveOutputMaskedImageVisualisation)
            imwrite(uint16(double(sunglintMask).*double(tempImageContainer)),[outputMaskVisualisationPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_masked_visualisation_do_not_process.tif']);
        end
    elseif(outputIndex==5)
        outputFilenameAndPath=[outputPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_mask.jpg'];
        imwrite(uint8(sunglintMask*255),outputFilenameAndPath,'Quality',100);%Single Channel 0->255%'Mode','lossless' doesn't work
        %imwrite(repmat(uint8(sunglintMask*255),[1,1,3]),outputFilenameAndPath,'Quality',100);%Three Channel 0->255  %'Mode','lossless' doesn't work
        
        %Also write masked image for inspection only. DO NOT USE THESE IMAGES FOR PROCESSING!!! Have not copied EXIF information to these masked images. Also not good to rewrite JPG if not sure of compression settings.
        if(saveOutputMaskedImageVisualisation)
            imwrite(uint16(double(sunglintMask).*double(tempImageContainer)),[outputMaskVisualisationPathname,filenameWithoutFiletype(filenamesOfImages{i}),'_masked_visualisation_do_not_process.tif']);
        end
    else
        error('No valid output selected');
    end
    disp(['File ',num2str(i),' of ',num2str(nImages),' completed']);
end
%Done
    
%% Function wrapper: sunglintThresholdMaskMultispec(inputImage,multispecThreshold) %Simplified from 3 channel RGB
function outputMask=sunglintThresholdMaskMultispec(inputImage,multispecThreshold)
    outputMask = inputImage < multispecThreshold;
end
%Done

%% Function wrapper: Smooth sunglint areas and threshold
function outputMask=smoothMasks(inputMask,kernelDiameter,threshold,maskType)
    %Function to smooth out and join the sparse sunglint mask data.
    %KernelDiameter should be an odd number. Suggest 21 for first pass and 7 for second pass
    %threshold is between 0 and 1. Suggest 0.2 for first pass and 0.1 for second pass.
    %Use maskType='Gaussian' for initial cleaning and maskType='Box' for growing mask area
    
    %Safety check
    if((threshold>1)||(threshold<0)||rem(kernelDiameter,2)~=1)
        error('Error in smoothMasks() check input values to function');
    end
    %Done
    
    %Convert to double (may be logical input). Invert mask as we want to work on only sunglint areas.
    doubleMaskInverse=double(inputMask==0);
    %Done
    
    %Generate smoothing kernel
    gaussianKernel=generateSmoothingKernel(kernelDiameter,maskType,1);
    %Done
    
    %2D cross correlation with smoothing kernel
    smoothedMask=xcorr2Clean(doubleMaskInverse,gaussianKernel);
    %Done
    
    %Threshold image again. I.e >20% of surrounding gaussian weighted surrounding squares are sunglint then also apply sunglint.
    thresholdMask=ones(size(smoothedMask)).*(smoothedMask>threshold);
    outputMask=double(thresholdMask==0);
    %Done
end

%% Function wrapper: generateSmoothingKernel
function outputKernel=generateSmoothingKernel(kernelDiameter,kernelTypeString,scalingFactor)
    %Creates smoothing kernels. Symmetric with sum of scalingFactor.

    if(rem(kernelDiameter,2)~=1)
       error('Error in generateSmoothingKernel() supplied a kernel diameter that is not odd. Use 5 for example.');
    end

    if(strcmp(kernelTypeString,'Box'))
        kernel=scalingFactor*ones(kernelDiameter,kernelDiameter)/(kernelDiameter^2);
        %Done
    elseif(strcmp(kernelTypeString,'Gaussian'))
        %2D Gaussian: f(x,y)=A*e^-((x-x0)^2/(2*SDX^2)+(y-y0)^2/(2*SDY^2))
        %Now the only tricky thing is choosing the standard deviation
        %Assume that the full kernel with corresponds to 5 standard deviations
        %So sigma=ceil(kR/5);
        kR=(kernelDiameter-1)/2;
        yTemp=[-kR:1:kR]';
        xTemp=[-kR:1:kR];
        yfull=repmat(yTemp,[1,kernelDiameter]);
        xfull=repmat(xTemp,[kernelDiameter,1]);
        SD=ceil(kR/5);
        tempPDF2D=exp(-((xfull.^2)/(2*SD)^2+(yfull.^2)/(2*SD)^2));
        normPDF2D=tempPDF2D/sum(tempPDF2D(:));
        kernel=scalingFactor*normPDF2D;
        %Done

        %Or kernel = fspecial('gaussian', [kernelDiameter kernelDiameter], SD);
        %Or https://au.mathworks.com/matlabcentral/fileexchange/32527-2d-gaussian-filter-with-varying-kernel-size-and-variance
        %Done
    elseif(strcmp(kernelTypeString,'Inverse Distance'))
        kR=(kernelDiameter-1)/2;
        yTemp=[-kR:1:kR]';
        xTemp=[-kR:1:kR];
        yfull=repmat(yTemp,[1,kernelDiameter]);
        xfull=repmat(xTemp,[kernelDiameter,1]);

        tempKernel=1./((yfull.^2+xfull.^2).^0.5);
        %Set centre weighting to 2 as it will be NaN or INF from division by zero.
        tempKernel(kR+1,kR+1)=2;
        normTempKernel=tempKernel/sum(tempKernel(:));
        kernel=scalingFactor*normTempKernel;
        %Done
    else
        error(['Error in generateSmoothingKernel() supplied an unknown kernel type of ',kernelTypeString]);
    end

    outputKernel=kernel;
    %Done
end

%% Function wrapper: xcorr2Clean()
function outputMatrix2D=xcorr2Clean(inputMatrix1,inputMatrix2)
    %Check size matrix2
    if(rem(size(inputMatrix2,1),2)~=1&&rem(size(inputMatrix2,2),2)~=1)
        error('Error in xcorr2Clean() inputMatrix2 not odd size');
    end

    if(length(size(inputMatrix1))~=2||length(size(inputMatrix2))~=2)
        error('Error xcorr2Clean() input matrices are not 2 dimensional');
    end
    %Done

    %Mirror matrix boundaries to minimise error instead of zero padding
    [bigTiledMatrix]=mirrorMatrix(inputMatrix1,inputMatrix2,'Mirror');
    %Done

    %Perform xCorr2
    biggerXCorr2Matrix=xcorr2(bigTiledMatrix,inputMatrix2);
    %Done

    %Now need to extract the centre and half widths of the original image
    centreY=(size(biggerXCorr2Matrix,1)+1)/2;
    centreX=(size(biggerXCorr2Matrix,2)+1)/2;
    hhIM1=(size(inputMatrix1,1)-1)/2;
    hwIM1=(size(inputMatrix1,2)-1)/2;
    %Done

    %Output the data
    outputMatrix2D=biggerXCorr2Matrix(centreY-hhIM1:centreY+hhIM1,centreX-hwIM1:centreX+hwIM1);
    %Done
end

%% Function wrapper: mirrorMatrix()
function [outputMatrix2D]=mirrorMatrix(inputMatrix1,inputMatrix2,methodString)
    %Supports 'Mirror', 'Extract'
    %Minimises contamination from zero padding etc
    %inputMatrix2 is usually a cross correlation kernel

    %Remove any singleton dimensions
    inputMatrix1=squeeze(inputMatrix1);
    inputMatrix2=squeeze(inputMatrix2);
    %Done

    %Check matrices are 2D
    if(length(size(inputMatrix1))~=2||length(size(inputMatrix2))~=2)
        error('Error mirrorMatrix() input matrices are not 2 dimensional');
    end
    %Done

    %Dimensions of the kernel/second matrix
    h2=size(inputMatrix2,1);
    w2=size(inputMatrix2,2);
    %Done

    %Mirror, or extract.
    if(strcmp(methodString,'Mirror'))
        %Just mirror the boundaries of the input matrix 1 then extract the central matrix later
        %Generate the mirrored matrix
        outputMatrix2D=[fliplr(flipud(inputMatrix1(1:h2,1:w2))),flipud(inputMatrix1(1:h2,:)),fliplr(flipud(inputMatrix1(1:h2,end-w2+1:end)));...
                        fliplr(inputMatrix1(:,1:w2)),inputMatrix1,fliplr(inputMatrix1(:,end-w2+1:end));...
                        fliplr(flipud(inputMatrix1(end-h2+1:end,1:w2))),flipud(inputMatrix1(end-h2+1:end,:)),fliplr(flipud(inputMatrix1(end-h2+1:end,end-w2+1:end)))]; %#ok<FLUDLR>
        %Done
    elseif(strcmp(methodString,'Extract'))
        %Extract the original image, i.e. reverse the process of above
        outputMatrix2D=inputMatrix1(h2+1:end-h2,w2+1:end-w2);
        %Done
    else
        error(['Error in mirrorMatrix() unknown method of',methodString]);
        outputMatrix2D=NaN;
    end
    %Done
end 

%% Function wrapper: selectInputImages()
function [filenamesOfImages,pathnameOfImages]=selectInputImages()
    global lastInputPathname;%Retain directory locations for faster processing of multiple folders.
    
    if isempty(lastInputPathname) 
        % First time calling 'uigetfile', use the pwd
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files to mask', ...
        'MultiSelect', 'on');
        lastInputPathname=pathnameOfImages;
    else
        %Repeated call to 'uigetfile', start at the same directory as last selection
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files to mask', ...
        'MultiSelect', 'on',lastInputPathname);
        lastInputPathname=pathnameOfImages;
    end
    if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
        filenamesOfImages={filenamesOfImages};
    end
    %Done
end

%% Function wrapper: selectOutputDirectory()
function outputPathname=selectOutputDirectory()
    global lastInputPathname lastOutputPathname %Retain directory locations for faster processing of multiple folders.
    
    %Then select the output directory
    if isempty(lastOutputPathname) 
        outputPathname=uigetdir(lastInputPathname,'Select output directory for image masks');
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    else
        outputPathname=uigetdir(lastOutputPathname,'Select output directory for image masks');
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    end
    %Done
end

%% Function wrapper: selectOutputDirectoryForVisualisation()
function outputPathname=selectOutputDirectoryForVisualisation()
    global lastOutputPathname lastOutputImageVisualisationPathname;%Retain directory locations for faster processing of multiple folders.
    
    %Then select the output directory
    if ~isempty(lastOutputImageVisualisationPathname) 
        outputPathname=uigetdir(lastOutputImageVisualisationPathname,'Select output directory for visualisation images to check masking');
        outputPathname=[outputPathname,'\'];
        lastOutputImageVisualisationPathname=outputPathname;
    else
        outputPathname=uigetdir(lastOutputPathname,'Select output directory for visualisation images to check masking');
        outputPathname=[outputPathname,'\'];
        lastOutputImageVisualisationPathname=outputPathname;
    end
    %Done
end

%% Function wrapper: selectExifTool()
function [exifToolFilename,exifToolPathname]=selectExifTool()
   global lastExifToolPathname %Retain directory locations for faster processing of multiple folders.

    if isempty(lastExifToolPathname) 
        exiftoolPathToSearch=mfilename('fullpath');%Start in directory this function is stored in
        slashIndices=strfind(exiftoolPathToSearch,'\');
        exiftoolPathToSearch=exiftoolPathToSearch(1:slashIndices(end));
        [exifToolFilename,exifToolPathname] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select exiftool.exe', ...
        'MultiSelect', 'off',exiftoolPathToSearch);
        lastExifToolPathname=exifToolPathname;
    else
        [exifToolFilename,exifToolPathname] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select exiftool.exe', ...
        'MultiSelect', 'off',lastExifToolPathname);
        lastExifToolPathname=exifToolPathname;
    end
    %Done
end

%% Function wrapper: filenameWithoutFiletype()
function outputFilename=filenameWithoutFiletype(inputFilename)
    stringIndices=strfind(inputFilename,'.');
    if(isempty(stringIndices))
        error('Error in filenameWithoutFiletype() the character . was not found in the inputFilename');
    else
        if(ischar(inputFilename))
            outputFilename=inputFilename(1:stringIndices(end)-1);
        else%Cellstring
            outputFilename={inputFilename{1:stringIndices(end)-1}};
        end
    end
    %Done
end