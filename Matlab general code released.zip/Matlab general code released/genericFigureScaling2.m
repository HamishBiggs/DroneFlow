function genericFigureScaling2(fontSize)
    set(gca,'FontSize',fontSize);
    set(gca,'FontWeight','Bold')
    set(gcf,'units','normalized');
    set(gcf,'outerposition',[0 0 1 1]);
    set(gca,'LineWidth',3);
    set(gca,'Box','on');
end