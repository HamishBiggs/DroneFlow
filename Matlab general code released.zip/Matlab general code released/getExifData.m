function outputData=getExifData()
    % Extracts all the exif data and saves it in a structure.

    %% First, select all images to fix.
    global lastPathname lastExifToolPathname%Retain directory locations for faster processing of multiple folders.
    if isempty(lastPathname) 
        % First time calling 'uigetfile', use the pwd
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files to extract exif data', ...
        'MultiSelect', 'on');
        lastPathname=pathnameOfImages;
    else
        %Repeated call to 'uigetfile', start at the same directory as last selection
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files to extract exif data', ...
        'MultiSelect', 'on',lastPathname);
        lastPathname=pathnameOfImages;
    end
    if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
        filenamesOfImages={filenamesOfImages};
    end
    %Done

    
    %% Second, find location of exiftool.exe since bloody matlab imwrite sucks and cant handle all the tag data...
    if isempty(lastExifToolPathname) 
        exiftoolPathToSearch=mfilename('fullpath');%Start in directory this function is stored in
        slashIndices=strfind(exiftoolPathToSearch,'\');
        exiftoolPathToSearch=exiftoolPathToSearch(1:slashIndices(end));
        [exifToolFilename,exifToolPathname] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select exiftool.exe', ...
        'MultiSelect', 'off',exiftoolPathToSearch);
        lastExifToolPathname=exifToolPathname;
    else
        [exifToolFilename,exifToolPathname] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select exiftool.exe', ...
        'MultiSelect', 'off',lastExifToolPathname);
        lastExifToolPathname=exifToolPathname;
    end
    %Done
    
    %% Third, loop through all files and extract their exif data
    nFiles=length(filenamesOfImages);
    tempData.('Filenames')=cell(nFiles,1);
    tempData.('rawExifData')=cell(nFiles,1);
    tempData.('cleanExifData')=cell(nFiles,1);

    for i=1:nFiles
        disp(['Processing file ',num2str(i),' of ',num2str(nFiles)]);
        %Check file is not open by another program
        tempData.Filenames{i}=[pathnameOfImages,filenamesOfImages{i}];
        fHandle=fopen([pathnameOfImages,filenamesOfImages{i}]);
        while(~fHandle)
            disp([pathnameOfImages,filenamesOfImages{i},' is open in another program. Close the file now so the exif data can be updated.']);
            pause(2);
            fHandle=fopen(pathnameOfImages,filenamesOfImages{i});
        end
        fclose(fHandle);
        %Done
        
        %Extract all the exif data and save it in the structure to output from the function.
        [~, tempData.rawExifData{i}]=system(['"',exifToolPathname,exifToolFilename,'"',' -s ','"',pathnameOfImages,filenamesOfImages{i},'"']);
        tempData.cleanExifData{i}=splitlines(tempData.rawExifData{i});
        tempData.cleanExifData{i}=splitFields(tempData.cleanExifData{i},':',true);
        %Done
    end    
    
    %Ouput the datastructure
    outputData=tempData;
    %Done
end