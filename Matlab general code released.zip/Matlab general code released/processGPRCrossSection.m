%% Script to process GPR cross section data
%{
%Processing before Matlab:
%Convert raw data into NZTM2000 [or similar projected coordinate system in metres] (e.g. with linz coordinate conversion utility)
%Get coordinates of bank locations and add to .csv file with zero depth there
%Format of input data should be:
{'Easting_NZTM2000_m','Northing_NZTM2000_m','Depth_m';...
'1571821.359','5193112.649','0';...
'1571816.795','5193118.119','4.415765167';...
'1571816.727','5193118.249','4.415765167'...
etc}

%Matlab script processing
%Load .csv file into Matlab
%Check if data is from true left to true right bank, or vice versa
%Visualise raw data as XY points
%Unit vector from bank 1 to bank 2
%Project data onto unit vector
%Visualise projected data as XY points
%Visualise projected data as cross section
%Define line for interpolation
%Perform interpolation
%Visualise interpolated data
%Save data
%Export cross sections as XYDepth and DisplacementDepth formats, in both LBtoRB and RBtoLB forms.
%Save Figures
%Done

%Cross section data can then be combined with velocity data using dischargeFromSurfaceVelocitiesAndCrossSection.mat
%}

%% Initialise and load data
clear all;
close all;
outputXSResolution_m=0.1;
ouputDataDir='O:\END19505\Working\Fieldwork\Waimakariri\2022-02-10 Flood Gauging\GPR\JM Emails and Data\';
outputFigureDir='O:\END19505\Working\Fieldwork\Waimakariri\2022-02-10 Flood Gauging\GPR\JM Emails and Data\Matlab Plots\';
saveDataBool=true;
saveFiguresBool=true;
GPR.('inputGPRData')=readTextFileGeneric('O:\END19505\Working\Fieldwork\Waimakariri\2022-02-10 Flood Gauging\GPR\JM Emails and Data\horizon-depth2-NZTM2000_Export.csv',',',false);
GPR.('Easting_Raw_m')=str2double(GPR.inputGPRData(2:end,1));
GPR.('Northing_Raw_m')=str2double(GPR.inputGPRData(2:end,2));
GPR.('Depth_Raw_m')=str2double(GPR.inputGPRData(2:end,3));
%Done

%% Ask if LB to RB, or RB to LB. Save in both forms.
reply='empty';
while(~any(strcmp(reply,{'Y','N','y','n'})))
    reply=input([char(10),'Is the input cross section from the true left to the true right bank? Type: Y for yes LB->RB, or N for no RB->LB. Then press enter.',char(10)],'s');
end
if(strcmp(reply,'Y')||strcmp(reply,'y'))
    GPR.('XS_Orientation')='LBtoRB';
else
    GPR.('XS_Orientation')='RBtoLB';
end
%Done

%% Visualise RAW XY Points
figure();
scatter(GPR.Easting_Raw_m,GPR.Northing_Raw_m,'xr','LineWidth',2);
xlabel('Easting (m)');
ylabel('Northing (m)');
title('Plot of RAW XY points');
genericFigureScaling();
axis equal;
%Done

%% Extract the bank coordinates and cross section unit vector
GPR.('Bank1Coords_xy')=[GPR.Easting_Raw_m(1),GPR.Northing_Raw_m(1)];
GPR.('Bank2Coords_xy')=[GPR.Easting_Raw_m(end),GPR.Northing_Raw_m(end)];
GPR.('CrossSectionVector_xy')=GPR.Bank2Coords_xy-GPR.Bank1Coords_xy;
GPR.('CrossSectionUnitVector_xy')=GPR.CrossSectionVector_xy/((GPR.CrossSectionVector_xy(1)^2+GPR.CrossSectionVector_xy(2)^2)^0.5);
%Done

%% Vector projection to get the measurements in a cross section between bank 1 and bank 2
%Dot product of point vector and cross section unit vector (i.e. a1=(a.b_hat)b_hat) https://en.wikipedia.org/wiki/Vector_projection 
GPR.('PointVectorFromB1_Raw_m')=[GPR.Easting_Raw_m,GPR.Northing_Raw_m]-repmat(GPR.Bank1Coords_xy,[length(GPR.Easting_Raw_m),1]);
tempDot=dot(GPR.PointVectorFromB1_Raw_m,repmat(GPR.CrossSectionUnitVector_xy,[length(GPR.Easting_Raw_m),1]),2);
GPR.('PointProjectedVectorFromB1_Raw_m')=repmat(tempDot,[1,2]).*repmat(GPR.CrossSectionUnitVector_xy,[length(GPR.Easting_Raw_m),1]);
GPR.('PointProjectedDisplacementFromB1_Raw_m')=(GPR.PointProjectedVectorFromB1_Raw_m(:,1).^2+GPR.PointProjectedVectorFromB1_Raw_m(:,2).^2).^0.5;
GPR.('PointProjectedXY_Raw_m')=repmat(GPR.Bank1Coords_xy,[length(GPR.Easting_Raw_m),1])+GPR.PointProjectedVectorFromB1_Raw_m;
GPR.('Easting_Projected_Raw_m')=GPR.PointProjectedXY_Raw_m(:,1);
GPR.('Northing_Projected_Raw_m')=GPR.PointProjectedXY_Raw_m(:,2);
GPR.('Depth_Projected_Raw_m')=GPR.Depth_Raw_m;
%Done

%% Visualise projected data as XY points
figure();
scatter(GPR.Easting_Projected_Raw_m,GPR.Northing_Projected_Raw_m,'xg','LineWidth',2);
genericFigureScaling();
xlabel('Easting (m)');
ylabel('Northing (m)');
title('Plot of RAW XY points projected onto cross section');
axis equal;
%Done

%% Visualise projected data as cross section
figure();
scatter(GPR.PointProjectedDisplacementFromB1_Raw_m,GPR.Depth_Projected_Raw_m,'xg','LineWidth',2);
xlabel('Displacement along cross section (m)');
ylabel('Depth (m)');
title('Plot of depth points after projection onto cross section');
genericFigureScaling();
set(gca, 'YDir','reverse')
%Done

%% Next sort cross section data so that it is always increasing (i.e. remove any loops due to GPR flight path etc before interpolation)
[GPR.('PointProjectedDisplacementFromB1Sorted_Raw_m'),GPR.('SortIndices')]=sort(GPR.PointProjectedDisplacementFromB1_Raw_m);
GPR.('Easting_Projected_Sorted_Raw_m')=GPR.Easting_Projected_Raw_m(GPR.SortIndices);
GPR.('Northing_Projected_Sorted_Raw_m')=GPR.Northing_Projected_Raw_m(GPR.SortIndices);
GPR.('Depth_Projected_Sorted_Raw_m')=GPR.Depth_Projected_Raw_m(GPR.SortIndices);
%Done

%% Next perform interpolation
GPR.('InterpolatedOutput').('PointProjectedDisplacementFromB1_m')=(0:outputXSResolution_m:GPR.PointProjectedDisplacementFromB1_Raw_m(end))';
if(GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m(end)~=GPR.PointProjectedDisplacementFromB1_Raw_m(end))%Need to include final point even if it is not a multiple of resolution
    GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m(end+1)=GPR.PointProjectedDisplacementFromB1_Raw_m(end);
end
nInterpPoints=length(GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m);
GPR.('InterpolatedOutput').('Depth_m')=interp1(GPR.PointProjectedDisplacementFromB1Sorted_Raw_m,GPR.Depth_Projected_Sorted_Raw_m,GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m,'Linear');
GPR.('InterpolatedOutput').('PointXY_m')=repmat(GPR.Bank1Coords_xy,[nInterpPoints,1])+repmat(GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m,[1,2]).*repmat(GPR.CrossSectionUnitVector_xy,[nInterpPoints,1]);
GPR.('InterpolatedOutput').('Easting_m')=GPR.InterpolatedOutput.PointXY_m(:,1);
GPR.('InterpolatedOutput').('Northing_m')=GPR.InterpolatedOutput.PointXY_m(:,2);
%Done

%% Visuailse projected data as XY points [overlaid on other ones)
figure();
hold on;
scatter(GPR.Easting_Raw_m,GPR.Northing_Raw_m,'r+','LineWidth',2);
scatter(GPR.Easting_Projected_Raw_m,GPR.Northing_Projected_Raw_m,'gx','LineWidth',2);
plot(GPR.InterpolatedOutput.Easting_m,GPR.InterpolatedOutput.Northing_m,'b','LineWidth',2);
hold off;
xlabel('Easting (m)');
ylabel('Northing (m)');
title('Plot of XY points after projection and interpolation');
legend({'Raw data','Projected data','Interpolated data'});
genericFigureScaling();
axis equal;
%Done

%% Visualise projected data as cross section
figure();
hold on;
scatter(GPR.PointProjectedDisplacementFromB1_Raw_m,GPR.Depth_Projected_Raw_m,'gx','LineWidth',2);
plot(GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m,GPR.InterpolatedOutput.Depth_m,'b','LineWidth',2);
hold off;
xlabel('Displacement along cross section (m)');
ylabel('Depth (m)');
title('Plot of depth points after projection and interpolation');
legend({'Projected data','Interpolated data'},'Location','SouthEast');
genericFigureScaling();
set(gca, 'YDir','reverse')
%Done

%% Save data
if(saveDataBool)
    %Create output cell string matrices
    if(strcmp(GPR.XS_Orientation,'LBtoRB'))
        %Make output cell string matrices for LBtoRB
        GPR.InterpolatedOutput.('OutputCellStrXYDepth_LBtoRB')=[{'Easting_m'},{'Northing_m'},{'Depth_m'};sprintfc('%0.3f',GPR.InterpolatedOutput.Easting_m),sprintfc('%0.3f',GPR.InterpolatedOutput.Northing_m),sprintfc('%0.3f',GPR.InterpolatedOutput.Depth_m)];
        GPR.InterpolatedOutput.('OutputCellStrDisplacementDepth_LBtoRB')=[{'CrossStreamDistanceLBtoRB_m'},{'Depth_m'};sprintfc('%0.3f',GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m),sprintfc('%0.3f',GPR.InterpolatedOutput.Depth_m)];
        %Done

        %Make output cell string matrices for RBtoLB
        GPR.InterpolatedOutput.('OutputCellStrXYDepth_RBtoLB')=[{'Easting_m'},{'Northing_m'},{'Depth_m'};sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Easting_m)),sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Northing_m)),sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Depth_m))];
        GPR.InterpolatedOutput.('OutputCellStrDisplacementDepth_RBtoLB')=[{'CrossStreamDistanceRBtoLB_m'},{'Depth_m'};sprintfc('%0.3f',GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m(end)-flipud(GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m)),sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Depth_m))];
        %Done
    else
        %Make output cell string matrices for LBtoRB
        GPR.InterpolatedOutput.('OutputCellStrXYDepth_LBtoRB')=[{'Easting_m'},{'Northing_m'},{'Depth_m'};sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Easting_m)),sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Northing_m)),sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Depth_m))];
        GPR.InterpolatedOutput.('OutputCellStrDisplacementDepth_LBtoRB')=[{'CrossStreamDistanceLBtoRB_m'},{'Depth_m'};sprintfc('%0.3f',GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m(end)-flipud(GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m)),sprintfc('%0.3f',flipud(GPR.InterpolatedOutput.Depth_m))];
        %Done

        %Make output cell string matrices for RBtoLB
        GPR.InterpolatedOutput.('OutputCellStrXYDepth_RBtoLB')=[{'Easting_m'},{'Northing_m'},{'Depth_m'};sprintfc('%0.3f',GPR.InterpolatedOutput.Easting_m),sprintfc('%0.3f',GPR.InterpolatedOutput.Northing_m),sprintfc('%0.3f',GPR.InterpolatedOutput.Depth_m)];
        GPR.InterpolatedOutput.('OutputCellStrDisplacementDepth_RBtoLB')=[{'CrossStreamDistanceRBtoLB_m'},{'Depth_m'};sprintfc('%0.3f',GPR.InterpolatedOutput.PointProjectedDisplacementFromB1_m),sprintfc('%0.3f',GPR.InterpolatedOutput.Depth_m)];
        %Done
    end
    %Done

    %Save the cell string matrices
    writecell(GPR.InterpolatedOutput.OutputCellStrXYDepth_LBtoRB,[ouputDataDir,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_GPR_CrossSection_XYDepth_LBtoRB.csv']);
    writecell(GPR.InterpolatedOutput.OutputCellStrDisplacementDepth_LBtoRB,[ouputDataDir,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_GPR_CrossSection_DisplacementDepth_LBtoRB.csv']);
    writecell(GPR.InterpolatedOutput.OutputCellStrXYDepth_RBtoLB,[ouputDataDir,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_GPR_CrossSection_XYDepth_RBtoLB.csv']);
    writecell(GPR.InterpolatedOutput.OutputCellStrDisplacementDepth_RBtoLB,[ouputDataDir,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_GPR_CrossSection_DisplacementDepth_RBtoLB.csv']);
    %Done

    %Save the matlab structure
    save([ouputDataDir,datestr(now(),'yyyy_mm_dd_HH_MM_ss'),'_GPR_CrossSectionStructure.mat'],'GPR');
    %Done
end
%Done

%% Save figures
if(saveFiguresBool)
    saveFiguresPNG2(outputFigureDir);
end
%Done