%% Video Stabilisation Using Point Feature Matching

%{
This is a basic stabilisation script where Point Feature Matching in user defined regions of interest is used to stabilise video.

Currently it just uses translation and rotation for stabilisation. Including scaling caused some problems (pulsating) and decreased the quality of the stabilisation.

Recommendations for a more advanced stabilisation algorithm (faster and smoother):
Skip frames, then interpolate rotation/matching between them. I.e. buffer frames, then match only every nth frame (i.e. 10th), then smooth transformation matrix between the n frames, then apply to each frame and write file.
Could also do it as a moving average on the translation matrix to remove high frequency errors (i.e. from point matching errors), but pick up the larger scale drone motion (i.e. altitude changes, drift, and minor rotation).
Also need to upgrade to relate the frame back to the original reference frame.

NOTES:
The image stabilisation in Fudaa LSPIV is excellent, and better than this basic Matlab script.
The image stabilisation in HydroSTIV is ok, but needs some improvement. Developers are going to add feature to select stable regions with polygons. This should speed up processing and improve accuracy.
%}

%% Code to build as standalone
if(~isdeployed())
    mcc('-m','videoStabilisation.m','-d','C:\Users\biggshj\OneDrive - NIWA\Projects\Matlab\ALL\FWWA2103 and ELF20508\Video Stabilisation\');
end
%Done

clear all;
close all;

%Profile code
%profile on;
%Done

%Options
noScaling=true;
viewMatching=false;
viewWarped=false;
ptThresh=0.1;
ptQuality=0.1;
nPointsToUse=3000;
warning('off','MATLAB:nearlySingularMatrix');
%Done

%Select input video
disp('Select video to stabilise');
[inputFilename,inputPathname] = uigetfile({'*.*','All Files (*.*)'},'Select video to stabilise','MultiSelect','off',getPreviousDir());
writeCurrentDir(inputPathname);%Remember last used directory for loading more videos
%Done

%Select output folder
disp('Select or create output directory');
[outputPathname] = uigetdir(getPreviousDir(),'Select or create output directory');
outputPathname=[outputPathname,'\'];
%Done

%% Load Video and Open Save File
hVideoSrc=vision.VideoFileReader([inputPathname,inputFilename]);
videoInfo=info(hVideoSrc);
dotIndices=strfind(inputFilename,'.');
outputFilename=[inputFilename(1:dotIndices(end)-1),'_stabilised'];
outputVideo=VideoWriter([outputPathname,outputFilename],'MPEG-4');
outputVideo.Quality=100;
outputVideo.FrameRate=videoInfo.VideoFrameRate;%Height and width are set automatically when writing the first frame
open(outputVideo);
Hcumulative=eye(3);%Initialise identity matrix
%Done

%Get first Image
colorImgA=step(hVideoSrc);
% Try to Convert to Grayscale
try
    imgA=rgb2gray(colorImgA);
    RGB=true;
catch % Image is not RGB
    imgA=colorImgA;
    RGB=false;
end
%Done

%Select areas of image where points can be found.
[ROIPolygons,~]=drawPolygonROIs(imgA);
%Done

%Create figure to show the movie
if(viewMatching)
    figHandle1=figure;
    figHandle2=figure;
end
%Done

% Loop Through Video
frameCounter=0;
while ~isDone(hVideoSrc)
    % Get Next Image
    colorImgB=step(hVideoSrc);
    % Convert to Grayscale
    if RGB
        imgB=rgb2gray(colorImgB);
    else
        imgB=colorImgB;
    end

    % Generate points
    pointsA=detectFASTFeatures(imgA,'MinContrast',ptThresh,'MinQuality',ptQuality);%Possibly try ORB features
    pointsB=detectFASTFeatures(imgB,'MinContrast',ptThresh,'MinQuality',ptQuality);
    [pointsA]=filterPointsByPolygons(pointsA,ROIPolygons);
    [pointsB]=filterPointsByPolygons(pointsB,ROIPolygons);
    pointsA=selectStrongest(pointsA,nPointsToUse);
    pointsB=selectStrongest(pointsB,nPointsToUse);
    %Done
    
    % Extract features and match pairs
    [featuresA,pointsA]=extractFeatures(imgA,pointsA);
    [featuresB,pointsB]=extractFeatures(imgB,pointsB);
    indexPairs=matchFeatures(featuresA,featuresB);
    matchedPointsA=pointsA(indexPairs(:,1),:);
    matchedPointsB=pointsB(indexPairs(:,2),:);
    %Done
    
    %Geometric transformation
    [tformForward]=estimateGeometricTransform(matchedPointsA,matchedPointsB,'affine');%Used for ROIPolygons
    [tformBackward]=estimateGeometricTransform(matchedPointsB,matchedPointsA,'affine');
    %Done
      
    %Extract Rotation & Translations
    H=tformBackward.T;
    R=H(1:2,1:2);
    theta=mean([atan2(R(2),R(1)),atan2(-R(3),R(4))]);
    if(noScaling)
        scale=1;
    else
        scale=mean(R([1,4])/cos(theta));
    end
    translation=H(3,1:2);
    %Done
    
    %Reconstitute Transform
    HsRt=[[scale*[cos(theta),-sin(theta);sin(theta),cos(theta)];translation],[0,0,1]'];
    Hcumulative=HsRt*Hcumulative;%Cumulative?? Or just the individual transformation? Tried comparing everything with base image and it was very messy unfortunately. Shakey etc.
    %Done
    
    %Perform Transformation on Color Image
    warpedImg=imwarp(colorImgB,affine2d(Hcumulative),'OutputView',imref2d(size(imgB)));
    ROIPolygonsTransformed=transformPolygons(ROIPolygons,tformForward);
    %Done
    
    %Show warped image as overlay
    if(viewWarped)
        figure(figHandle1); 
        imshowpair(colorImgA, warpedImg, 'montage');
        title(['First Frame', repmat(' ',[1 50]), 'Corrected Frame']);
    end
    %Done
    
    %Show matched points
    if(viewMatching)
        figure(figHandle2); 
        showMatchedFeatures(imgA,imgB,matchedPointsA,matchedPointsB);
        hold on;
        for i=1:length(ROIPolygons)
            patch('XData',ROIPolygons{i}(:,1),'YData',ROIPolygons{i}(:,2),'EdgeColor','green','FaceColor','none','LineWidth',2);
            patch('XData',ROIPolygonsTransformed{i}(:,1),'YData',ROIPolygonsTransformed{i}(:,2),'EdgeColor','red','FaceColor','none','LineWidth',2);
        end
        hold off;
        title('Matched inlier points');
    end
    %Done
    
    %Update the transformed polygons
    ROIPolygons=ROIPolygonsTransformed;
    %Done
    
    % Save Transformed Color Image to Video File
    writeVideo(outputVideo,warpedImg);
    %Done
    
    %Update counter and previous image
    frameCounter=frameCounter+1;
    imgA = imgB;
    disp(['Processed frame ',num2str(frameCounter)]);
    %Done
end
close(outputVideo);
disp('Finished processing the video. Close this window.');
%Done

%Profile view
%profile viewer;
%Done

function [outputPolygons]=transformPolygons(inputPolygons,inputTransform)
    %Function to transform polygon coordinates
    
    %Test
    %inputTransform.T(3,2)=-inputTransform.T(3,2);%Y dimension flipped for image coordinates
    
    %Check if only one input polygon
    if(~iscell(inputPolygons))
        inputPolygons={inputPolygons};
    end
    %Done
    
    %Loop through polygons
    nPolygons=length(inputPolygons);
    temp=cell(nPolygons,1);
    for i=1:nPolygons
        [X,Y] = transformPointsForward(inputTransform,inputPolygons{i}(:,1),inputPolygons{i}(:,2));%Going the wrong way.... Why? Issue with direction of image y axis?
        %[X,Y] = transformPointsForward(inputTransform,inputPolygons{i}(:,1),-inputPolygons{i}(:,2));%Going the wrong way.... Why? Issue with direction of image y axis?
        temp{i}=[X,Y];
        %temp{i}=[X,-Y];
    end
    %Done
    
    %Output
    outputPolygons=temp;
    %Done
end

function [filteredPoints]=filterPointsByPolygons(inputPoints,inputPolygons)
    %Function to filter key points based on whether they are contained within specified polygons
    %Polygons input as a cell array, where each item of the cell array is a matrix consisting of [Xv,Yv] where the columns are the X and Y coordinates of vertices.
    pointsX=inputPoints.Location(:,1);
    pointsY=inputPoints.Location(:,2);
    nPoints=length(pointsX);
    nPolygons=length(inputPolygons);
    insideBool=false(nPoints,1);
    for i=1:nPolygons
        insideBool=insideBool|inpolygon(pointsX,pointsY,inputPolygons{i}(:,1),inputPolygons{i}(:,2));
    end
    filteredPoints=inputPoints(insideBool);
    %Done
end

function [outputPolygons,outputBinaryMask]=drawPolygonROIs(inputImage)
    %Function takes an input image and allows the user to draw a polygon with a GUI.
        
    %Initialise
    enterPressed=false;otherKeyPressed=false;%Inialise key press variables to share with nested functions.
    figure('KeyPressFcn',@Key_Down,'KeyReleaseFcn',@Key_Up);
    warning('off','images:initSize:adjustingMag');%Just to supress warning messages about image size and display.
    imshow(inputImage);
    set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
    %Done
    
    %Setup data structures
    allPolygons=cell(10000,1);%No more than 10,000.
    %Done
    
    %Get all the polygons
    continueSelecting=true;
    polygonIndex=1;
    while(continueSelecting)
        title('Zoom and pan to ROI, then press any key to draw polygon');
        enterPressed=false;otherKeyPressed=false;
        while(~enterPressed&&~otherKeyPressed)
            pause(0.1);%Pause to allow figure interaction
        end
        title('Draw polygon');
        allPolygons{polygonIndex}=drawpolygon(gca);
        title('Editing polygons, press any key to finish');
        enterPressed=false;otherKeyPressed=false;
        while(~enterPressed&&~otherKeyPressed)
            pause(0.1);%Pause to allow figure interaction
        end
        title('Press enter to select another polygon, or press any other key to finish');
        enterPressed=false;otherKeyPressed=false;
        while(~enterPressed&&~otherKeyPressed)
            pause(0.1);%Pause to allow figure interaction
        end
        pause(0.1);
        if(~enterPressed)
            title('Finished selecting points');
            continueSelecting=false;
            break;
        end
        polygonIndex=polygonIndex+1;
    end
    %Done
    
    %Remove empty cells
    allPolygons=allPolygons(~cellfun('isempty',allPolygons));
    %Done
    
    %Extract standard polygons from interactive polygons
    outputPolygons=cell(size(allPolygons));
    for i=1:length(outputPolygons)
        outputPolygons{i}=allPolygons{i}.Position;
    end
    %Done
    
    %Create binary mask
    outputBinaryMask=false(size(inputImage,1),size(inputImage,2));
    for i=1:length(outputPolygons)
        tempBinaryMask=poly2mask(outputPolygons{i}(:,1),outputPolygons{i}(:,2),size(inputImage,1),size(inputImage,2));
        outputBinaryMask=outputBinaryMask|tempBinaryMask;
    end
    %Done

    %Sub functions to handle key press events
    function [] =  Key_Down(~,event)
        %Call back of keys from keyboard
        if(strcmp(event.Key,'return'))
            enterPressed=true;
        else
            otherKeyPressed=true;
        end
    end
    function [] = Key_Up(~,~)
    end
    %Done

    %Done, function works well!
end

function lastDir=getPreviousDir()
    %Function to read the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=mfilename('fullpath');
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'r');%Will open the file for reading if it exists
    if(fHandle==-1)
        lastDir=pwd;
    else
        allData=textscan(fHandle,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
        fclose(fHandle);
        if(iscell(allData))
            allData=allData{1};%Unpack it
        end
        if(iscell(allData))
            allData=allData{1};%Unpack it twice sometimes needed...
        end
        if(contains(allData,'\'))
            slashIndices=strfind(allData,'\');
            tempPath=allData(1:slashIndices(end));
            if(isfolder(tempPath))
                lastDir=tempPath;
            else
                lastDir=pwd;
            end            
        else
            lastDir=pwd;
        end
        %Done
    end
    %Done
end

function writeCurrentDir(currentDir)
    %Function to record the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=matlab.desktop.editor.getActiveFilename;
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        warning(['Could not write the last used directory to ',[scriptPath,nameOfStorageFile],' please check this file isn''t already open or similar']);
    else
        fprintf(fHandle,'%s',currentDir);
        fclose(fHandle);
    end
    %Done
end