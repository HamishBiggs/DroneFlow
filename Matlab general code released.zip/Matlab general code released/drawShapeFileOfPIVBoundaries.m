function [outputPolygons,outputBinaryMask]=drawShapeFileOfPIVBoundaries(inputImage)
    %{
        Function takes an input image and allows the user to draw a polygon with a GUI.
        This could then be converted into a shape file (with spatial data attached).

        
    %}
    %Initialise
    enterPressed=false;otherKeyPressed=false;%Inialise key press variables to share with nested functions.
    figure('KeyPressFcn',@Key_Down,'KeyReleaseFcn',@Key_Up);
    warning('off','images:initSize:adjustingMag');%Just to supress warning messages about image size and display.
    if(size(inputImage,3)>3)
        imshow(uint8(inputImage(:,:,1:3)));%For .tif images with more bands
    else
        imshow(uint8(inputImage));
    end
    set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
    %Done
    
    %Setup data structures
    allPolygons=cell(10000,1);%No more than 10,000.
    %Done
    
    %Get all the polygons
    continueSelecting=true;
    polygonIndex=1;
    while(continueSelecting)
        title('Zoom and pan to ROI, then press any key to draw polygon');
        enterPressed=false;otherKeyPressed=false;
        while(~enterPressed&&~otherKeyPressed)
            pause(0.1);%Pause to allow figure interaction
        end
        title('Draw polygon');
        allPolygons{polygonIndex}=drawpolygon(gca);
        title('Editing polygons, press any key to finish');
        enterPressed=false;otherKeyPressed=false;
        while(~enterPressed&&~otherKeyPressed)
            pause(0.1);%Pause to allow figure interaction
        end
        title('Press enter to select another polygon, or press any other key to finish');
        enterPressed=false;otherKeyPressed=false;
        while(~enterPressed&&~otherKeyPressed)
            pause(0.1);%Pause to allow figure interaction
        end
        pause(0.1);
        if(~enterPressed)
            title('Finished selecting points');
            continueSelecting=false;
            break;
        end
        polygonIndex=polygonIndex+1;
    end
    %Done
    
    %Remove empty cells
    allPolygons=allPolygons(~cellfun('isempty',allPolygons));
    %Done
    
    %Extract standard polygons from interactive polygons
    outputPolygons=cell(size(allPolygons));
    for i=1:length(outputPolygons)
        outputPolygons{i}=allPolygons{i}.Position;
    end
    %Done
    
    %Create binary mask
    outputBinaryMask=false(size(inputImage,1),size(inputImage,2));
    for i=1:length(outputPolygons)
        tempBinaryMask=poly2mask(outputPolygons{i}(:,1),outputPolygons{i}(:,2),size(inputImage,1),size(inputImage,2));
        outputBinaryMask=outputBinaryMask|tempBinaryMask;
    end
    %Done

    %Sub functions to handle key press events
    function [] =  Key_Down(~,event)
        %Call back of keys from keyboard
        if(strcmp(event.Key,'return'))
            enterPressed=true;
        else
            otherKeyPressed=true;
        end
    end
    function [] = Key_Up(~,~)
    end
    %Done

    %Done, function works well!
end