function lastDir=getPreviousDir()
    %Function to read the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=mfilename('fullpath');
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'r');%Will open the file for reading if it exists
    if(fHandle==-1)
        lastDir=pwd;
    else
        allData=textscan(fHandle,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
        fclose(fHandle);
        if(iscell(allData))
            allData=allData{1};%Unpack it
        end
        if(iscell(allData))
            allData=allData{1};%Unpack it twice sometimes needed...
        end
        if(contains(allData,'\'))
            slashIndices=strfind(allData,'\');
            tempPath=allData(1:slashIndices(end));
            if(isfolder(tempPath))
                lastDir=tempPath;
            else
                lastDir=pwd;
            end            
        else
            lastDir=pwd;
        end
        %Done
    end
    %Done
end