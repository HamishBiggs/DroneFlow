function writeCurrentDir(currentDir)
    %Function to record the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=matlab.desktop.editor.getActiveFilename;
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        warning(['Could not write the last used directory to ',[scriptPath,nameOfStorageFile],' please check this file isn''t already open or similar']);
    else
        fprintf(fHandle,'%s',currentDir);
        fclose(fHandle);
    end
    %Done
end