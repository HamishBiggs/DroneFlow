function [imageHeight_mm,imageWidth_mm,squareHeight_mm,squareWidth_mm]=generateCalibrationTargetImage2(squaresHigh,squaresWide,pixelsPerSquareSide,printerDPI,topAndBottomBorderPixels,sideBorderPixels,firstSquareBlackBool)
    %[imageHeight_mm,imageWidth_mm,squareHeight_mm,squareWidth_mm]=generateCalibrationTargetImage(8,8,1772,300,1000,1000,true)
    %For defined square size use pixelsPerSquareSide=round(printerDPI*inchesPerMm*squareHeight_mm); i.e. pixelsPerSquareSide=round(300*0.03937007874*150)=1772 however, this will not be exact, so use the output numbers.
    %Not sure how to make printers print images in defined DPI rather than rescaling etc? However, at least this function produces quality checkerboards of any size. :)
    
    %Select the output directory
    global lastOutputPathname;
    if isempty(lastOutputPathname) 
        outputPathname=uigetdir([pwd(),'\'],'Select output directory to save the calibration target');
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    else
        outputPathname=uigetdir(lastOutputPathname,'Select output directory to save the calibration target');
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    end
    %Done

    %Generate and save image
    calImage=uint8(255*ones(squaresHigh*pixelsPerSquareSide+2*topAndBottomBorderPixels,squaresWide*pixelsPerSquareSide+2*sideBorderPixels));
    rowStarts=[0:(squaresHigh-1)]'*pixelsPerSquareSide+1+topAndBottomBorderPixels;
    rowEnds=[1:squaresHigh]'*pixelsPerSquareSide+topAndBottomBorderPixels;
    colStarts=[0:(squaresWide-1)]'*pixelsPerSquareSide+1+sideBorderPixels;
    colEnds=[1:squaresWide]'*pixelsPerSquareSide+sideBorderPixels;
    if(firstSquareBlackBool)
        writeBlackBool=true;
        rowStartBlackBool=true;
    else
        writeBlackBool=false;
        rowStartBlackBool=false;
    end
    for(rowIndex=1:squaresHigh)
        for(colIndex=1:squaresWide)
            if(writeBlackBool)
                calImage(rowStarts(rowIndex):rowEnds(rowIndex),colStarts(colIndex):colEnds(colIndex))=0;
            end
            writeBlackBool=~writeBlackBool;
        end
        rowStartBlackBool=~rowStartBlackBool;
        writeBlackBool=rowStartBlackBool;
    end
    imwrite(calImage,[outputPathname,'CalibrationTarget.png']);
    imwrite(calImage,[outputPathname,'CalibrationTarget.jpg'],'Quality',100);
    %Done
    
    %Estimate image size based on printerDPI
    %1 millimeter is equal to 0.03937007874 inches
    inchesPerMm=0.03937007874;
    imageHeight_mm=((squaresHigh*pixelsPerSquareSide+2*topAndBottomBorderPixels)/printerDPI)/inchesPerMm;
    imageWidth_mm=((squaresWide*pixelsPerSquareSide+2*sideBorderPixels)/printerDPI)/inchesPerMm;
    squareHeight_mm=(pixelsPerSquareSide/printerDPI)/inchesPerMm;
    squareWidth_mm=(pixelsPerSquareSide/printerDPI)/inchesPerMm;
    %Done
end