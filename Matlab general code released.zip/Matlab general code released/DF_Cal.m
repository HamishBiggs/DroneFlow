%DroneFlow Calibraion Class for stereocamera data.

classdef DF_Cal
    properties
        
    end
    methods(Static)
        function [outputStereoParams,primaryCameraImagesUsed,secondaryCameraImagesUsed,outputEstimationErrors]=performCalibration(checkerboardSquareSize_mm)
            %Function to streamline camera calibration
            
            %The NIWA calibration target has 183.4 mm squares.
            if(isempty(checkerboardSquareSize_mm))
                checkerboardSquareSize_mm=183.4;
            end
            %Done
            
            %% Select calibration images
            %Select primary images
            global lastInputPathname; %#ok<*NUSED>
            if(isempty(lastInputPathname))
                lastInputPathname='O:\END19505\Working\Hardware\Stereoscopic camera\Calibration\';
            end
            [filenamesOfPrimaryImages,pathnameOfPrimaryImages]=selectInputImages('Select calibration images from primary camera');
            filenamesAndPathsOfPrimaryImages=strcat(pathnameOfPrimaryImages,filenamesOfPrimaryImages);
            lastInputPathname=pathnameOfPrimaryImages;
            nImagePairs=length(filenamesOfPrimaryImages);
            %Done

            %Select secondary images
            [filenamesOfSecondaryImages,pathnameOfSecondaryImages]=selectInputImages('Select calibration images from secondary camera');
            filenamesAndPathsOfSecondaryImages=strcat(pathnameOfSecondaryImages,filenamesOfSecondaryImages);
            lastInputPathname=pathnameOfSecondaryImages;
            if(length(filenamesOfSecondaryImages)~=nImagePairs)
                error('Error in DF_Cal.performCalibration() number of primary images not equal to number of secondary images');
            end
            %Done

            %% Get image numbers and compare to ensure all the pairs are the same
            %Expected format: DF_PRIMARY_00414.tiff or DF_PRIMARY_00414.jpg
            imageNumsPrimary=zeros(nImagePairs,1);
            imageNumsSecondary=zeros(nImagePairs,1);
            for i=1:nImagePairs
                primaryUnderscores=strfind(filenamesOfPrimaryImages{i},'_');
                secondaryUnderscores=strfind(filenamesOfSecondaryImages{i},'_');
                imageNumsPrimary(i)=str2double(filenamesOfPrimaryImages{i}(primaryUnderscores(end)+1:primaryUnderscores(end)+5));
                imageNumsSecondary(i)=str2double(filenamesOfSecondaryImages{i}(secondaryUnderscores(end)+1:secondaryUnderscores(end)+5));
            end
            if(sum(imageNumsPrimary==imageNumsSecondary)~=nImagePairs)
                error('Error in DF_Cal.performCalibration() image pairs do not correspond, function designed to select all corresponding image pairs. Redesign function if internal pair matching wanted.');
            end
            %Done

            % Detect checkerboards in images
            disp('Computing stereo calibration....');
            [imagePoints,boardSize,imagesUsed]=detectCheckerboardPoints(filenamesAndPathsOfPrimaryImages,filenamesAndPathsOfSecondaryImages);
            %Done

            % Generate world coordinates of the checkerboard keypoints
            worldPoints=generateCheckerboardPoints(boardSize,checkerboardSquareSize_mm);
            %Done

            % Read one of the images from the first stereo pair
            I1=imread(filenamesAndPathsOfPrimaryImages{1});
            [mrows,ncols,~]=size(I1);

            % Calibrate the camera
            [stereoParams,pairsUsed,estimationErrors]=estimateCameraParameters(imagePoints,worldPoints,...
                'EstimateSkew',true,'EstimateTangentialDistortion',true,...
                'NumRadialDistortionCoefficients',3,'WorldUnits','millimeters',...
                'InitialIntrinsicMatrix',[],'InitialRadialDistortion',[],...
                'ImageSize',[mrows,ncols]);
            %Done

            % View reprojection errors
            h1=figure;showReprojectionErrors(stereoParams);
            %Done

            % Visualize pattern locations
            h2=figure;showExtrinsics(stereoParams,'CameraCentric');
            %Done

            % Display parameter estimation errors
            displayErrors(estimationErrors,stereoParams);
            %Done

            % You can use the calibration data to rectify stereo images.
            %I2 = imread(filenamesAndPathsOfSecondaryImages{1});
            %[J1, J2] = rectifyStereoImages(I1, I2, stereoParams);
            %Done
            
            %Output
            outputStereoParams=stereoParams;
            primaryCameraImagesUsed=filenamesAndPathsOfPrimaryImages(pairsUsed);
            secondaryCameraImagesUsed=filenamesAndPathsOfSecondaryImages(pairsUsed);
            outputEstimationErrors=estimationErrors;
            disp('Calibration complete!');
            %Done
            
            %Subfunction to clean up image selection
            function [filenamesOfImages,pathnameOfImages]=selectInputImages(selectImageString)
                %global lastInputPathname;%Retain directory locations for faster processing of multiple folders.

                if isempty(lastInputPathname) 
                    % First time calling 'uigetfile', use the pwd
                    [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                    selectImageString, ...
                    'MultiSelect', 'on');
                    lastInputPathname=pathnameOfImages;
                else
                    %Repeated call to 'uigetfile', start at the same directory as last selection
                    [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                    selectImageString, ...
                    'MultiSelect', 'on',lastInputPathname);
                    lastInputPathname=pathnameOfImages;
                end
                if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
                    filenamesOfImages={filenamesOfImages};
                end
                %Done
            end
            %Done works well.
        end
        function preprocessCalibration(numberOfCheckerboardSquares)
            %DF_CalibrationTestScript is to test calibration code
            %{
            To do:
                Convert from raw to tiff and save in subfolder with image info extracted. DF_Cam.preProcessRaw(searchStartPath,imageWidth,imageHeight) [DONE]
                Select folders of calibration files [in .tiff (preferable) or .jpg format] (with GUI). [DONE]
                Detect checker board in all images. [DONE]
                Compare file pairs to see if checkerboard is visible in both sets of imagery. [DONE]
                Data on where checkerboard is located? I.e. to only transfer a selection of image pairs with good distribution around the calibration target? [DONE]
                Copy pairs and rename with a simple index suffix into a Primary and Secondary folder. [DONE]
            %}

            %% Select calibration images
            %Select primary images
            global lastInputPathname; %#ok<*NUSED>
            if(isempty(lastInputPathname))
                lastInputPathname='O:\END19505\Working\Hardware\Stereoscopic camera\Calibration\';
            end
            [filenamesOfPrimaryImages,pathnameOfPrimaryImages]=selectInputImages('Select calibration images from primary camera');
            lastInputPathname=pathnameOfPrimaryImages;
            nImagePairs=length(filenamesOfPrimaryImages);
            %Done

            %Select secondary images
            [filenamesOfSecondaryImages,pathnameOfSecondaryImages]=selectInputImages('Select calibration images from secondary camera');
            lastInputPathname=pathnameOfSecondaryImages;
            if(length(filenamesOfSecondaryImages)~=nImagePairs)
                error('Error in DF_Cal.preprocessCalibration() number of primary images not equal to number of secondary images');
            end
            %Done

            %% Get image numbers and compare to ensure all the pairs are the same
            %Expected format: DF_PRIMARY_00414.tiff or DF_PRIMARY_00414.jpg
            imageNumsPrimary=zeros(nImagePairs,1);
            imageNumsSecondary=zeros(nImagePairs,1);
            for i=1:nImagePairs
                primaryUnderscores=strfind(filenamesOfPrimaryImages{i},'_');
                secondaryUnderscores=strfind(filenamesOfSecondaryImages{i},'_');
                imageNumsPrimary(i)=str2double(filenamesOfPrimaryImages{i}(primaryUnderscores(end)+1:primaryUnderscores(end)+5));
                imageNumsSecondary(i)=str2double(filenamesOfSecondaryImages{i}(secondaryUnderscores(end)+1:secondaryUnderscores(end)+5));
            end
            if(sum(imageNumsPrimary==imageNumsSecondary)~=nImagePairs)
                error('Error in DF_Cal.preprocessCalibration() image pairs do not correspond, function designed to select all corresponding image pairs. Redesign function if internal pair matching wanted.');
            end
            %Expect to select all images, or a block of images down to a certain level. I.e. with all matching pairs. Could easily add functionality to discard non matched images.
            %Done

            %% Next detect checkerboard. Can do it all at once, but is not as convenient as for each pair.
            %disp('Detecting checkerboard points');
            %[imagePoints,boardSize,pairsUsed] = detectCheckerboardPoints(strcat(pathnameOfPrimaryImages,filenamesOfPrimaryImages),strcat(pathnameOfSecondaryImages,filenamesOfSecondaryImages));%Can increase the corner detection threshold if needed to remove false positives. Default is: ,'MinCornerMetric',0.15
            %disp('Done');
            %Done

            %% Next detect checkerboard. Loop through images.
            boardHeightPrimary=zeros(nImagePairs,1);
            boardWidthPrimary=zeros(nImagePairs,1);
            checkerboardCoordsXPrimary=cell(nImagePairs,1);
            checkerboardCoordsYPrimary=cell(nImagePairs,1);
            boardHeightSecondary=zeros(nImagePairs,1);
            boardWidthSecondary=zeros(nImagePairs,1);
            checkerboardCoordsXSecondary=cell(nImagePairs,1);
            checkerboardCoordsYSecondary=cell(nImagePairs,1);
            goodPairBool=false(nImagePairs,1);
            boardNSquares=zeros(nImagePairs,1);
            boardNIntersects=zeros(nImagePairs,1);
            boardCentreProportionX=zeros(nImagePairs,1);
            boardCentreProportionY=zeros(nImagePairs,1);
            areaPrimary=zeros(nImagePairs,1);
            areaSecondary=zeros(nImagePairs,1);
            boardScaling=zeros(nImagePairs,1);

            for i=1:nImagePairs
                disp(['Detecting checkerboard points in image pair ',num2str(i),' of ',num2str(nImagePairs)]);
                primaryImage=imread([pathnameOfPrimaryImages,filenamesOfPrimaryImages{i}]);
                %secondaryImage=imread([pathnameOfSecondaryImages,filenamesOfSecondaryImages{i}]);

                [imagePoints,boardSize,pairsUsed] = detectCheckerboardPoints([pathnameOfPrimaryImages,filenamesOfPrimaryImages{i}],[pathnameOfSecondaryImages,filenamesOfSecondaryImages{i}],'MinCornerMetric',0.3);%Can increase the corner detection threshold if needed to remove false positives. Default is: ,'MinCornerMetric',0.15
                boardNSquares(i)=boardSize(1)*boardSize(2);
                % Check if images show the full checkerboard. I.e. get the non-zero mode of checkerboard points and exclude other images.
                if(~pairsUsed||(boardNSquares(i)~=numberOfCheckerboardSquares))
                    boardHeightPrimary(i)=NaN;
                    boardWidthPrimary(i)=NaN;
                    checkerboardCoordsXPrimary{i}=NaN;
                    checkerboardCoordsYPrimary{i}=NaN;
                    boardHeightSecondary(i)=NaN;
                    boardWidthSecondary(i)=NaN;
                    checkerboardCoordsXSecondary{i}=NaN;
                    checkerboardCoordsYSecondary{i}=NaN;
                    goodPairBool(i)=false;
                    boardNIntersects(i)=NaN;
                    boardCentreProportionX(i)=NaN;
                    boardCentreProportionY(i)=NaN;
                    boardScaling(i)=NaN;
                else
                    boardHeightPrimary(i)=boardSize(1);
                    boardWidthPrimary(i)=boardSize(2);
                    checkerboardCoordsXPrimary{i}=reshape(imagePoints(:,1,1,1),boardSize-1);
                    checkerboardCoordsYPrimary{i}=reshape(imagePoints(:,2,1,1),boardSize-1);
                    boardHeightSecondary(i)=boardSize(1);
                    boardWidthSecondary(i)=boardSize(2);
                    checkerboardCoordsXSecondary{i}=reshape(imagePoints(:,1,1,2),boardSize-1);
                    checkerboardCoordsYSecondary{i}=reshape(imagePoints(:,2,1,2),boardSize-1);
                    goodPairBool(i)=true;
                    boardNIntersects(i)=(boardSize(1)-1)*(boardSize(2)-1);
                    boardCentreProportionX(i)=mean([checkerboardCoordsXPrimary{i}(:);checkerboardCoordsXSecondary{i}(:)])/size(primaryImage,2);%Get the average centre point X coord of checkerboard intercepts as a proportion of image.
                    boardCentreProportionY(i)=mean([checkerboardCoordsYPrimary{i}(:);checkerboardCoordsYSecondary{i}(:)])/size(primaryImage,1);%Get the average centre point X coord of checkerboard intercepts as a proportion of image.
                    areaPrimary(i)=polyarea([checkerboardCoordsXPrimary{i}(1,1);checkerboardCoordsXPrimary{i}(1,end);checkerboardCoordsXPrimary{i}(end,end);checkerboardCoordsXPrimary{i}(end,1)],...
                                         [checkerboardCoordsYPrimary{i}(1,1);checkerboardCoordsYPrimary{i}(1,end);checkerboardCoordsYPrimary{i}(end,end);checkerboardCoordsYPrimary{i}(end,1)]);
                    areaSecondary(i)=polyarea([checkerboardCoordsXSecondary{i}(1,1);checkerboardCoordsXSecondary{i}(1,end);checkerboardCoordsXSecondary{i}(end,end);checkerboardCoordsXSecondary{i}(end,1)],...
                                           [checkerboardCoordsYSecondary{i}(1,1);checkerboardCoordsYSecondary{i}(1,end);checkerboardCoordsYSecondary{i}(end,end);checkerboardCoordsYSecondary{i}(end,1)]);
                    boardScaling(i)=mean([areaPrimary(i);areaSecondary(i)])/(size(primaryImage,1)*size(primaryImage,2));%Calculate average area of checkerboard divided by area of image.
                end

                %{
                if(goodPairBool(i))
                    figure();
                    hold on;
                    %imshow([pathnameOfPrimaryImages,filenamesOfPrimaryImages{i}],'Parent',gca());
                    imshow(primaryImage,'Parent',gca());
                    plot(gca(),checkerboardCoordsXPrimary{i}(:),checkerboardCoordsYPrimary{i}(:),'Marker','x','MarkerSize',20,'Color','r','LineStyle','none');
                    plot(gca(),checkerboardCoordsXSecondary{i}(:),checkerboardCoordsYSecondary{i}(:),'Marker','x','MarkerSize',20,'Color','g','LineStyle','none');
                    plot(gca(),boardCentreProportionX(i)*size(primaryImage,2),boardCentreProportionY(i)*size(primaryImage,1),'Marker','*','MarkerSize',1000*boardScaling(i),'Color','b','LineStyle','none');
                    hold off;
                    genericFigureScaling();
                end
               %}
            end
            disp('Done');
            %Done

            %% Then auto select 30 images based on a mixture of board scale and centre position. :)
            %First show distribution of data
            figure();
            scatter(boardCentreProportionX*size(primaryImage,2),boardCentreProportionY*size(primaryImage,1),4000*boardScaling,'Marker','*');
            xlim([0,size(primaryImage,2)]);
            ylim([0,size(primaryImage,1)]);
            set(gca,'Ydir','reverse')
            genericFigureScaling();
            %Done

            %Divide image into squares. i.e. 6 wide and 5 tall.
            squaresWide=6;
            squaresHigh=5;
            imageHeight=size(primaryImage,1);
            imageWidth=size(primaryImage,2);
            squareEdgesX=linspace(0,imageWidth,squaresWide+1);
            squareEdgesY=linspace(0,imageHeight,squaresHigh+1);
            squareCentresX=(squareEdgesX(1:end-1)+squareEdgesX(2:end))/2;
            squareCentresY=(squareEdgesY(1:end-1)+squareEdgesY(2:end))/2;
            nSquareCentres=length(squareCentresX)*length(squareCentresY);
            squareCentresXVector=zeros(nSquareCentres,1);
            squareCentresYVector=zeros(nSquareCentres,1);
            %Done

            %Find distance from centre of each square to each of the checkerboards.
            %Then sort the distances.
            squareToCheckerboardDistance=cell(nSquareCentres,1);
            squareToCheckerboardIDX=cell(nSquareCentres,1);
            squareCounter=1;
            for i=1:length(squareCentresX)%Loop by height first then outer is width
                for j=1:length(squareCentresY)
                    squareToCheckerboardDistance{squareCounter}=((squareCentresX(i)-boardCentreProportionX*size(primaryImage,2)).^2+(squareCentresY(j)-boardCentreProportionY*size(primaryImage,1)).^2).^0.5;
                    squareToCheckerboardIDX{squareCounter}=(1:nImagePairs)';
                    [squareToCheckerboardDistance{squareCounter},sortIDX]=sort(squareToCheckerboardDistance{squareCounter});
                    squareToCheckerboardIDX{squareCounter}=squareToCheckerboardIDX{squareCounter}(sortIDX);
                    squareCentresXVector(squareCounter)=squareCentresX(i);
                    squareCentresYVector(squareCounter)=squareCentresY(j);
                    squareCounter=squareCounter+1;
                end
            end
            %Done

            %Need special case if less than 30 pairs of images with checkerboards.
            if(sum(goodPairBool)<nSquareCentres)
                error(['Error in DF_Cal.preprocessCalibration() there are less than ',num2str(nSquareCentres),' checkerboard pairs']);  
            end

            %Now need to allocate most suitable images
            %Going to do a quick and hobo way of this, rather than something elegant but time consuming.
            %I.e. a first come first served approach.
            tempSquareToCheckerboardIDX=[squareToCheckerboardIDX{:}];
            tempSquareToCheckerboardIDX=tempSquareToCheckerboardIDX(1,:)';
            finalSquareToCheckerboardIDX=zeros(nSquareCentres,1);
            for i=1:nSquareCentres
                %First do unique numbers. Then handle non unique.
                if(~any(tempSquareToCheckerboardIDX(i)==finalSquareToCheckerboardIDX))
                    finalSquareToCheckerboardIDX(i)=tempSquareToCheckerboardIDX(i);
                else
                    uniqueBool=false;
                    checkerboardCounter=2;%Check the second closest checkerboard
                    while(~uniqueBool)
                        if(~any(squareToCheckerboardIDX{i}(checkerboardCounter)==finalSquareToCheckerboardIDX))
                            finalSquareToCheckerboardIDX(i)=squareToCheckerboardIDX{i}(checkerboardCounter);
                            uniqueBool=true;
                        elseif(checkerboardCounter==nImagePairs)
                            error('Error in DF_Cal.preprocessCalibration() problem assigning checkerboards to image locations');
                        end
                        checkerboardCounter=checkerboardCounter+1;
                    end
                end
            end
            %Done

            %Visualise best images of checkerboards
            figure();
            hold on;
            scatter(boardCentreProportionX(finalSquareToCheckerboardIDX)*size(primaryImage,2),boardCentreProportionY(finalSquareToCheckerboardIDX)*size(primaryImage,1),4000*boardScaling(finalSquareToCheckerboardIDX),'Marker','*');
            plot(boardCentreProportionX()*size(primaryImage,2),boardCentreProportionY()*size(primaryImage,1),'Color','r','Marker','x','LineStyle','none','MarkerSize',20);
            plot(squareCentresXVector,squareCentresYVector,'Color','k','Marker','+','LineStyle','none','MarkerSize',20);
            xlim([0,size(primaryImage,2)]);
            ylim([0,size(primaryImage,1)]);
            hold off;
            set(gca,'Ydir','reverse')
            genericFigureScaling();
            %Done

            %Save the good chekerboards to another folder
            timeString=num2str(floor(posixtime(datetime('now','TimeZone','local'))));
            outputPathnameOfPrimaryImages=[pathnameOfPrimaryImages,'Cal_',timeString,'/'];
            outputPathnameOfSecondaryImages=[pathnameOfSecondaryImages,'Cal_',timeString,'/'];
            mkdir(outputPathnameOfPrimaryImages);
            mkdir(outputPathnameOfSecondaryImages);
            for i=1:nSquareCentres
                copyfile([pathnameOfPrimaryImages,filenamesOfPrimaryImages{finalSquareToCheckerboardIDX(i)}],[outputPathnameOfPrimaryImages,filenamesOfPrimaryImages{finalSquareToCheckerboardIDX(i)}]);
                copyfile([pathnameOfSecondaryImages,filenamesOfSecondaryImages{finalSquareToCheckerboardIDX(i)}],[outputPathnameOfSecondaryImages,filenamesOfSecondaryImages{finalSquareToCheckerboardIDX(i)}]);
            end
            %Done

            %Subfunction to clean up image selection
            function [filenamesOfImages,pathnameOfImages]=selectInputImages(selectImageString)
                %global lastInputPathname;%Retain directory locations for faster processing of multiple folders.

                if isempty(lastInputPathname) 
                    % First time calling 'uigetfile', use the pwd
                    [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                    selectImageString, ...
                    'MultiSelect', 'on');
                    lastInputPathname=pathnameOfImages;
                else
                    %Repeated call to 'uigetfile', start at the same directory as last selection
                    [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
                    selectImageString, ...
                    'MultiSelect', 'on',lastInputPathname);
                    lastInputPathname=pathnameOfImages;
                end
                if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
                    filenamesOfImages={filenamesOfImages};
                end
                %Done
            end
            %Done
            
            %Works well! Very useful to automatically find and move good calibration images.
        end
    end
end