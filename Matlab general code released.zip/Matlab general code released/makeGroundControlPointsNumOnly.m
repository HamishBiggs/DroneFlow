%This is a test script to play with matlabs inbuilt functions

clear all;
%close all;

%Step 1: Define file paths
rawImagePath='C:\Users\biggshj\OneDrive - NIWA\Projects\Matlab\ALL\GCPs\Raw Images\';
outputImagePath='C:\Users\biggshj\OneDrive - NIWA\Projects\Matlab\ALL\GCPs\Output Images 2\';
templateName='Template2.png';
%Done

%Step 2: Load the template and sub images
template=imread([rawImagePath,templateName]);
image(template);
for i=0:9
    nI.(['N',num2str(i)])=imresize(imread([rawImagePath,num2str(i),'.png']),3.8);%numberImages
end
%Done

%Step 3: Cycle through the output
for i=0:9
    for j=0:9
        tempImage=template;
        %Write first digit
        tempImage(1:1+size(nI.(['N',num2str(i)]),1)-1,30:30+size(nI.(['N',num2str(i)]),2)-1,:)=nI.(['N',num2str(i)])(:,:,:);
        %Done
        %Write second digit
        tempImage(1:1+size(nI.(['N',num2str(j)]),1)-1,630:630+size(nI.(['N',num2str(j)]),2)-1,:)=nI.(['N',num2str(j)])(:,:,:);
        %Done
        %Now save output
        imwrite(tempImage,[outputImagePath,num2str(i),num2str(j),'.png']);
    end
end
        

%{
%Rough template
output01=template;
output01(100:100+size(nI.N0,1)-1,100:100+size(nI.N0,2)-1,:)=nI.N0(:,:,:);
output01(500:500+size(nI.N0,1)-1,100:100+size(nI.N0,2)-1,:)=nI.N0(:,:,:);
output01(100:100+size(nI.N0,1)-1,700:700+size(nI.N0,2)-1,:)=nI.N0(:,:,:);
output01(500:500+size(nI.N0,1)-1,700:700+size(nI.N0,2)-1,:)=nI.N0(:,:,:);

output01(100:100+size(nI.N0,1)-1,250:250+size(nI.N0,2)-1,:)=nI.N0(:,:,:);
output01(500:500+size(nI.N0,1)-1,250:250+size(nI.N0,2)-1,:)=nI.N0(:,:,:);
output01(100:100+size(nI.N0,1)-1,850:850+size(nI.N0,2)-1,:)=nI.N0(:,:,:);
output01(500:500+size(nI.N0,1)-1,850:850+size(nI.N0,2)-1,:)=nI.N0(:,:,:);
image(output01);
%}