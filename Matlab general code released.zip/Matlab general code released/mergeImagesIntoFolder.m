function mergeIntoFolder()
    %Renames all image files by date taken and copies to one output folder
   
    %% Use same directories as previously. Speeds up process. :)
    %First, select all images to move.
    global lastInputPathname lastOutputPathname lastExifToolPathname%Retain directory locations for faster processing of multiple folders.
    if isempty(lastInputPathname) 
        % First time calling 'uigetfile', use the pwd
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files to copy and rename', ...
        'MultiSelect', 'on');
        lastInputPathname=pathnameOfImages;
    else
        %Repeated call to 'uigetfile', start at the same directory as last selection
        [filenamesOfImages,pathnameOfImages] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select all image files to copy and rename', ...
        'MultiSelect', 'on',lastInputPathname);
        lastInputPathname=pathnameOfImages;
    end
    if(~iscell(filenamesOfImages))%If only one file is selected it returns a char array not a cell. So place inside a cell.
        filenamesOfImages={filenamesOfImages};
    end
    %Done
    
    %Then select the output directory
    if isempty(lastOutputPathname) 
        outputPathname=uigetdir(lastInputPathname,'Select output directory to copy the renamed images to');
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    else
        outputPathname=uigetdir(lastOutputPathname,'Select output directory to copy the renamed images to');
        outputPathname=[outputPathname,'\'];
        lastOutputPathname=outputPathname;
    end
    %Done
    
    %Then get the ExifTool
    if isempty(lastExifToolPathname) 
        exiftoolPathToSearch=mfilename('fullpath');%Start in directory this function is stored in
        slashIndices=strfind(exiftoolPathToSearch,'\');
        exiftoolPathToSearch=exiftoolPathToSearch(1:slashIndices(end));
        [exifToolFilename,exifToolPathname] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select exiftool.exe', ...
        'MultiSelect', 'off',exiftoolPathToSearch);
        lastExifToolPathname=exifToolPathname;
    else
        [exifToolFilename,exifToolPathname] = uigetfile({'*.*',  'All Files (*.*)'}, ...
        'Select exiftool.exe', ...
        'MultiSelect', 'off',lastExifToolPathname);
        lastExifToolPathname=exifToolPathname;
    end
    %Done
    
    %% Next rename and copy
    nFiles=length(filenamesOfImages);
    for i=1:nFiles
        %timeCreated=System.IO.File.GetCreationTime([pathnameOfImages,filenamesOfImages{i}]);%Arghhh! Doesn't work. Not photo creation time. Probably time copied from SD card.
        %outputFilename=[sprintf('%04d',double(timeCreated.Year)),'_',sprintf('%02d',double(timeCreated.Month)),'_',sprintf('%02d',double(timeCreated.Day)),'_',sprintf('%02d',double(timeCreated.Hour)),...
        %               '_',sprintf('%02d',double(timeCreated.Minute)),'_',sprintf('%02d',double(timeCreated.Second)),'_',filenamesOfImages{i}];
        
        %Check file is not open by another program
        tempData.Filenames{i}=[pathnameOfImages,filenamesOfImages{i}];
        fHandle=fopen([pathnameOfImages,filenamesOfImages{i}]);
        while(~fHandle)
            disp([pathnameOfImages,filenamesOfImages{i},' is open in another program. Close the file now so the exif data can be updated.']);
            pause(2);
            fHandle=fopen(pathnameOfImages,filenamesOfImages{i});
        end
        fclose(fHandle);
        %Done
        
        %Extract all the exif data and save it in the structure to output from the function.
        disp(['Processing file ',num2str(i),' of ',num2str(nFiles)]);
        [~, rawExifData]=system(['"',exifToolPathname,exifToolFilename,'"',' -s ','"',pathnameOfImages,filenamesOfImages{i},'"']);
        cleanExifData=splitlines(rawExifData);%Wohooo!
        cleanExifData=splitFields(cleanExifData,':',true);%Wohoo!
        %Done
        
        %Now format the creation info and save.
        tempIndex=find(strcmp(cleanExifData(:,1),'CreateDate'));
        tempCreationString=cleanExifData{tempIndex,2};
        fixedCreationString=strrep(strrep(tempCreationString,':','_'),' ','_');
        outputFilename=[fixedCreationString,'_',filenamesOfImages{i}];
        copyfile([pathnameOfImages,filenamesOfImages{i}],[outputPathname,outputFilename]);
    end
    %Done
end