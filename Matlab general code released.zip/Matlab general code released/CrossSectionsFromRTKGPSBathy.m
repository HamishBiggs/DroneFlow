%% Generate Cross Sections From Narrow Beam Echosounder with RTKGPS positioning
%Hamish Biggs, NIWA, From: Drone Flow Project Software Toolbox, Updated 2022_06_13
%{
Instructions:
 - Clean data in excel or similar first. Export data as a .csv file with fields {Name,Easting_m,Northing_m,CorrectedDepth_m}.
 - CorrectedDepth_m accounts for the offset from the transducer to the water surface.
 - This file should include any depth from manual RTKGPS surveying near banks. I.e. the part of the cross section that the boat cannot measure due to boat/transducer draught and blanking distances.
 - The first record in the file should be bank 1 (i.e. depth = 0), and the last entry should be bank 2 (i.e. depth = 0). Manually rearrange the file to make this so.
 - The order of the rest of the entries dont matter as they are sorted.
%}

%% Select the file to process
clear all;
close all;

disp('Running CrossSectionsFromRTKGPSBathy.m');
[echosounderFileName,inputPathname]=uigetfile({'*.*','All Files (*.*)'},'Select the CSV file containing the RTKGPS data and narrow beam echo sounder corrected depths to process','MultiSelect','off',getPreviousDir());
writeCurrentDir(inputPathname);%Remember last used directory for next time script is run
%Done

%% Get the output directory
outputPathname=uigetdir(inputPathname,'Select or create folder for output cross sections');
outputPathname=[outputPathname,'\'];
%Done

%% Loading from the data
Data.('inputCellStrMatrix')=readTextFileGeneric([inputPathname,echosounderFileName],',',true);
Data.('Easting_m')=str2double(Data.inputCellStrMatrix(2:end,2));
Data.('Northing_m')=str2double(Data.inputCellStrMatrix(2:end,3));
Data.('Depth_m')=str2double(Data.inputCellStrMatrix(2:end,4));
%Done

%% Get bank points (user must manually make them first and last entries in the input data
B1_East_North_m=[Data.Easting_m(1);Data.Northing_m(1)];
B2_East_North_m=[Data.Easting_m(end);Data.Northing_m(end)];
maxSeparation_m=((B2_East_North_m(2)-B1_East_North_m(2))^2+(B2_East_North_m(1)-B1_East_North_m(1))^2)^0.5;
%Done

%% Plot the data as XY points and bank locations
figure();
scatter(Data.Easting_m,Data.Northing_m);
hold on;
scatter(B1_East_North_m(1),B1_East_North_m(2),'gx');
scatter(B2_East_North_m(1),B2_East_North_m(2),'rx');
text(B1_East_North_m(1),B1_East_North_m(2),['\leftarrow B1 is LB?'],'Color','k','FontSize',24,'Clipping','on');
text(B2_East_North_m(1),B2_East_North_m(2),['\leftarrow B2 is RB?'],'Color','k','FontSize',24,'Clipping','on');
hold off
xlabel('Easting (m)');
ylabel('Northing (m)');
genericFigureScaling();
title('Scatter plot of cross section bathymetry points','Interpreter','none','FontSize',24);
axis equal;
%Done

%% Input to check whether LB->RB or RB->LB
reply='empty';
while(~any(strcmp(reply,{'Y','N','y','n'})))
    reply=input([char(10),'Are the labels for true left bank (LB) and true right bank (RB) correct? Type: Y to proceed, or N to flip labels and cross section orientation. Then press enter.',char(10)],'s');
end
if(any(strcmp(reply,{'N','n'})))
    temp=B1_East_North_m;
    B1_East_North_m=B2_East_North_m;
    B2_East_North_m=temp;
    
    figure();
    scatter(Data.Easting_m,Data.Northing_m);
    hold on;
    scatter(B1_East_North_m(1),B1_East_North_m(2),'gx');
    scatter(B2_East_North_m(1),B2_East_North_m(2),'rx');
    text(B1_East_North_m(1),B1_East_North_m(2),['\leftarrow LB'],'Color','k','FontSize',24,'Clipping','on');
    text(B2_East_North_m(1),B2_East_North_m(2),['\leftarrow RB'],'Color','k','FontSize',24,'Clipping','on');
    hold off
    xlabel('Easting (m)');
    ylabel('Northing (m)');
    genericFigureScaling();
    title('Corrected banks','Interpreter','none','FontSize',24);
    axis equal;
    %Done
end
%Done

%% Next get the East and North displacements relative to B1
Data.('East_Displacement_m')=Data.Easting_m-B1_East_North_m(1);
Data.('North_Displacement_m')=Data.Northing_m-B1_East_North_m(2);
%Done

%% Next do vector projection
nPoints=length(Data.Easting_m);
XS_UnitVector=B2_East_North_m-B1_East_North_m;
XS_UnitVector=XS_UnitVector/(XS_UnitVector(1)^2+XS_UnitVector(2)^2)^0.5;

%Next project the measurement coordinates onto the cross section line. https://en.wikipedia.org/wiki/Vector_projection  a1=(a dot b_hat)b_hat   where a1 is the vector projection of a onto b_hat
Data.('East_Displacement_Projected_m')=zeros(nPoints,1);
Data.('North_Displacement_Projected_m')=zeros(nPoints,1);
Data.('Linear_Displacement_Projected_m')=zeros(nPoints,1);
Data.('Linear_Displacement_Magnitude_Check_m')=zeros(nPoints,1);

for j=1:nPoints
    %Calculate the vector projection
    aDotB_hat=dot([Data.East_Displacement_m(j);Data.North_Displacement_m(j)],XS_UnitVector);
    Data.East_Displacement_Projected_m(j)=aDotB_hat*XS_UnitVector(1);
    Data.North_Displacement_Projected_m(j)=aDotB_hat*XS_UnitVector(2);
    %Done

    %Next convert the projection into linear distances. Use scalar projection and preserve the sign of displacement (i.e. rather than magnitude of vector) https://en.wikipedia.org/wiki/Scalar_projection
    %Important if the first and last points (that define the cross section) are not the min and max end of the cross section
    Data.Linear_Displacement_Projected_m(j)=dot([Data.East_Displacement_Projected_m(j);Data.North_Displacement_Projected_m(j)],XS_UnitVector);
    Data.Linear_Displacement_Magnitude_Check_m(j)=(Data.East_Displacement_Projected_m(j)^2+Data.North_Displacement_Projected_m(j)^2)^0.5;
    %Done
end
%Done

%% Next sort the data
[Data.('Linear_Displacement_Projected_Sorted_m'),sortIndices]=sort(Data.Linear_Displacement_Projected_m);
Data.('Easting_Projected_Sorted_m')=Data.East_Displacement_Projected_m(sortIndices)+B1_East_North_m(1);
Data.('Northing_Projected_Sorted_m')=Data.North_Displacement_Projected_m(sortIndices)+B1_East_North_m(2);
Data.('Depth_Projected_Sorted_m')=Data.Depth_m(sortIndices);
%Done   

%% Next plot the projected data
figure();
scatter(Data.Easting_m,Data.Northing_m);
hold on;
scatter(B1_East_North_m(1),B1_East_North_m(2),'gx');
scatter(B2_East_North_m(1),B2_East_North_m(2),'rx');
plot(Data.Easting_Projected_Sorted_m,Data.Northing_Projected_Sorted_m,'-r+');
hold off
xlabel('Easting (m)');
ylabel('Northing (m)');
genericFigureScaling();
title('Cross section points','Interpreter','none','FontSize',24);
axis equal;
%Done

%% Next remove any points beyond the ends of the transect
goodPointsBool=(Data.Linear_Displacement_Projected_Sorted_m>-0.0000001)&(Data.Linear_Displacement_Projected_Sorted_m<maxSeparation_m+0.0000001);
Data.Linear_Displacement_Projected_Sorted_m=Data.Linear_Displacement_Projected_Sorted_m(goodPointsBool);
Data.Easting_Projected_Sorted_m=Data.Easting_Projected_Sorted_m(goodPointsBool);
Data.Northing_Projected_Sorted_m=Data.Northing_Projected_Sorted_m(goodPointsBool);
Data.Depth_Projected_Sorted_m=Data.Depth_Projected_Sorted_m(goodPointsBool);
%Done

%% Next plot the projected data after removing points beyond the end
figure();
scatter(Data.Easting_m,Data.Northing_m);
hold on;
scatter(B1_East_North_m(1),B1_East_North_m(2),'gx');
scatter(B2_East_North_m(1),B2_East_North_m(2),'rx');
plot(Data.Easting_Projected_Sorted_m,Data.Northing_Projected_Sorted_m,'-r+');
hold off
xlabel('Easting (m)');
ylabel('Northing (m)');
genericFigureScaling();
title('Cross section points after removing points beyond the ends','Interpreter','none','FontSize',24);
axis equal;
%Done

%% Interpolate the data
%Note: May need code to handle non-unique values of displacement. Although this is unlikely to occur with RTK GPS data.
Data.Linear_Displacement_Interpolated_m=linspace(min(Data.Linear_Displacement_Projected_Sorted_m),max(Data.Linear_Displacement_Projected_Sorted_m),1000)';
Data.('Depth_Interpolated_m')=interp1(Data.Linear_Displacement_Projected_Sorted_m,Data.Depth_Projected_Sorted_m,Data.Linear_Displacement_Interpolated_m);
Data.('Easting_Interpolated_m')=B1_East_North_m(1)+Data.Linear_Displacement_Interpolated_m*XS_UnitVector(1);
Data.('Northing_Interpolated_m')=B1_East_North_m(2)+Data.Linear_Displacement_Interpolated_m*XS_UnitVector(2);
%Done

%% Smooth the data
Data.('Depth_Interpolated_Smoothed_m')=smooth1D(Data.Depth_Interpolated_m,5,'Box','Truncated');
%Set ends to original values (i.e. zero)
Data.Depth_Interpolated_Smoothed_m(1)=Data.Depth_Interpolated_m(1);
Data.Depth_Interpolated_Smoothed_m(end)=Data.Depth_Interpolated_m(end);
%Done

%% Plot the interpolated XY data
figure();
scatter(Data.Easting_m,Data.Northing_m);
hold on;
scatter(B1_East_North_m(1),B1_East_North_m(2),'gx');
scatter(B2_East_North_m(1),B2_East_North_m(2),'rx');
plot(Data.Easting_Interpolated_m,Data.Northing_Interpolated_m,'-r+');
hold off
xlabel('Easting (m)');
ylabel('Northing (m)');
genericFigureScaling();
title('Cross section points after interpolation','Interpreter','none','FontSize',24);
axis equal;
%Done

%% Plot the cross section, interpolated cross section, and smoothed interpolated cross section
figure();
hold on;
plot(Data.Linear_Displacement_Projected_Sorted_m,Data.Depth_Projected_Sorted_m,'r:','LineWidth',2);
plot(Data.Linear_Displacement_Interpolated_m,Data.Depth_Interpolated_m,'c--','LineWidth',2);
plot(Data.Linear_Displacement_Interpolated_m,Data.Depth_Interpolated_Smoothed_m,'g','LineWidth',2);
hold off;
set(gca, 'YDir','reverse');
xlabel('Linear Displacement LB->RB (m)');
ylabel('Depth (m)');
genericFigureScaling();
legend({'Projected','Interpolated','Smoothed'},'Location','EastOutside','FontSize',24);
title('Cross section depth','Interpreter','none','FontSize',24);
%Done

%% Save the data
%Save the cross sections as 'Depth'
disp([char(10),'Saving the cross section depth']);
numArrayElements=length(Data.Depth_Interpolated_Smoothed_m);
outputFileName=[outputPathname,'CrossSection_Depth_LBtoRB.csv'];
outputCellStrArray=cell(numArrayElements+1,2);
outputCellStrArray{1,1}='Length_m';
outputCellStrArray{1,2}='Depth_m';
for j=1:numArrayElements
    outputCellStrArray{j+1,1}=num2str(Data.Linear_Displacement_Interpolated_m(j),'%.5f');
    outputCellStrArray{j+1,2}=num2str(Data.Depth_Interpolated_Smoothed_m(j),'%.5f');
end
%writecell(outputCellStrArray,outputFileName);%Not available in older versions of Matlab that some people may deploy
cellStrMatrix2csvFaster(outputFileName,outputCellStrArray,',');
%Done

%Save the cross sections as 'Elevation'
disp([char(10),'Saving the cross section elevation']);
numArrayElements=length(Data.Depth_Interpolated_Smoothed_m);
outputFileName=[outputPathname,'CrossSection_Elevation_LBtoRB.csv'];
outputCellStrArray=cell(numArrayElements+1,2);
outputCellStrArray{1,1}='Length_m';
outputCellStrArray{1,2}='Elevation_m';
for j=1:numArrayElements
    outputCellStrArray{j+1,1}=num2str(Data.Linear_Displacement_Interpolated_m(j),'%.5f');
    outputCellStrArray{j+1,2}=num2str(-Data.Depth_Interpolated_Smoothed_m(j),'%.5f');
end
%writecell(outputCellStrArray,outputFileName);%Not available in older versions of Matlab that some people may deploy
cellStrMatrix2csvFaster(outputFileName,outputCellStrArray,',');
%Done

%% Save figures if needed
reply='empty';
while(~any(strcmp(reply,{'Y','N','y','n'})))
    reply=input([char(10),'Would you also like to save all the figures as images (useful for QC)? Type: Y to save figures, or N if figures are not needed.',char(10)],'s');
end
if(any(strcmp(reply,{'Y','y'})))
    saveFiguresPNG(outputPathname);
    disp([char(10),'Figures saved in a subdirectory in ',outputPathname]);
end
%Done

%Finished processing
disp([char(10),'CrossSectionsFromRTKGPSBathy.m has completed processing. Please close the application.']);
%Done

%% Functions
function cellStrMatrix2csvFaster(outputFullFileName,cellStrMatrix,delimiter)
    %Clean up output of text from matlab
    
    %Initialise
    fHandle=fopen(outputFullFileName, 'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        error(['Error in cellStrMatrix2csvFaster(), could not open or create the file ',outputFullFileName,' check it isn''t already open or similar']);
    end
    cellArrayHeight=size(cellStrMatrix, 1);
    cellArrayWidth=size(cellStrMatrix, 2);
    %Done
    
    %Loop and build char string
    inputSize=whos('cellStrMatrix');
    delimLength=length(delimiter);
    nlLength=length(char(13));%'\r\n'
    temp=char(zeros(1,inputSize.bytes+2*inputSize.size(1)+inputSize.size(1)*inputSize.size(2)*delimLength+10000));%Storage size + row end chars + delimiters + bit extra
    counter=0;
    for i=1:cellArrayHeight
        for j=1:cellArrayWidth
            if(~ischar(cellStrMatrix{i,j}))%Safety check that not trying to write numeric values or similar
                error(['Error in cellStrMatrix2csvFaster() the cell in row ',num2str(i),' and column ',num2str(j),' does not contain a string']);
            end
            dC=length(cellStrMatrix{i,j});
            temp(counter+1:counter+dC)=cellStrMatrix{i,j};
            counter=counter+dC;
            if(j==cellArrayWidth)%NL if end of row
                if(i~=cellArrayHeight)%Only put NL if it isn't the end of the file.
                    temp(counter+1:counter+nlLength)=char(13);
                    counter=counter+nlLength;
                end
            else
                temp(counter+1:counter+delimLength)=delimiter;
                counter=counter+delimLength;
            end
        end
    end
    fprintf(fHandle,'%s',temp(1:counter));
    %Done
    
    %Close
    fclose(fHandle);
    %Done
    
    %Tested, works well.
    %There is also the function writecell(C,filename) that seems to be new [introduced in 2019a]? Also works well.
end
function lastDir=getPreviousDir()
    %Function to read the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=mfilename('fullpath');
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'r');%Will open the file for reading if it exists
    if(fHandle==-1)
        lastDir=pwd;
    else
        allData=textscan(fHandle,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
        fclose(fHandle);
        if(iscell(allData))
            allData=allData{1};%Unpack it
        end
        if(iscell(allData))
            allData=allData{1};%Unpack it twice sometimes needed...
        end
        if(contains(allData,'\'))
            slashIndices=strfind(allData,'\');
            tempPath=allData(1:slashIndices(end));
            if(isfolder(tempPath))
                lastDir=tempPath;
            else
                lastDir=pwd;
            end            
        else
            lastDir=pwd;
        end
        %Done
    end
    %Done
end

function writeCurrentDir(currentDir)
    %Function to record the last used directory as a .csv file to speed up selection of videos in the future. I.e. not navigating to folders from the Matlab PWD.
    if(~isdeployed())
        scriptNameAndPath=matlab.desktop.editor.getActiveFilename;
        slashIndices=strfind(scriptNameAndPath,'\');
        scriptPath=scriptNameAndPath(1:slashIndices(end));
    else
        scriptPath=[pwd(),'\'];
    end
    nameOfStorageFile='lastDirectoryUsed.csv'; 
    fHandle=fopen([scriptPath,nameOfStorageFile],'wt');%Will create, or replace file. 'wt' is write text file. Useful for carriage returns on new line.
    if(fHandle==-1)
        warning(['Could not write the last used directory to ',[scriptPath,nameOfStorageFile],' please check this file isn''t already open or similar']);
    else
        fprintf(fHandle,'%s',currentDir);
        fclose(fHandle);
    end
    %Done
end

%The Matlab function 'smooth()' is only available with some toolboxes. Hence another 1D smoothing function written by the author has been added here.
function outputSmoothedArray=smooth1D(inputArray,kernelWidth,kernelTypeString,paddingTypeString)
    %1D smoothing function
    %'Truncated' is the recommended method for averaging at the ends (i.e. no padding)
    %e.g. outputSmoothedArray=smooth1D(inputArray,5,'Box','Truncated')

    %Dimensional safety tests
    if(length(size(inputArray))>2||~any(size(inputArray)==1)||numel(inputArray)<=1)
        error('Error in smooth1D, inputArray is not a 1 dimensional array');
    end
    %Done

    %Flip row vectors to column vectors
    if(size(inputArray,1)==1&&size(inputArray,2)>1)
        inputArray=inputArray';
    end
    %Done

    %Check kernel size
    if(rem(kernelWidth,2)~=1)
        warning('Warning in smooth1D, kernel width is not an odd integer. Suggest values such as 3,5,7,9 etc');
    end
    %Done

    %Generate kernels
    if(strcmp(kernelTypeString,'Box'))
        kernel=ones(kernelWidth,1)/kernelWidth;
        %Done
    elseif(strcmp(kernelTypeString,'Gaussian'))
        %Now the only tricky thing is choosing the standard deviation
        %Assume that the full kernel width corresponds to 2 standard deviations
        %So sigma=ceil(kR/2);
        kR=(kernelWidth-1)/2;
        SD=ceil(kR/2);

        yTemp=[-kR:1:kR]';
        kernel=normpdf(yTemp,0,SD)/sum(normpdf(yTemp,0,SD));%Evaluates pdf at these points, so need to renormalise it for smoothing.
        %Done
    else
        error('Error in smooth1D() unknown kernel type');
        %Other kernels such as inverse distance can easily be added.
    end
    %Done

    %Next need to decide padding type
    if(strcmp(paddingTypeString,'Zeros'))
        paddedArray=[zeros(kernelWidth,1);inputArray;zeros(kernelWidth,1)];                
    elseif(strcmp(paddingTypeString,'Mirror'))
        paddedArray=[flipud(inputArray(1:kernelWidth));inputArray;flipud(inputArray(end-kernelWidth+1:end))]; 
    elseif(strcmp(paddingTypeString,'Mean'))
        paddedArray=[ones(kernelWidth,1)*mean(inputArray);inputArray;ones(kernelWidth,1)*mean(inputArray)]; 
    elseif(strcmp(paddingTypeString,'Truncated'))
        %No padded array is needed for this method
    else                
        error('Error in smooth1D() unknown padding method');
    end
    %Done

    %Then cross correlation with inbuilt function, or my own
    if(strcmp(paddingTypeString,'Truncated'))
        %This method uses no boundary mirroring etc, but just truncates the kernel to handle end regions.
        tempSmoothedArray=smooth1DTruncatedKernel(inputArray,kernel);
    else
        %Then perform cross correlation (just use convolution, but flip kernel). (not needed for symmetric kernels, but good habbit).
        tempArray=conv(paddedArray,flipud(kernel),'same');
        %Then extract central region away from padding
        tempSmoothedArray=tempArray(kernelWidth+1:end-kernelWidth);
    end
    %Done

    %Safety check and output
    if(length(tempSmoothedArray)~=length(inputArray))
        error('Error in smooth1D() length discrepancy');
    end
    outputSmoothedArray=tempSmoothedArray;
    %Done
end 
function outputSmoothedArray=smooth1DTruncatedKernel(inputArray,inputKernel)
    %This performs cross correlation itself, so may be very slow. Uses a truncated kernel so bias is introduced.
    %This is called from smooth1D with paddingTypeString set to 'Truncated'

    %Initialise
    inputArray=inputArray(:);%Force column vectors
    inputKernel=inputKernel(:);
    AL=length(inputArray);%ArrayLength
    KL=length(inputKernel);%KernelLength
    KR=(KL-1)/2;%KernelRadius
    KCI=(KL+1)/2;%KernelCentreIndex
    %Done

    %Safety check
    if(mod(KL,2)~=1)
        error('Error in smooth1DTruncatedKernel() kernel is not odd');
    end
    %Done

    %Initialise padded kernel and output array
    fullKernel=zeros(AL+2*KR,1);
    fullKernel(1:KL)=inputKernel;
    tempOutputArray=zeros(AL,1);
    %Done

    %Loop through array
    for i=1:AL
        extractedKernel=fullKernel(KR+1:KR+AL,1);
        normalisation=sum(extractedKernel);
        tempOutputArray(i)=sum(extractedKernel.*inputArray)/normalisation;
        fullKernel=circshift(fullKernel,1);
    end
    %Done

    %Output data
    outputSmoothedArray=tempOutputArray;
    %Done          
end

%Also add functionality for saving figures
function saveFiguresPNG(fullOutputDirectory)
%Another figure saving function

    %Check fullOutputDirectory
    if(fullOutputDirectory(end)~='/')
        fullOutputDirectory(end+1)='/';
    end
    %Done
    
    %Next make dir if it doesnt exist
    fullOutputDirectory=[fullOutputDirectory,datestr(now,'yyyymmddTHHMMSS'),'_Figures/'];
    if(~isdir(fullOutputDirectory))
        mkdir(fullOutputDirectory);
    end
    %Done
    
    %Get the figure handles
    figureHandles=findall(0,'Type','figure');
    %Done
    
    %Next cycle through all figure handles and export them
    for i=1:length(figureHandles)
        plotNumber=1+length(figureHandles)-i;%So they plot/save in the right order. (for some reason loading them loads them in reverse order)
        figure(figureHandles(i));
        set(figureHandles(i),'units','centimeters');
        outerPositionCM=get(figureHandles(i),'outerposition');
        set(figureHandles(i),'PaperUnits','centimeters');
        set(figureHandles(i),'PaperSize',[outerPositionCM(3),outerPositionCM(4)]);
        set(figureHandles(i),'PaperPosition',[0,0,outerPositionCM(3),outerPositionCM(4)]);
        %Done

        %Check an axis exists
        if(~isempty(findobj(gcf,'type','axes')))
            %Code for saving all individual ones
            disp(['Exporting individual figure ',num2str(i),' of ',num2str(length(figureHandles))]);
            saveNameIndividualPNG=[fullOutputDirectory,'Fig_',num2str(plotNumber),'.png'];
            print(gcf, '-dpng', saveNameIndividualPNG,'-r300');%Also tried 600dpi but not worth it for the filesize/time vs improvement 
            %Arghhh, matlab figure saving with white space etc.
            trimWhiteSpacePNG(saveNameIndividualPNG);
            %This fixes it well.
        end
        close(figureHandles(i));
    end
    %Done

    disp('All figures exported');
    %Works well! :)
    
    
    %Pull trimWhiteSpacePNG() out of printClass.
    function trimWhiteSpacePNG(saveNameIndividualPNG)
        %Function to circumvent matlabs stupid white space on saved figures.

        I=imread(saveNameIndividualPNG);
        notWhiteSpace=(I(:,:,1)~=255)|(I(:,:,2)~=255)|(I(:,:,3)~=255);

        topLimit=find(any(notWhiteSpace,2),1,'first');
        bottomLimit=find(any(notWhiteSpace,2),1,'last');
        leftLimit=find(any(notWhiteSpace,1),1,'first');
        rightLimit=find(any(notWhiteSpace,1),1,'last');

        crispyFigure=I(topLimit:bottomLimit,leftLimit:rightLimit,:);
        imwrite(crispyFigure,saveNameIndividualPNG);
        %Works well
    end
end

function genericFigureScaling()
    set(gca,'FontSize',30);
    set(gca,'FontWeight','Bold')
    set(gcf,'units','normalized');
    set(gcf,'outerposition',[0 0 1 1]);
    set(gca,'LineWidth',3);
    set(gca,'Box','on');
    fHandle=gcf;
    fHandle.Color=[1,1,1];
end

function outputCellMatrix=readTextFileGeneric(inputFilename,delimiter,removeConsecutiveDelimitersBool)
    %Read whole file into a cell column array
    fileID=fopen(inputFilename,'r');
    allDataCol=textscan(fileID,'%s','Delimiter','$#^@&@^#@!');%E.g. non-existant delimiter
    allDataCol=allDataCol{1};%Unpack it
    fclose(fileID);
    %Done
    
    %Now need to find the row with most delimiters (also check for empty rows)
    maxDelims=0;
    emptyRows=false(size(allDataCol));
    for i=1:length(allDataCol)
        delimLocations=strfind(allDataCol{i},delimiter);%Gives indices in the string where the delimiter is
        
        %Some files might have multiple connected delims which could be a headache, so combine them.
        if(removeConsecutiveDelimitersBool&&(length(delimLocations)>1))
            %Check if delims are adjacent
            adjacentDelimsBool=[false,(delimLocations(2:end)-delimLocations(1:end-1))==1];
            %Done
            
            %Then if any are adjacent fix them
            if(sum(adjacentDelimsBool)>0)
                %Get the indices of the adjacent delims
                adjacentDelimsIndices=delimLocations(adjacentDelimsBool);
                %Done
                
                %Get the good chars and fix
                goodChars=true(1,length(allDataCol{i}));
                goodChars(adjacentDelimsIndices)=0;
                allDataCol{i}=allDataCol{i}(goodChars); 
                %Done
                
                %Update the delimLocations
                delimLocations=strfind(allDataCol{i},delimiter);%Gives indices in the string where the delimiter is
                %Done
            end
            %Done
        elseif(isempty(allDataCol{i}))%If there is not more than 1 delimeter, then also check whether there is any data in that row. E.g. no delimeters and no data
            emptyRows(i)=true;
        end
        %Done
        
        %Next count how many delims in the line and update maxDelims if larger
        if(length(delimLocations)>maxDelims)
            maxDelims=length(delimLocations);
        end
        %Done
    end
    %Done
    
    %Remove empty rows
    allDataCol=allDataCol(~emptyRows);
    %Done
    
    %Next initialise the cell matrix
    tempCellMatrix=cell(length(allDataCol),maxDelims);
    %Done
    
    %Now loop through and populate the cells
    for i=1:length(allDataCol)
        %Find delim locations for the text row
        delimLocations=strfind(allDataCol{i},delimiter);
        %Done
        
        %Check there are delims for the row. Move whole row if not.
        if(isempty(delimLocations))
            tempCellMatrix{i,1}=allDataCol{i};
        else
            %Now loop through and move all the contents    
            %Think dynamic loops dont work, so use while
            loopCounter=1;
            numCells=length(delimLocations)+1;
            while(loopCounter<=numCells)
                if(loopCounter==1)
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(1:delimLocations(1)-1);
                elseif(loopCounter==numCells)
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(delimLocations(end)+1:end);
                else
                    tempCellMatrix{i,loopCounter}=allDataCol{i}(delimLocations(loopCounter-1)+1:delimLocations(loopCounter)-1);
                end
                loopCounter=loopCounter+1;
            end
            %Done
        end
        %Done
    end
    %Done
    
    %Output data
    outputCellMatrix=tempCellMatrix;
    %Done

    %Works well! The consecutive delim removal also works well. :)
end