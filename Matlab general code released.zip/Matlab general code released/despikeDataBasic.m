function [despikedData,nSpikes]=despikeDataBasic(inputData,movingMedianSize,thresholdTimesMovingMedian)
    %Basic spike replacement based on moving median (of magnitude) for each data channel
    tempDespikedData=inputData;
    inputDataMagnitudes=(inputData.^2).^0.5;
    movingMedianMagnitude=zeros(size(inputData));
    movingMedianSigned=zeros(size(inputData));
    for i=1:size(inputData,2)
        movingMedianMagnitude(:,i)=movmedian(inputDataMagnitudes(:,i),movingMedianSize);
        movingMedianSigned(:,i)=movmedian(inputData(:,i),movingMedianSize);
    end
    dataToReplaceBool=inputDataMagnitudes>(thresholdTimesMovingMedian*movingMedianMagnitude);
    tempDespikedData(dataToReplaceBool)=movingMedianSigned(dataToReplaceBool);
    despikedData=tempDespikedData;
    nSpikes=sum(dataToReplaceBool,1);
    %Done
end