function [outputNaNMask]=expandNaNRegions(inputNaNMask,kernelRadius,nanTolerance)
    %This performs convolution to expand a nan mask
    %Works well b=expandNaNRegions(a,1,1); %For the most basic 3x3 kernel and setting a Nan if any kernel touches any nan
    %c=isnan(b)&~isnan(a);  is useful to visualise the expanded NaN mask
    %For our applications a kernel radius of 2, or 3 should be appropriate.
    
    %Safety check
    if(length(size(inputNaNMask))~=2||mod(kernelRadius,1)~=0||mod(nanTolerance,1)~=0||sum(sum(isnan(inputNaNMask)))==0)%Should be a 2D nan mask and integer values for the others
        error('Error in expandNaNRegions() check the input NaNMask and kernelRadius. Saved as wtfNaN.mat');
        save('wtfNaN.mat');
    end
    %Done
    
    %Now setup the kernel and modify inputNaNMask
    TNM=inputNaNMask;
    TNM(~isnan(TNM))=0;
    TNM(isnan(TNM))=1;
    K=ones(2*kernelRadius+1,2*kernelRadius+1);
    %Done
    
    %Then perform convolution
    TNMOut=conv2(TNM,K,'same');
    %Done
    
    %Then compute new nans
    TNMOut(TNMOut>=nanTolerance)=NaN;
    %Then apply these new NaNs to the original nan mask
    inputNaNMask(isnan(TNMOut))=NaN;
    %Done   
    
    %Output :)
    outputNaNMask=inputNaNMask;
    %Done
end