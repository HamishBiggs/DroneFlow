function [D_Dy,D_Dx,D_Dy_raw,D_Dx_raw,KNF]=bigGKClean(kD,SF)
    %Generate gradient kernels function (simple version)
    %kD=kernelDiamter, odd integer>0
    %SF=ScaleFactor(m/pixel)
    %KNF is the kernel normalisation factor
    %D_Dy=D_Dy_raw*KNF, D_Dx=D_Dx_raw*KNF
    %y is vertical dimension. x is horizontal dimension.

    %Input safety check
    if(kD<1||rem(kD-1,2)~=0)
        error('kD must be an odd integer >0');
    end

    %Initialisation of variables
    R=(kD-1)/2;
    KNF=1/(R^2+R);
    D_Dy_raw=zeros(kD,kD);
    D_Dx_raw=zeros(kD,kD);
    
    %Generate D_Dy_raw kernel
    for i2=1:R
        for j2=-R:R
            i1=-i2;j1=-j2; %Indices of the second pair point
            I2=i2+(R+1);I1=i1+(R+1); %Matrix indices
            J2=j2+(R+1);J1=j1+(R+1); %Matrix indices
            %Compute gradient kernel value for (i2,j2)
            D_Dy_raw(I2,J2)=(i2*SF)/(2*((i2*SF)^2+(j2*SF)^2));
            %Compute gradient kernel value for (i1,j1)
            D_Dy_raw(I1,J1)=-(i2*SF)/(2*((i2*SF)^2+(j2*SF)^2));
        end
    end
    
    %Generate D_Dx_raw kernel
    for i2=-R:R
        for j2=1:R
            i1=-i2;j1=-j2; %Indices of the second pair point
            I2=i2+(R+1);I1=i1+(R+1); %Matrix indices
            J2=j2+(R+1);J1=j1+(R+1); %Matrix indices
            %Compute gradient kernel value for (i2,j2)
            D_Dx_raw(I2,J2)=(j2*SF)/(2*((i2*SF)^2+(j2*SF)^2));
            %Compute gradient kernel value for (i1,j1)
            D_Dx_raw(I1,J1)=-(j2*SF)/(2*((i2*SF)^2+(j2*SF)^2));
        end
    end
    
    D_Dy=D_Dy_raw*KNF;
    D_Dx=D_Dx_raw*KNF;
end