function outputColCellArray=extractColumn(inputCellStrMatrix,columnTitle)
    %Make it easier to extract columns from inputCellStrMatrix
    colIndex=0;
    for i=1:size(inputCellStrMatrix,2)
        if(strcmp(inputCellStrMatrix{1,i},columnTitle)&&(colIndex==0))
            colIndex=i;
        elseif(strcmp(inputCellStrMatrix{1,i},columnTitle)&&(colIndex~=0))%Check if any other instances of the same column name
            save('wtf.mat');
            error('Error in extractColumn() there are two columns with the same title, saving wtf.mat');
        end
    end
    outputColCellArray=inputCellStrMatrix(2:end,colIndex);
    %Done
end