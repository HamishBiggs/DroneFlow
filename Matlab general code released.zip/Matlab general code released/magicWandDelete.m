function outputBinaryMatrix=magicWandDelete(inputBinaryMatrix,xCoords,yCoords)
    %Take pixels co-ordinates, then search through all connected pixels and also assign to same class

    %Initialise
    iBM=double(inputBinaryMatrix);
    sV=size(iBM);%sizeVector
    %Done

    %Check for errors in input matrix format
    if(sum((iBM(:)~=0)&iBM(:)~=1)~=0)
        error('Error in magicWandDelete() input matrix contains entries that are not 1 or 0');
    end
    if(length(sV)~=2)
        error('Error in magicWandDelete() size vector, not equal to 2');
    end
    %Done

    %Pad with zeros
    bigBM=zeros(sV(1)+2,sV(2)+2);
    bigBM(2:end-1,2:end-1)=iBM;
    %Done

    %Get size of expanded matrix
    bigSV=size(bigBM);
    %Done

    %Create kernels
    kernelRadius=1;
    kernelDiameter=3;
    XK=[ 0,0, 0;...
        -1,0,+1;...
         0,0, 0];%X displacement kernel
    YK=[0,-1,0;...
        0, 0,0;...
        0,+1,0];%Y displacement kernel (Assuming origin is top left)
    checkedPixelMask=[1,0,1;...
                      0,0,0;...
                      1,0,1];%So don't double up on neighbours etc.
    %Originally had the diagonal in the kernel too.
    %Removing the diagonals negates the need for the neighbour kernel.
    %Done 

    %Should be faster if just using column vectors and linear indexing
    XKV=XK(:);
    YKV=YK(:);
    checkedPixelMaskV=checkedPixelMask(:);
    %Done           

    %Use my sneaky way to speed up indexing of 2D matrices from mathClass.NaNKernelSmooth()
    %Use principle that the relative offset is constant :)
    %Then create a linear array that can just add the displacement to the centre.
    %Single indexing is just Y+(X-1)*Ymax; %Where y is dim1 and x is dim2
    yOffset=[-kernelRadius:kernelRadius]'*ones(1,kernelDiameter);
    xOffset=ones(kernelDiameter,1)*[-kernelRadius:kernelRadius]*bigSV(1);
    fastIndexingArray=yOffset+xOffset;
    fastIndexingArray=fastIndexingArray(:);
    %Done

    %Loop through all the starting points
    for i=1:length(xCoords)
        %Set as neighbour coords as scalars to begin with
        xVector=xCoords(i);
        yVector=yCoords(i);
        %Begin looping through and finding all neighbours
        while(~isempty(xVector))
            %Create extraction vector and set all pixels indexed by xVector and yVector to 0
            extractionVector=(xVector-1)*bigSV(1)+yVector;
            bigBM(extractionVector)=0;
            %Done

            %Loop through each pixel addressed by [yVector(index),xVector(index)]
            %find the pixels neighbours, then put them into a new xVector and yVector, then continue
            vectorIndex=1;
            vectorMax=length(xVector);
            if(length(xVector)~=length(yVector))
                error('Error in magicWandDelete(), vector length discrepancy');
            end
            %Prepare nextXVector
            nextXVector=[];
            nextYVector=[];
            while(vectorIndex<=vectorMax)
                %Find shift of neighbouring pixels
                %Fast 1D extraction  (constant relative displacement)+variable centre of kernel displacement
                %Also adjusted the other kernel functions to be 1D vectors. Should all be faster.
                extractionVector=fastIndexingArray+yVector(vectorIndex)+(xVector(vectorIndex)-1)*bigSV(1);
                neighbourRegion=bigBM(extractionVector);
                bigBM(extractionVector)=neighbourRegion.*checkedPixelMaskV;
                %Done

                %Find the neighbours
                neighbourXShift=neighbourRegion.*XKV;
                neighbourXShift=neighbourXShift(:);
                neighbourYShift=neighbourRegion.*YKV;
                neighbourYShift=neighbourYShift(:);
                %Done

                %Only extract pixels with some shift in x or y, which shows they are valid neighbours, not zero pixels, or origin.
                validToExtract=(neighbourXShift~=0)|(neighbourYShift~=0);
                if(any(validToExtract))
                    neighbourXShift=neighbourXShift(validToExtract)+xVector(vectorIndex);%Add the current x position
                    neighbourYShift=neighbourYShift(validToExtract)+yVector(vectorIndex);%Add the current y position
                    %Append neighbour co-ordinates to nextXVector, if valid neighbours exist
                    nextXVector(end+1:end+length(neighbourXShift))=neighbourXShift;
                    nextYVector(end+1:end+length(neighbourYShift))=neighbourYShift;
                end
                %Done

                %Increment
                vectorIndex=vectorIndex+1;
                %Done
            end
            %Set xVector and yVector equal to next vectors
            xVector=nextXVector;
            yVector=nextYVector;
            %Done
        end
        %Done
    end
    %Done

    %Output data
    outputBinaryMatrix=bigBM(2:end-1,2:end-1);
    %Done

    %Works well.
end