function genericFigureScaling()
    set(gca,'FontSize',30);
    set(gca,'FontWeight','Bold')
    set(gcf,'units','normalized');
    set(gcf,'outerposition',[0 0 1 1]);
    set(gca,'LineWidth',3);
    set(gca,'Box','on');
    fHandle=gcf;
    fHandle.Color=[1,1,1];
end