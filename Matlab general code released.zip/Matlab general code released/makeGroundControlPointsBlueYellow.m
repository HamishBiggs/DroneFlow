%Make control points. I.e. as A4 or A3 laminated.

clear all;
close all;

%Step 1: Define output path
disp('Select or create output directory');
if(~exist('lastDir'))
    lastDir=[pwd(),'\'];
end
[outputPathname] = uigetdir(lastDir,'Select or create output directory for GCPs');
outputPathname=[outputPathname,'\'];
lastDir=outputPathname;
%Done

%Step 2: Create a blue and yellow template
A4Width300DPI=3508;
A4Height300DPI=2480;
A3Width300DPI=4961;
A3Height300DPI=3605;
outputHeight=A3Height300DPI;
outputWidth=A3Width300DPI;
outputImageSizeSuffix='A3';
I=zeros(outputHeight,outputWidth,3);
IYIndices=(1:outputHeight)';
IXIndices=(1:outputWidth);
IYCentreIndex=mean(IYIndices);%Can be a fraction
IXCentreIndex=mean(IXIndices);%Can be a fraction
IYIndicesMatrix=IYIndices*ones(1,outputWidth);
IXIndicesMatrix=ones(outputHeight,1)*IXIndices;
IRMatrix=((IYIndicesMatrix-IYCentreIndex).^2+(IXIndicesMatrix-IXCentreIndex).^2).^0.5;
IThetaMatrix=atan2d(IYIndicesMatrix-IYCentreIndex,IXIndicesMatrix-IXCentreIndex);
I(:,:,3)=255;%Set background to blue, then use yellow at the top and bottom
%Note: Matrix indexes from the top down. So from an index and angle perspective the 'top' is the 'bottom'
ThetaRangeYellowTop=[atan2d(IYIndicesMatrix(1,1)-IYCentreIndex,IXIndicesMatrix(1,1)-IXCentreIndex);atan2d(IYIndicesMatrix(1,end)-IYCentreIndex,IXIndicesMatrix(1,end)-IXCentreIndex)];
ThetaRangeYellowBottom=[atan2d(IYIndicesMatrix(end,1)-IYCentreIndex,IXIndicesMatrix(end,1)-IXCentreIndex);atan2d(IYIndicesMatrix(end,end)-IYCentreIndex,IXIndicesMatrix(end,end)-IXCentreIndex)];
yellowIndices2D=find(((ThetaRangeYellowTop(1)<=IThetaMatrix(:))&(IThetaMatrix(:)<=ThetaRangeYellowTop(2)))|((ThetaRangeYellowBottom(1)>=IThetaMatrix(:))&(IThetaMatrix(:)>=ThetaRangeYellowBottom(2))));
I(yellowIndices2D)=255;
I(yellowIndices2D+outputWidth*outputHeight)=255;
I(yellowIndices2D+2*outputWidth*outputHeight)=0;
%Done

%Show template image
%figure();
%imshow(uint8(I));
%Done

%Step 3: Cycle through the output images
nImages=100;
imageCounter=1;
i=0;
j=0;
while(imageCounter<=nImages)
    %Display loop counter
    display(['Saving GCP image ',num2str(imageCounter),' of ',num2str(nImages)]);
    %Done

    %Create subimage of text
    insertTextPositionY=round(IYCentreIndex*1.65);
    insertTextPositionX=round(IXCentreIndex);
    backgroundColour=I(insertTextPositionY,insertTextPositionX,:);
    tempTextImage=repmat(backgroundColour,[1000,1000,1]);
    tempTextImage=insertText(tempTextImage,[500,500],['G',num2str(i),num2str(j)],'FontSize',200,'BoxOpacity',0,'AnchorPoint','Center');%200 is max font size unfortunately. Will have to scale it ourselves for larger.
    %Done

    %Trim sub image to letter boundaries
    letterPixels=tempTextImage(:,:,1)==0;
    indicesLetterPixels=find(letterPixels(:));
    [subsLetterPixelsY,subsLetterPixelsX]=ind2sub(size(letterPixels),indicesLetterPixels);
    yLimsLetterPixels=[min(subsLetterPixelsY)-1,max(subsLetterPixelsY)+1];
    xLimsLetterPixels=[min(subsLetterPixelsX)-1,max(subsLetterPixelsX)+1];
    croppedTextImage=tempTextImage(yLimsLetterPixels(1):yLimsLetterPixels(2),xLimsLetterPixels(1):xLimsLetterPixels(2),:);
    %Done

    %Rescale croppedTextImage. Want to span 0.2 of original image.
    textHeightProportion=0.2;
    croppedTextImageRescaled=imresize(croppedTextImage,textHeightProportion*size(I,1)/size(croppedTextImage,1));
    %Done

    %Next insert the text
    tempImage=I;
    yInsertOrigin=insertTextPositionY-round(size(croppedTextImageRescaled,1)/2);
    xInsertOrigin=insertTextPositionX-round(size(croppedTextImageRescaled,2)/2);
    tempImage(yInsertOrigin:yInsertOrigin+size(croppedTextImageRescaled,1)-1,xInsertOrigin:xInsertOrigin+size(croppedTextImageRescaled,2)-1,:)=croppedTextImageRescaled;
    %Done

    %Add circles in the corners to cut out before laminating.
    yLocation=200;
    xLocation=yLocation*(size(I,2)/size(I,1));
    radius=150;
    tempImage=insertShape(tempImage,'circle',[xLocation,yLocation,radius],'Color','black','LineWidth',10);
    tempImage=insertText(tempImage,[xLocation,yLocation],'Cut','FontSize',100,'BoxOpacity',0,'AnchorPoint','Center');%200 is max font size unfortunately. Will have to scale it ourselves for larger.

    tempImage=insertShape(tempImage,'circle',[size(tempImage,2)-xLocation,yLocation,radius],'Color','black','LineWidth',10);
    tempImage=insertText(tempImage,[size(tempImage,2)-xLocation,yLocation],'Cut','FontSize',100,'BoxOpacity',0,'AnchorPoint','Center');%200 is max font size unfortunately. Will have to scale it ourselves for larger.

    tempImage=insertShape(tempImage,'circle',[xLocation,size(tempImage,1)-yLocation,radius],'Color','black','LineWidth',10);
    tempImage=insertText(tempImage,[xLocation,size(tempImage,1)-yLocation],'Cut','FontSize',100,'BoxOpacity',0,'AnchorPoint','Center');%200 is max font size unfortunately. Will have to scale it ourselves for larger.

    tempImage=insertShape(tempImage,'circle',[size(tempImage,2)-xLocation,size(tempImage,1)-yLocation,radius],'Color','black','LineWidth',10);
    tempImage=insertText(tempImage,[size(tempImage,2)-xLocation,size(tempImage,1)-yLocation],'Cut','FontSize',100,'BoxOpacity',0,'AnchorPoint','Center');%200 is max font size unfortunately. Will have to scale it ourselves for larger.
    %Done

    %Visualise
    %figure();
    %imshow(uint8(tempImage));
    %Done

    %Now save output images
    imwrite(tempImage,[outputPathname,'G',num2str(i),num2str(j),'_',outputImageSizeSuffix,'.jpg']);
    %Done

    %Update indices and counters
    imageCounter=imageCounter+1;
    j=j+1;
    if(j>9)
        j=0;
        i=i+1;
    end
    %Done
end
%Done
