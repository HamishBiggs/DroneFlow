#include "Drone_flow.h"

extern configuration config;
HANDLE hComm;
DCB dcbSerialParams;
COMMTIMEOUTS timeouts = { 0 };
BOOL Write_Status;

void initTriggerComms(void)
{
	hComm = CreateFileA(config.triggerPortName,
		GENERIC_READ | GENERIC_WRITE,
		0,    // must be opened with exclusive-access
		NULL, // no security attributes
		OPEN_EXISTING, // must use OPEN_EXISTING
		0,    // not overlapped I/O
		NULL  // hTemplate must be NULL for comm devices
	);

	if (hComm == INVALID_HANDLE_VALUE)
	{

		if (GetLastError() == ERROR_FILE_NOT_FOUND)
		{
			puts("cannot open port!");
			//return;
			abort();//Added this
		}

		puts("invalid handle value!");
		//return;
		abort();//Added this
	}
	else
		printf("opening serial port successful");
	dcbSerialParams.DCBlength = sizeof(dcbSerialParams);

	Write_Status = GetCommState(hComm, &dcbSerialParams);     //retreives  the current settings

	if (Write_Status == FALSE) {
		printf("\n   Error! in GetCommState()");
		CloseHandle(hComm);
		//return 1;
		return;
	}

	dcbSerialParams.BaudRate = CBR_9600;      // Setting BaudRate = 9600
	dcbSerialParams.ByteSize = 8;             // Setting ByteSize = 8
											  //dcbSerialParams.
	dcbSerialParams.StopBits = ONESTOPBIT;    // Setting StopBits = 1
	dcbSerialParams.Parity = ODDPARITY;      // Setting Parity = None

	Write_Status = SetCommState(hComm, &dcbSerialParams);  //Configuring the port according to settings in DCB

	if (Write_Status == FALSE)
	{
		printf("\n   Error! in Setting DCB Structure");
		CloseHandle(hComm);
		//return 1;
		return;
	}
	else
	{
		printf("\n   Setting DCB Structure Successful\n");
		printf("\n       Baudrate = %d", dcbSerialParams.BaudRate);
		printf("\n       ByteSize = %d", dcbSerialParams.ByteSize);
		printf("\n       StopBits = %d", dcbSerialParams.StopBits);
		printf("\n       Parity   = %d", dcbSerialParams.Parity);
	}

	// Set COM port timeout settings
	timeouts.ReadIntervalTimeout = 50;
	timeouts.ReadTotalTimeoutConstant = 50;
	timeouts.ReadTotalTimeoutMultiplier = 10;
	timeouts.WriteTotalTimeoutConstant = 50;
	timeouts.WriteTotalTimeoutMultiplier = 10;
	if (SetCommTimeouts(hComm, &timeouts) == 0)
	{
		printf("Error setting timeouts\n");
		CloseHandle(hComm);
		//return 1;
		return;
	}
}

void setTriggerFrequency(void)
{
	char lp[20] = "";

	//DWORD  NumWritten;//Removed as unused local variable.
	DWORD  dNoOFBytestoWrite;              // No of bytes to write into the port
	DWORD  dNoOfBytesWritten = 0;          // No of bytes written to the port

	strcat(lp, "@st=");
	strcat(lp, config.captureFrequency);
	strcat(lp, "\n\r");
	dNoOFBytestoWrite = sizeof(lp); // Calculating the no of bytes to write into the port


	if (!WriteFile(hComm, lp, dNoOFBytestoWrite,
		&dNoOfBytesWritten, NULL))
	{
		printf("Error writing text to %s\n", config.triggerPortName);
	}
	else
	{
		printf("\n\r%d bytes written to %s\n\r",
			dNoOfBytesWritten, config.triggerPortName);
	}

	if (Write_Status == TRUE)
		printf("\n\n    %s - Written to %s", lp, config.triggerPortName);
	else
		printf("\n\n   Error %d in Writing to Serial Port", GetLastError());
}