//=============================================================================
// Copyright (c) 2001-2018 FLIR Systems, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

/**
 *  @example Trigger_C.cpp
 *
 *  @brief Trigger_C.cpp shows how to trigger the camera. It relies on
 *  information provided in the Enumeration_C, Acquisition_C, and NodeMapInfo_C
 *  examples.
 *
 *  It can also be helpful to familiarize yourself with the
 *  ImageFormatControl_C and Exposure_C examples as these provide a strong
 *  introduction to camera customization.
 *
 *  This example shows the process of configuring, using, and cleaning up a
 *  camera for use with both a software and a hardware trigger.
 */

#include "Drone_flow.h"

extern configuration config;
extern spinError err;

int main(/*int argc, char** argv*/)
{
	spinInit();
	initTimer();
	readConfig();
	initTriggerComms();
	setTriggerFrequency();
	initCameras();
	resetCameras();
	Sleep(15000);
	initCameras();
	processImageParameters();
	initPrimaryCameraGPIO();
	initSecondaryCameraGPIO();
	initPrimaryCameraTrigger();
	initSecondaryCameraTrigger();
	initAcquisitionMode();
	captureNoExternalEnable();
	spinClose();
}
