#include "Drone_flow.h"

extern spinError err;
extern spinSystem hSystem;
extern configuration config;

spinCamera hPrimaryCamera = NULL, hSecondaryCamera = NULL;
spinCameraList hCameraList = NULL;
spinNodeMapHandle hPrimaryCameraNodeMap = NULL, hSecondaryCameraNodeMap = NULL;
spinNodeHandle hLineSelector = NULL;
spinNodeHandle hLineStatus = NULL;
spinNodeHandle hLineMode = NULL;
spinNodeHandle hV3_3Enable = NULL;
spinNodeHandle hTriggerSource = NULL;
spinNodeHandle hTriggerMode = NULL;
spinNodeHandle hTriggerActivation = NULL;
spinNodeHandle hTriggerOverlap = NULL;
spinImage hResultImage = NULL;
spinImage hConvertedImage = NULL;

int64_t frameTime, pairCount = 1, oldPrimaryTimestamp = 0, oldSecondaryTimestamp = 0;

//Note: None of the time variables below seem to be used???  Need to figure out how to get the system time. :)
time_t rawtime;
struct tm * timeinfo;
char filename[MAX_BUFF_LEN];
char systemTime[MAX_BUFF_LEN];

bool8_t isIncomplete = 0;
bool8_t hasFailed = 0;

spinError initCameras(void)
{
	// Retrieve list of cameras from the system
	err = spinCameraListCreateEmpty(&hCameraList);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to create camera list. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinSystemGetCameras(hSystem, hCameraList);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve camera list. Aborting with error %d...\n\n", err);
		return err;
	}

	// Verify cameras are present
	printf("Checking for Primary Camera...\t");
	err = spinCameraListGetBySerial(hCameraList, config.primaryCamera, &hPrimaryCamera);
	if (hPrimaryCamera == NULL)
	{
		printf("not found\n");
		return err;
	}
	else printf("ok\n");

	printf("Checking for Secondary Camera...");
	err = spinCameraListGetBySerial(hCameraList, config.secondaryCamera, &hSecondaryCamera);
	if (hSecondaryCamera == NULL)
	{
		printf("not found\n");
		return err;
	}
	else printf("ok\n");

	// Initialize cameras
	err = spinCameraInit(hPrimaryCamera);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to initialize Primary camera. Aborting with error %d...\n\n", err);
		return err;
	}
	else printf("Primary Camera initialised...\n");

	err = spinCameraInit(hSecondaryCamera);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to initialize Secondary camera. Aborting with error %d...\n\n", err);
		return err;
	}
	else printf("Secondary Camera initialised...\n");

	// Retrieve camera nodemaps
	err = spinCameraGetNodeMap(hPrimaryCamera, &hPrimaryCameraNodeMap);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve GenICam nodemap from Primary camera. Aborting with error %d...\n\n", err);
		return err;
	}
	else printf("Retrieved Primary Camera nodemap...\n");

	err = spinCameraGetNodeMap(hSecondaryCamera, &hSecondaryCameraNodeMap);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve GenICam nodemap from Secondary camera. Aborting with error %d...\n\n", err);
		return err;
	}
	else printf("Retrieved Secondary Camera nodemap...\n");

	err=enableChunkData(hPrimaryCameraNodeMap);
	//Added this error checking
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Problems occured for enableChunkData for Primary Camera. Aborting with error %d...\n\n", err);
		return err;
	}
	else printf("Successfully enabled Chunk Data for Primary Camera...\n");

	err=enableChunkData(hSecondaryCameraNodeMap);
	//Added this error checking
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Problems occured for enableChunkData for secondary camera. Aborting with error %d...\n\n", err);
		return err;
	}
	else printf("Successfully enabled Chunk Data for Secondary Camera...\n");

	return SPINNAKER_ERR_SUCCESS;
}

spinNodeHandle hNodeHandle = NULL;
spinNodeHandle hPropertyName = NULL;
int64_t propertyValue = 0;

void setEnumeratedProperty(char *nodeName, char *propertyValueLabel)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinEnumerationGetEntryByName(hNodeHandle, propertyValueLabel, &hPropertyName);
	err = spinEnumerationEntryGetIntValue(hPropertyName, &propertyValue);
	err = spinEnumerationSetIntValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("1: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, nodeName, &hNodeHandle);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("2: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinEnumerationSetIntValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("3: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
}

void setEnumeratedPropertyPrimaryCamera(char *nodeName, char *propertyValueLabel)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("1: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinEnumerationGetEntryByName(hNodeHandle, propertyValueLabel, &hPropertyName);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("2: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinEnumerationEntryGetIntValue(hPropertyName, &propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("3: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinEnumerationSetIntValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("4: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
}

void setEnumeratedPropertySecondaryCamera(char *nodeName, char *propertyValueLabel)
{
	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, nodeName, &hNodeHandle);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("1: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinEnumerationGetEntryByName(hNodeHandle, propertyValueLabel, &hPropertyName);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("2: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinEnumerationEntryGetIntValue(hPropertyName, &propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("3: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
	err = spinEnumerationSetIntValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("4: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
}

void setFloatProperty(char *nodeName, double propertyValue)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinFloatSetValue(hNodeHandle, propertyValue);
	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinFloatSetValue(hNodeHandle, propertyValue);
}

void setFloatPropertyPrimaryCamera(char *nodeName, double propertyValue)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinFloatSetValue(hNodeHandle, propertyValue);
	printf("Test breaking code2");
	abort();
}

void setIntProperty(char *nodeName, int propertyValue)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinIntegerSetValue(hNodeHandle, propertyValue);
	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinIntegerSetValue(hNodeHandle, propertyValue);
}

void setIntPropertyPrimaryCamera(char *nodeName, int propertyValue)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinIntegerSetValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Error in setIntPropertyPrimaryCamera() for nodeName = %s, and propertyValue = %i, error code = %d...\n\n", nodeName, propertyValue, err);
		//return(err);
		abort();
	}
}

void setBoolProperty(char *nodeName, bool8_t propertyValue)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinBooleanSetValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("1: Aborting with error %d...\n\n", err);
		abort();//return err;
	}

	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinBooleanSetValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("2: Aborting with error %d...\n\n", err);
		abort();//return err;
	}

}

void setBoolPropertyPrimaryCamera(char *nodeName, bool8_t propertyValue)
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, nodeName, &hNodeHandle);
	err = spinBooleanSetValue(hNodeHandle, propertyValue);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("1: Aborting with error %d...\n\n", err);
		abort();//return err;
	}
}

void processImageParameters(void)
{
// Auto Gain setting
	printf("Setting Auto Gain to ");
	switch (config.gainAuto)
	{
	   case AG_OFF:
		  printf("OFF\n");
		  setEnumeratedProperty("GainAuto", "Off");
		  break;
	   case AG_ONCE:
		  printf("ONCE\n");
		  setEnumeratedProperty("GainAuto", "Once");
		  break;
	   case AG_CONTINUOUS:
		  printf("CONTINUOUS\n");
		  setEnumeratedProperty("GainAuto", "Continuous");
		  break;
	   default:
		  break;
	}

// Set pixel format
	printf("Setting Pixel Format to %s\n", config.pixelFormat);
	setEnumeratedProperty("PixelFormat", config.pixelFormat);

// Set exposure mode
	printf("Setting Exposure Mode to TIMED\n");
	setEnumeratedProperty("ExposureMode", "Timed");

// Set exposure time / auto mode
	setEnumeratedProperty("ExposureAuto", "Off");//Added this to set default starting exposure time to 1000us. Used to set cameras to same starting exposure benchmark.
	setFloatProperty("ExposureTime", (double)(1000));//Added this to set default starting exposure time to 1000us. Used to set cameras to same starting exposure benchmark.
	printf("Setting exposure times to ");
	if (config.exposureAuto==0)
	{
		printf("%d us\n", config.exposureTime);
		setEnumeratedProperty("ExposureAuto", "Off");
		setFloatProperty("ExposureTime", (double)(config.exposureTime));
	}
	else
	{
		printf("AUTO, ");
		switch (config.exposureAuto)
		{
		   case AE_OFF:
			   printf("OFF\n");
			   setEnumeratedProperty("ExposureAuto", "Off");
			   break;
		   case AE_ONCE:
			   printf("ONCE\n");
			   setEnumeratedProperty("ExposureAuto", "Once");
			   setFloatProperty("AutoExposureControlLoopDamping", (double)(0.01));
			   break;
		   case AE_CONTINUOUS:
			   printf("CONTINUOUS\n");
			   setEnumeratedProperty("ExposureAuto", "Continuous");
			   setFloatProperty("AutoExposureControlLoopDamping", (double)(0.01));
			   break;
		   default:
			  break;
		}
	}

// Set auto exposure lighting mode
	printf("Setting Auto Exposure Lighting Mode to ");
	switch (config.autoExposureLightingMode)
	{
	   case AELM_AUTO://AutoDetect causes errors. Avoid!
		  printf("AUTODETECT\n");
		  setEnumeratedProperty("AutoExposureLightingMode", "AutoDetect");
		  break;
	   case AELM_FRONT:
		  printf("FRONT LIGHT\n");
		  setEnumeratedProperty("AutoExposureLightingMode", "FrontLight");
		  break;
	   case AELM_BACK:
		  printf("BACK LIGHT\n");
		  setEnumeratedProperty("AutoExposureLightingMode", "BackLight");
		  break;
	   case AELM_NORM:
		  printf("NORMAL\n");
		  setEnumeratedProperty("AutoExposureLightingMode", "Normal");
		  break;
	   default:
		  break;
	}

// Set auto exposure metering mode
	printf("Setting Auto Exposure Metering Mode to ");
	switch (config.autoExposureMeteringMode)
	{
	case AEMM_AVG:
		printf("AVERAGE\n");
		setEnumeratedProperty("AutoExposureMeteringMode", "Average");
		break;
	case AEMM_SPOT:
		printf("SPOT\n");
		setEnumeratedProperty("AutoExposureMeteringMode", "Spot");
		break;
	case AEMM_PARTIAL:
		printf("PARTIAL\n");
		setEnumeratedProperty("AutoExposureMeteringMode", "Partial");
		break;
	case AEMM_CW:
		printf("CENTRE WEIGHTED\n");
		setEnumeratedProperty("AutoExposureMeteringMode", "CenterWeighted");
		break;
	case AEMM_HP:
		printf("HISTOGRAM PEAK\n");
		setEnumeratedProperty("AutoExposureMeteringMode", "HistgramPeak");
		break;
	default:
		break;
	}

// Set auto exposure time lower limit
	printf("Setting Auto Exposure Time Lower Limit, %d us\n", config.autoExposureTimeLowerLimit);
	setIntProperty("AeExposureTimeLowerLimit_Int", config.autoExposureTimeLowerLimit);

// Set auto exposure time upper limit
	printf("Setting Auto Exposure Time Upper Limit, %d us\n", config.autoExposureTimeUpperLimit);
	setIntProperty("AeExposureTimeUpperLimit_Int", config.autoExposureTimeUpperLimit);

// Set auto exposure control priority
	printf("Setting Auto Exposure Control Priority to ");
	switch (config.autoExposureControlPriority)
	{
	   case AECP_GAIN:
		  printf("GAIN\n");
		  setEnumeratedProperty("AutoExposureControlPriority", "Gain");
		  break;
	   case AECP_ET:
		  printf("EXPOSURE TIME\n");
		  setEnumeratedProperty("AutoExposureControlPriority", "ExposureTime");
		  break;
	   default:
		  break;
	}

// Set X,Y decimation
	//Tested decimation and the friggin cameras can only do 2 decimation or nothing! There are also binning (averaging) options if needed, but cant be used at the same time as decimation.
	setEnumeratedProperty("DecimationSelector", "All");//Added this
	setEnumeratedProperty("DecimationVerticalMode", "Discard");//Added this
	setEnumeratedProperty("DecimationHorizontalMode", "Discard");//Added this

	printf("Setting Horizontal Decimation to %d\n", config.xDecimation);
	setIntProperty("DecimationHorizontal", config.xDecimation);

	printf("Setting Vertical Decimation to %d\n", config.yDecimation);
	setIntProperty("DecimationVertical", config.yDecimation);

// Set ROI
	printf("Setting ROI to width %d, height %d\n", config.xRoi, config.yRoi);
	setIntProperty("Width", config.xRoi);
	setIntProperty("Height", config.yRoi);

// Set ROI offsets
	printf("Setting Image Offsets to X: %d, Y: %d\n", config.xOffset, config.yOffset);
	setIntProperty("OffsetX", config.xOffset);
	setIntProperty("OffsetY", config.yOffset);

	//printf("Testing annoying stuff %i \n", StreamBufferHandlingMode_OldestFirst);
	//setEnumeratedProperty("StreamBufferHandlingMode", "OldestFirst");//This is not in the user manual.... //This line causes ERROR: 1: Aborting with error -1006...
	//Aha! The enum is StreamBufferHandlingMode_OldestFirst=0, but the function setEnumeratedProperty("Option", "Selection"); Just appends them to Option_Selection which corresponds to an ENUM. :)

	//Test
	//printf("Test of stream buffering \n");
	//setEnumeratedPropertyPrimaryCamera("StreamBufferHandlingMode", "OldestFirst");
	//setEnumeratedPropertySecondaryCamera("StreamBufferHandlingMode", "OldestFirst");
	//Nope! Also didn't work. Just skip it. Maybe clashes with another setting for external triggering.

	// Set auto white balance. Added this!
	//First need to set the starting white balance to the same for each camera. (Balance relative to green).
	setEnumeratedProperty("BalanceWhiteAuto", "Off");
	setEnumeratedProperty("BalanceRatioSelector", "Red");
	setFloatProperty("BalanceRatio", (double)(0.54));
	setEnumeratedProperty("BalanceRatioSelector", "Blue");
	setFloatProperty("BalanceRatio", (double)(1.66));
	printf("Setting Auto White Balance to ");
	switch (config.balanceWhiteAuto)
	{
	case AWB_OFF:
		printf("OFF\n");
		setEnumeratedProperty("BalanceWhiteAuto", "Off");
		setEnumeratedProperty("BalanceRatioSelector", "Red");
		setFloatProperty("BalanceRatio", (((double) config.manual_wb_rg)/1000));
		setEnumeratedProperty("BalanceRatioSelector", "Blue");
		setFloatProperty("BalanceRatio", (((double) config.manual_wb_bg)/1000));
		break;
	case AWB_ONCE:
		printf("ONCE\n");
		setEnumeratedProperty("BalanceWhiteAuto", "Once");
		setEnumeratedProperty("BalanceWhiteAutoProfile", "Outdoor");
		setFloatProperty("BalanceWhiteAutoDamping", (double)(0.01));
		break;
	case AWB_CONTINUOUS:
		printf("CONTINUOUS\n");
		setEnumeratedProperty("BalanceWhiteAuto", "Continuous");
		setEnumeratedProperty("BalanceWhiteAutoProfile", "Outdoor");
		setFloatProperty("BalanceWhiteAutoDamping", (double)(0.01));
		break;
	default:
		break;
	}
	
	// Set auto grey value control
	printf("Setting AutoExposureTargetGreyValueAuto to ");
	switch (config.auto_GV_on)
	{
	case AGV_OFF:
		printf("off\n");
		setEnumeratedProperty("AutoExposureTargetGreyValueAuto", "Off");
		break;
	case AGV_ON:
		printf("continuous with target value of %f\n",(double)config.target_GV);
		setEnumeratedProperty("AutoExposureTargetGreyValueAuto", "Continuous");
		setFloatProperty("AutoExposureTargetGreyValue",(double)config.target_GV);
		break;
	default:
		break;
	}

	// Set gamma correction (i.e. for non-linear intensity response) //Added this
	printf("Setting gamma_correction_on to ");
	switch (config.gamma_correction_on)
	{
	case GC_OFF:
		printf("off\n");
		setBoolProperty("GammaEnable", False);
		break;
	case GC_ON:
		printf("on with value of %f\n", ((double)config.gamma_value)/10000);
		setBoolProperty("GammaEnable", True);
		setFloatProperty("Gamma", ((double)config.gamma_value) / 10000);//Recommended value for sRGB (standard RGB)
		break;
	default:
		break;
	}
}

spinError initPrimaryCameraGPIO(void)
{
	/* Primary camera */

	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "LineSelector", &hLineSelector);
	err = spinEnumerationSetIntValue(hLineSelector, LineSelector_Line0);
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "LineMode", &hLineMode);
	err = spinEnumerationSetIntValue(hLineMode, LineMode_Input);

	return SPINNAKER_ERR_SUCCESS;
}

spinError initSecondaryCameraGPIO(void)
{
	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, "LineSelector", &hLineSelector);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Line Selector fail. Aborting with error %d...\n\n", err);
		return err;
	}

	if (!IsAvailableAndWritable(hLineSelector, "LineSelector"))
	{
		PrintRetrieveNodeFailure("node", "LineSelector");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	err = spinEnumerationSetIntValue(hLineSelector, LineSelector_Line3);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to write Line Selector value. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, "LineMode", &hLineMode);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Line Selector fail. Aborting with error %d...\n\n", err);
		return err;
	}

	if (!IsAvailableAndWritable(hLineMode, "LineMode"))
	{
		PrintRetrieveNodeFailure("node", "LineMode");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	err = spinEnumerationSetIntValue(hLineMode, LineMode_Input);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to write Line Mode value. Aborting with error %d...\n\n", err);
		return err;
	}

	return SPINNAKER_ERR_SUCCESS;
}

spinError initPrimaryCameraTrigger(void)
{
	// Set software trigger on primary camera

   setEnumeratedPropertyPrimaryCamera("TriggerMode", "Off");
   setEnumeratedPropertyPrimaryCamera("TriggerSelector", "FrameStart");
   setEnumeratedPropertyPrimaryCamera("TriggerSource", "Line0");
   setEnumeratedPropertyPrimaryCamera("TriggerActivation", "FallingEdge");
   setEnumeratedPropertyPrimaryCamera("TriggerOverlap", "ReadOut");
   setEnumeratedPropertyPrimaryCamera("TriggerMode", "On");

   printf("Primary camera set to Line 0, Falling Edge\n");

	return SPINNAKER_ERR_SUCCESS;
}

spinError initSecondaryCameraTrigger(void)
{
	setEnumeratedPropertySecondaryCamera("TriggerMode", "Off");
	setEnumeratedPropertySecondaryCamera("TriggerSelector", "FrameStart");
	setEnumeratedPropertySecondaryCamera("TriggerSource", "Line3");
	setEnumeratedPropertySecondaryCamera("TriggerActivation", "FallingEdge");
	setEnumeratedPropertySecondaryCamera("TriggerOverlap", "ReadOut");
	setEnumeratedPropertySecondaryCamera("TriggerMode", "On");

	//printf("Secondary camera set to hardware trigger on Line 3\n");//Error??
	printf("Secondary camera set to Line 3, Falling Edge\n");
	return SPINNAKER_ERR_SUCCESS;
}

void initAcquisitionMode(void)
{
	initAcquisitionContinuous(PRIMARY_CAMERA);
	initAcquisitionContinuous(SECONDARY_CAMERA);
	//initAcquisitionSingleFrame(PRIMARY_CAMERA);
	//initAcquisitionSingleFrame(SECONDARY_CAMERA);

	setBoolProperty("AcquisitionFrameRateEnable", 0);
	//setBoolPropertyPrimaryCamera("AcquisitionFrameRateEnable", 1);
	//setFloatPropertyPrimaryCamera("AcquisitionFrameRate", config.captureFrequency);
}

spinError initAcquisitionContinuous(bool8_t camera)
{
	spinNodeHandle hAcquisitionMode = NULL;
	spinNodeHandle hAcquisitionModeContinuous = NULL;
	int64_t acquisitionModeContinuous = 0;

	// Retrieve enumeration node from nodemap
	if(camera==PRIMARY_CAMERA) err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "AcquisitionMode", &hAcquisitionMode);
	else  err = spinNodeMapGetNode(hSecondaryCameraNodeMap, "AcquisitionMode", &hAcquisitionMode);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to set acquisition mode to continuous (node retrieval). Aborting with error %d...\n\n", err);
		return err;
	}

	// Retrieve entry node from enumeration node
	if (IsAvailableAndReadable(hAcquisitionMode, "AcquisitionMode"))
	{
		err = spinEnumerationGetEntryByName(hAcquisitionMode, "Continuous", &hAcquisitionModeContinuous);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to set acquisition mode to continuous (entry 'continuous' retrieval). Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("entry", "AcquisitionMode");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	// Retrieve integer from entry node

	if (IsAvailableAndReadable(hAcquisitionModeContinuous, "AcquisitionModeContinuous"))
	{
		err = spinEnumerationEntryGetIntValue(hAcquisitionModeContinuous, &acquisitionModeContinuous);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to set acquisition mode to continuous (entry int value retrieval). Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("entry", "AcquisitionMode 'Continuous'");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}
	// Set integer as new value of enumeration node
	if (IsAvailableAndWritable(hAcquisitionMode, "AcquisitionMode"))
	{
		err = spinEnumerationSetIntValue(hAcquisitionMode, acquisitionModeContinuous);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to set acquisition mode to continuous (entry int value setting). Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("entry", "AcquisitionMode");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	printf("Acquisition mode set to continuous...\n");
	
	return SPINNAKER_ERR_SUCCESS;
}
spinError initAcquisitionSingleFrame(bool8_t camera)
{
	spinNodeHandle hAcquisitionMode = NULL;
	spinNodeHandle hAcquisitionModeSingleFrame = NULL;
	int64_t acquisitionModeSingleFrame = 1;

	// Retrieve enumeration node from nodemap
	if(camera==PRIMARY_CAMERA) err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "AcquisitionMode", &hAcquisitionMode);
	else err = spinNodeMapGetNode(hSecondaryCameraNodeMap, "AcquisitionMode", &hAcquisitionMode);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to set acquisition mode to single frame (node retrieval). Aborting with error %d...\n\n", err);
		return err;
	}

	// Retrieve entry node from enumeration node
	if (IsAvailableAndReadable(hAcquisitionMode, "AcquisitionMode"))
	{
		err = spinEnumerationGetEntryByName(hAcquisitionMode, "SingleFrame", &hAcquisitionModeSingleFrame);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to set acquisition mode to single frame (entry 'SingleFrame' retrieval). Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("entry", "AcquisitionMode");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	// Retrieve integer from entry node

	if (IsAvailableAndReadable(hAcquisitionModeSingleFrame, "AcquisitionModeSingleFrame"))
	{
		err = spinEnumerationEntryGetIntValue(hAcquisitionModeSingleFrame, &acquisitionModeSingleFrame);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to set acquisition mode to continuous (entry int value retrieval). Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("entry", "AcquisitionMode 'SingleFrame'");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}
	// Set integer as new value of enumeration node
	if (IsAvailableAndWritable(hAcquisitionMode, "AcquisitionMode"))
	{
		err = spinEnumerationSetIntValue(hAcquisitionMode, acquisitionModeSingleFrame);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to set acquisition mode to single frame (entry int value setting). Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("entry", "AcquisitionMode");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	if(camera==PRIMARY_CAMERA) printf("Primary camera acquisition mode set to Single Frame...\n");
	else printf("Secondary camera acquisition mode set to Single Frame...\n");

	return SPINNAKER_ERR_SUCCESS;
}

spinError enableChunkData(spinNodeMapHandle hNodeMap)//Changed return type from void to spinError
{
	unsigned int i = 0;

	printf("\n\n*** CONFIGURING CHUNK DATA ***\n\n");

	//
	// Activate chunk mode
	//
	// *** NOTES ***
	// Once enabled, chunk data will be available at the end of hte payload of
	// every image captured until it is disabled. Chunk data can also be
	// retrieved from the nodemap.
	//
	spinNodeHandle hChunkModeActive = NULL;

	err = spinNodeMapGetNode(hNodeMap, "ChunkModeActive", &hChunkModeActive);

	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to activate chunk mode. Aborting with error %d...\n\n", err);
		return err;
	}

	//check if available and writable
	if (IsAvailableAndWritable(hChunkModeActive, "ChunkModeActive"))
	{
		err = spinBooleanSetValue(hChunkModeActive, True);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to activate chunk mode. Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("node", "ChunkModeActive");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	printf("Chunk mode activated...\n");

	//
	// Enable all types of chunk data
	//
	// *** NOTES ***
	// Enabling chunk data requires working with nodes: "ChunkSelector" is an
	// enumeration selector node and "ChunkEnable" is a boolean. It requires
	// retrieving the selector node (which is of enumeration node type),
	// selecting the entry of the chunk data to be enabled, retrieving the
	// corresponding boolean, and setting it to true.
	//
	// In this example, all chunk data is enabled, so these steps are performed
	// in a loop. Once this is complete, chunk mode still needs to be activated.
	//
	spinNodeHandle hChunkSelector = NULL;
	size_t numEntries = 0;

	// Retrieve selector node, check if available and readable and writable
	err = spinNodeMapGetNode(hNodeMap, "ChunkSelector", &hChunkSelector);

	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve chunk selector entries. Aborting with error %d...\n\n", err);
		return err;
	}

	// Retrieve number of entries
	if (IsAvailableAndReadable(hChunkSelector, "ChunkSelector"))
	{
		err = spinEnumerationGetNumEntries(hChunkSelector, &numEntries);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to retrieve number of entries. Aborting with error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("node", "ChunkSelector");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	printf("Enabling entries...\n");


	for (i = 0; i < numEntries; i++)
	{
		spinNodeHandle hEntry = NULL;

		err = spinEnumerationGetEntryByIndex(hChunkSelector, i, &hEntry);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("\tUnable to enable chunk entry (error %d)...\n\n", err);
			continue;
		}

		// Check if available and readable, retrieve entry name
		char entryName[MAX_BUFF_LEN];
		size_t lenEntryName = MAX_BUFF_LEN;

		if (IsAvailableAndReadable(hEntry, "ChunkEntry"))
		{
			err = spinNodeGetDisplayName(hEntry, entryName, &lenEntryName);
			if (err != SPINNAKER_ERR_SUCCESS)
			{
				printf("\t%s: unable to retrieve chunk entry display name (error %d)...\n", entryName, err);
				strcpy(entryName, "Unknown");
			}
		}
		else
		{
			PrintRetrieveNodeFailure("entry", "ChunkEntry");
			strcpy(entryName, "Unknown");
			continue;
		}
		// Retrieve enum entry integer value
		int64_t value = 0;

		err = spinEnumerationEntryGetIntValue(hEntry, &value);

		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("\t%s: unable to get chunk entry value (error %d)...\n", entryName, err);
			continue;
		}

		// Set integer value
		if (IsAvailableAndWritable(hChunkSelector, "ChunkSelector"))
		{
			err = spinEnumerationSetIntValue(hChunkSelector, value);
			if (err != SPINNAKER_ERR_SUCCESS)
			{
				printf("\t%s: unable to set chunk entry value (error %d)...\n", entryName, err);
				continue;
			}
		}
		else
		{
			PrintRetrieveNodeFailure("node", "ChunkSelector");
			return SPINNAKER_ERR_ACCESS_DENIED;
		}

		// Retrieve corresponding chunk enable node
		spinNodeHandle hChunkEnable = NULL;

		err = spinNodeMapGetNode(hNodeMap, "ChunkEnable", &hChunkEnable);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("\t%s: unable to get entry from nodemap (error %d)...\n", entryName, err);
			continue;
		}

		// Retrieve chunk enable value and set to true if necessary
		bool8_t isEnabled = False;
		//printf("Test of loop where warnings occuring %i", i);
		if (IsAvailableAndWritable(hChunkEnable, "ChunkEnable"))
		{
			err = spinBooleanGetValue(hChunkEnable, &isEnabled);
			if (err != SPINNAKER_ERR_SUCCESS)
			{
				printf("\t%s: unable to get chunk entry boolean value (error %d)...\n", entryName, err);
				continue;
			}
		}
		else
		{
			//Throwing warnings for nodes 0 and 1 since Image and Image CRC are enabled by default and probably not writable
			if (i > 1)
			{
				PrintRetrieveNodeFailure("node", "ChunkEnable");
			}
			continue;
		}
		// Consider the case in which chunk data is enabled but not writable
		if (!isEnabled)
		{
			// Set chunk enable value to true

			err = spinBooleanSetValue(hChunkEnable, True);
			if (err != SPINNAKER_ERR_SUCCESS)
			{
				printf("\t%s: unable to set chunk entry boolean value (error %d)...\n", entryName, err);
				continue;
			}

		}
		/*
		Andrews code that was throwing warning: Unable to get node (ChunkEnable node retrieval failed).
		Only occured for i=0 and i=1. What chunk data is this?

		Chunk data:
		Image - enabled by default and cannot be disabled.
		Image CRC - enabled by default and cannot be disabled.
		FrameID
		OffsetX
		OffsetY
		Width
		Height
		Exposure Time
		Gain
		Black Level
		Pixel Format
		ImageTimestamp
		Sequencer Set Active

		Yes, is probably because the first two are not IsAvailableAndWritable(hChunkEnable, "ChunkEnable");
		Will just prevent output message for i=0 or i=1
		if (IsAvailableAndWritable(hChunkEnable, "ChunkEnable"))
		{
			err = spinBooleanGetValue(hChunkEnable, &isEnabled);
			if (err != SPINNAKER_ERR_SUCCESS)
			{
				printf("\t%s: unable to get chunk entry boolean value (error %d)...\n", entryName, err);
				continue;
			}
		}
		else
		{
			PrintRetrieveNodeFailure("node", "ChunkEnable");
			continue;
		}
		// Consider the case in which chunk data is enabled but not writable
		if (!isEnabled)
		{
			// Set chunk enable value to true

			err = spinBooleanSetValue(hChunkEnable, True);
			if (err != SPINNAKER_ERR_SUCCESS)
			{
				printf("\t%s: unable to set chunk entry boolean value (error %d)...\n", entryName, err);
				continue;
			}

		}
		*/

		printf("\t%s: enabled\n", entryName);
	}
	return SPINNAKER_ERR_SUCCESS;
}

spinError saveSingleImage(bool8_t camera)
{

	if(camera==PRIMARY_CAMERA) err = spinCameraGetNextImage(hPrimaryCamera, &hResultImage);
	else err = spinCameraGetNextImage(hSecondaryCamera, &hResultImage);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to get image. Non-fatal error %d...\n\n", err);
	}

	err = spinImageIsIncomplete(hResultImage, &isIncomplete);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to determine image completion. Non-fatal error %d...\n\n", err);
		hasFailed = True;
	}

	// Check image for completion
	if (isIncomplete)
	{
		spinImageStatus imageStatus = IMAGE_NO_ERROR;

		err = spinImageGetStatus(hResultImage, &imageStatus);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to retrieve image status. Non-fatal error %d...\n\n", imageStatus);
		}
		else
		{
			printf("Image incomplete with image status %d...\n", imageStatus);
		}

		hasFailed = True;
	}

	// Release incomplete or failed image
	if (hasFailed)
	{
		err = spinImageRelease(hResultImage);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to release image. Non-fatal error %d...\n\n", err);
		}
	}

	double exposureTime = 0.0;
	int64_t currentTimestamp = 0, timeStamp = 0, frameId;

	err = spinImageChunkDataGetFloatValue(hResultImage, "ChunkExposureTime", &exposureTime);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve exposure time from image chunk data. Aborting with error %d...", err);
		return err;
	}

	err = spinImageChunkDataGetIntValue(hResultImage, "ChunkTimestamp", &currentTimestamp);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve timestamp from image chunk data. Aborting with error %d...", err);
		return err;
	}

	err = spinImageChunkDataGetIntValue(hResultImage, "ChunkFrameID", &frameId);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve frame ID from image chunk data. Aborting with error %d...", err);
		return err;
	}

	/*	
	//Andrew's junk that was commented out
	if (camera == PRIMARY_CAMERA)
	{
		timeStamp = currentTimestamp - oldPrimaryTimestamp;
		oldPrimaryTimestamp = currentTimestamp;
	}
	else
	{
		timeStamp = currentTimestamp - oldSecondaryTimestamp;
		oldSecondaryTimestamp = currentTimestamp;
	}

	timeStamp = (int64_t)(timeStamp / 10000000.0);

	char errStr[10];
	if (timeStamp != 7) strcpy(errStr,"Error"); else strcpy(errStr, "Ok");
	//End of Andrew's junk
	*/
	if (config.imageType==2)
	{
		if (camera == PRIMARY_CAMERA) sprintf(filename, "%sDrone-Flow-%I64d-PRIMARY-%I64d-%d", config.imagePath, pairCount, currentTimestamp, (int)exposureTime);
		else sprintf(filename, "%sDrone-Flow-%I64d-SECONDARY-%I64d-%d", config.imagePath, pairCount, currentTimestamp, (int)exposureTime);
		err = spinImageSave(hResultImage, filename, PNG);
	}
	else if (config.imageType == 1)
	{
		if (camera == PRIMARY_CAMERA) sprintf(filename, "%sDrone-Flow-%I64d-PRIMARY-%I64d-%d", config.imagePath, pairCount, currentTimestamp, (int)exposureTime);
		else sprintf(filename, "%sDrone-Flow-%I64d-SECONDARY-%I64d-%d", config.imagePath, pairCount, currentTimestamp, (int)exposureTime);
		err = spinImageSave(hResultImage, filename, JPEG);
	}
	else
	{
		if (camera == PRIMARY_CAMERA) sprintf(filename, "%sDrone-Flow-%I64d-PRIMARY-%I64d-%d", config.imagePath, frameId, currentTimestamp, (int)exposureTime);
		else sprintf(filename, "%sDrone-Flow-%I64d-SECONDARY-%I64d-%d", config.imagePath, frameId, currentTimestamp, (int)exposureTime);
		err = spinImageSave(hResultImage, filename, RAW);
	}
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to save image. Non-fatal error %d...\n\n", err);
	}
	else
	{
		if (config.imageType == 2) printf("Image saved at %s%s \n\n", filename,".png");
		else if (config.imageType == 1) printf("Image saved at %s%s \n\n", filename, ".jpg");
		else printf("Image saved at %s%s \n\n", filename, ".raw");
	}

	err = spinImageRelease(hResultImage);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to release image. Non-fatal error %d...\n\n", err);
	}

	return err;
}

void waitForExternalEnable(void)
{
	printf("\nWaiting for external enable...\n");
	while (!isExternalEnableAsserted());
	printf("\nExternal enable received...\n");
	err = spinCameraBeginAcquisition(hPrimaryCamera);
	err = spinCameraBeginAcquisition(hSecondaryCamera);
//	triggerPrimaryCamera();
}

void captureWhileExternalEnableAsserted(void)
{
	do
	{
		saveSingleImage(PRIMARY_CAMERA);
		saveSingleImage(SECONDARY_CAMERA);
		pairCount++;
//		triggerPrimaryCamera();
//		triggerSecondaryCamera();

	} while (isExternalEnableAsserted());

	err = spinCameraEndAcquisition(hPrimaryCamera);
	err = spinCameraEndAcquisition(hSecondaryCamera);
}

void captureNoExternalEnable(void)
{

	err = spinCameraBeginAcquisition(hPrimaryCamera);
	err = spinCameraBeginAcquisition(hSecondaryCamera);
	while (1)
	{
		saveSingleImage(PRIMARY_CAMERA);
		saveSingleImage(SECONDARY_CAMERA);
		pairCount++;
		//Error: Incrementing pairCount was missing from captureNoExternalEnable(). Now fixed and working well.
	}
}

bool8_t isExternalEnableAsserted(void)//Why is this bool8_t? What is a bool8_t?
{
	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "LineSelector", &hLineSelector);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Line Selector fail. Aborting with error %d...\n\n", err);
		return (bool8_t) err;//Added (bool8_t) for explicit data type conversion.
	}

	if (!IsAvailableAndWritable(hLineSelector, "LineSelector"))
	{
		PrintRetrieveNodeFailure("node", "LineSelector");
		return (bool8_t) SPINNAKER_ERR_ACCESS_DENIED;//Added (bool8_t) for explicit data type conversion.
	}

	err = spinEnumerationSetIntValue(hLineSelector, LineSelector_Line3);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to write Line Selector value. Aborting with error %d...\n\n", err);
	}

	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "LineStatus", &hLineStatus);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Line 3 Status fail. Aborting with error %d...\n\n", err);
	}

	if (!IsAvailableAndReadable(hLineStatus, "LineStatus"))
	{
		PrintRetrieveNodeFailure("node", "LineStatus");
	}

	bool8_t line0Value = 0;

	err = spinBooleanGetValue(hLineStatus, &line0Value);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Line 0 Status Read fail. Aborting with error %d...\n\n", err);
	}
	
	return(line0Value);
}

spinError triggerPrimaryCamera(void)
{
	spinNodeHandle hAcquisitionStart = NULL;

	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "AcquisitionStart", &hAcquisitionStart);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to execute Primary AcquisitionStart. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinCommandExecute(hAcquisitionStart);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to execute Primary AcquisitionStart. Aborting with error %d...\n\n", err);
		return err;
	}

	return err;
}

spinError triggerSecondaryCamera(void)
{
	spinNodeHandle hAcquisitionStart = NULL;

	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, "AcquisitionStart", &hAcquisitionStart);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to execute Secondary AcquisitionStart. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinCommandExecute(hAcquisitionStart);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to execute Secondary AcquisitionStart. Aborting with error %d...\n\n", err);
		return err;
	}

	return err;
}

spinError resetCameras(void)
{
	spinNodeHandle hDeviceReset = NULL;

	err = spinNodeMapGetNode(hPrimaryCameraNodeMap, "DeviceReset", &hDeviceReset);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("1: Unable to execute Primary Reset. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinCommandExecute(hDeviceReset);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("2: Unable to execute Primary Reset. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinNodeMapGetNode(hSecondaryCameraNodeMap, "DeviceReset", &hDeviceReset);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("1: Unable to execute Secondary Reset. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinCommandExecute(hDeviceReset);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("2: Unable to execute Secondary Reset. Aborting with error %d...\n\n", err);
		return err;
	}

	return err;

}