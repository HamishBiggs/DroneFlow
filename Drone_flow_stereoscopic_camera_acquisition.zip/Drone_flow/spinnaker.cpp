#include "Drone_flow.h"

extern spinCamera hPrimaryCamera, hSecondaryCamera;
extern spinCameraList hCameraList;

spinError errReturn = SPINNAKER_ERR_SUCCESS;
spinError err = SPINNAKER_ERR_SUCCESS;
spinSystem hSystem = NULL;

spinError spinInit(void)
{
	// Print application build information
	printf("Application build date: %s %s \n\n", __DATE__, __TIME__);

	// Retrieve singleton reference to system object

	err = spinSystemGetInstance(&hSystem);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve system instance. Aborting with error %d...\n\n", err);
		return err;
	}

	// Print out current library version
	spinLibraryVersion hLibraryVersion;

	spinSystemGetLibraryVersion(hSystem, &hLibraryVersion);
	printf("Spinnaker library version: %d.%d.%d.%d\n\n",
		hLibraryVersion.major,
		hLibraryVersion.minor,
		hLibraryVersion.type,
		hLibraryVersion.build);
	FILE *tempFile;
	tempFile = fopen("test.txt", "w+");
	if (tempFile == NULL)
	{
		printf("Failed to create file in current folder.  Please check "
			"permissions.\n");
		printf("Press Enter to exit...\n");
		getchar();
		return SPINNAKER_ERR_ACCESS_DENIED;
	}
	fclose(tempFile);
	remove("test.txt");

	return SPINNAKER_ERR_SUCCESS;
}

spinError spinClose(void)
{
	err = spinCameraRelease(hPrimaryCamera);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to release Primary camera. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinCameraRelease(hSecondaryCamera);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to release Secondary camera. Aborting with error %d...\n\n", err);
		return err;
	}

	// Clear and destroy camera list before releasing system
	err = spinCameraListClear(hCameraList);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to clear camera list. Aborting with error %d...\n\n", err);
		return err;
	}

	err = spinCameraListDestroy(hCameraList);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to destroy camera list. Aborting with error %d...\n\n", err);
		return err;
	}

	// Release system
	err = spinSystemReleaseInstance(hSystem);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to release system instance. Aborting with error %d...\n\n", err);
		return err;
	}

	printf("\nDone! Press Enter to exit...\n");
	getchar();

	return SPINNAKER_ERR_SUCCESS;
}

// This function helps to check if a node is available and readable
bool8_t IsAvailableAndReadable(spinNodeHandle hNode, char nodeName[])
{
	bool8_t pbAvailable = False;
	spinError err = SPINNAKER_ERR_SUCCESS;
	err = spinNodeIsAvailable(hNode, &pbAvailable);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve node availability (%s node), with error %d...\n\n", nodeName, err);
	}

	bool8_t pbReadable = False;
	err = spinNodeIsReadable(hNode, &pbReadable);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve node readability (%s node), with error %d...\n\n", nodeName, err);
	}
	return pbReadable && pbAvailable;
}

// This function helps to check if a node is available and writable
bool8_t IsAvailableAndWritable(spinNodeHandle hNode, char nodeName[])
{
	bool8_t pbAvailable = False;
	spinError err = SPINNAKER_ERR_SUCCESS;
	err = spinNodeIsAvailable(hNode, &pbAvailable);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve node availability (%s node), with error %d...\n\n", nodeName, err);
	}

	bool8_t pbWritable = False;
	err = spinNodeIsWritable(hNode, &pbWritable);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve node writability (%s node), with error %d...\n\n", nodeName, err);
	}
	return pbWritable && pbAvailable;
}

// This function handles the error prints when a node or entry is unavailable or
// not readable/writable on the connected camera
void PrintRetrieveNodeFailure(char node[], char name[])
{
	printf("Unable to get %s (%s %s retrieval failed).\n\n", node, name, node);
}

// This function prints the device information of the camera from the transport
// layer; please see NodeMapInfo_C example for more in-depth comments on
// printing device information from the nodemap.
spinError PrintDeviceInfo(spinNodeMapHandle hNodeMap)
{
	spinError err = SPINNAKER_ERR_SUCCESS;
	unsigned int i = 0;

	printf("\n*** DEVICE INFORMATION ***\n\n");

	// Retrieve device information category node
	spinNodeHandle hDeviceInformation = NULL;

	err = spinNodeMapGetNode(hNodeMap, "DeviceInformation", &hDeviceInformation);
	if (err != SPINNAKER_ERR_SUCCESS)
	{
		printf("Unable to retrieve node. Non-fatal error %d...\n\n", err);
		return err;
	}

	// Retrieve number of nodes within device information node
	size_t numFeatures = 0;

	if (IsAvailableAndReadable(hDeviceInformation, "DeviceInformation"))
	{
		err = spinCategoryGetNumFeatures(hDeviceInformation, &numFeatures);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to retrieve number of nodes. Non-fatal error %d...\n\n", err);
			return err;
		}
	}
	else
	{
		PrintRetrieveNodeFailure("node", "DeviceInformation");
		return SPINNAKER_ERR_ACCESS_DENIED;
	}

	// Iterate through nodes and print information
	for (i = 0; i < numFeatures; i++)
	{
		spinNodeHandle hFeatureNode = NULL;

		err = spinCategoryGetFeatureByIndex(hDeviceInformation, i, &hFeatureNode);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			printf("Unable to retrieve node. Non-fatal error %d...\n\n", err);
			continue;
		}

		spinNodeType featureType = UnknownNode;

		//get feature node name
		char featureName[MAX_BUFF_LEN];
		size_t lenFeatureName = MAX_BUFF_LEN;
		err = spinNodeGetName(hFeatureNode, featureName, &lenFeatureName);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			strcpy(featureName, "Unknown name");
		}

		if (IsAvailableAndReadable(hFeatureNode, featureName))
		{
			err = spinNodeGetType(hFeatureNode, &featureType);
			if (err != SPINNAKER_ERR_SUCCESS)
			{
				printf("Unable to retrieve node type. Non-fatal error %d...\n\n", err);
				continue;
			}
		}
		else
		{
			printf("%s: Node not readable\n", featureName);
			continue;
		}

		char featureValue[MAX_BUFF_LEN];
		size_t lenFeatureValue = MAX_BUFF_LEN;

		err = spinNodeToString(hFeatureNode, featureValue, &lenFeatureValue);
		if (err != SPINNAKER_ERR_SUCCESS)
		{
			strcpy(featureValue, "Unknown value");
		}

		printf("%s: %s\n", featureName, featureValue);
	}
	printf("\n");

	return err;
}
