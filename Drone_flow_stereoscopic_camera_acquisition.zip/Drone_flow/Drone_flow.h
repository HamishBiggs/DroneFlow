#include "Windows.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "time.h"
#include "SpinnakerC.h"
#include "ini.h"
#include <timeapi.h>
#include <conio.h>

/*
//Original order of includes. Changed to try to prevent redefinition of EXTERN_C. Yeeep! Fixed the problem/warning. :)
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "SpinnakerC.h"
#include "ini.h"
#include "Windows.h"
#include "time.h"
#include <timeapi.h>
#include <conio.h>
*/
// This macro helps with C-strings.
#define MAX_BUFF_LEN 256

//Camera indices
#define PRIMARY_CAMERA 0
#define SECONDARY_CAMERA 1

//Auto Exposure
#define AE_OFF			0
#define AE_ONCE			1
#define AE_CONTINUOUS	2

//Auto Gain
#define AG_OFF			0
#define AG_ONCE			1
#define AG_CONTINUOUS	2

//Auto Exposure Lighting Mode
#define AELM_AUTO	0
#define AELM_FRONT	1
#define AELM_BACK	2
#define AELM_NORM	3

//Auto Exposure Metering Mode
#define AEMM_AVG		0
#define AEMM_SPOT		1
#define AEMM_PARTIAL	2
#define AEMM_CW			3
#define AEMM_HP			4

//Auto Exposure Control Priority
#define AECP_GAIN		0
#define AECP_ET			1

//Auto White Balance (ADDED THIS)
#define AWB_OFF			0
#define AWB_ONCE		1
#define AWB_CONTINUOUS	2

//Auto Grey Value (ADDED this)
#define AGV_OFF			0
#define AGV_ON			1

//Gamma correction (ADDED this)
#define GC_OFF			0
#define GC_ON			1

// Compiler warning C4996 suppressed due to deprecated strcpy() and sprintf()
 // functions on Windows platform.
#if defined WIN32 || defined _WIN32 || defined WIN64 || defined _WIN64
#pragma warning(disable : 4996)
#endif

void readConfig(void);
spinError spinInit(void);
spinError spinClose(void);
spinError initCameras(void);
void processImageParameters(void);
void setEnumeratedProperty(char *nodeName, char *propertyValueLabel);
void setEnumeratedPropertyPrimaryCamera(char *nodeName, char *propertyValueLabel);
void setEnumeratedPropertySecondaryCamera(char *nodeName, char *propertyValueLabel);
void setFloatProperty(char *nodeName, double propertyValue);
void setFloatPropertyPrimaryCamera(char *nodeName, double propertyValue);
void setIntProperty(char *nodeName, int propertyValue);
void setBoolProperty(char *nodeName, bool8_t propertyValue);
void setBoolPropertyPrimaryCamera(char *nodeName, bool8_t propertyValue);
spinError initPrimaryCameraGPIO(void);
spinError initPrimaryCameraTrigger(void);
spinError triggerPrimaryCamera(void);
spinError triggerSecondaryCamera(void);
spinError initSecondaryCameraGPIO(void);
spinError initSecondaryCameraTrigger(void);
spinError initAcquisitionSingleFrame(bool8_t camera);
spinError initAcquisitionContinuous(bool8_t camera);
spinError resetCameras(void);
spinError enableChunkData(spinNodeMapHandle hNodeMap);//Changed from void
void waitForExternalEnable(void);
void captureWhileExternalEnableAsserted(void);
void captureNoExternalEnable(void);
bool8_t isExternalEnableAsserted(void);
spinError saveSingleImage(bool8_t camera);
bool8_t IsAvailableAndReadable(spinNodeHandle hNode, char nodeName[]);
bool8_t IsAvailableAndWritable(spinNodeHandle hNode, char nodeName[]);
void PrintRetrieveNodeFailure(char node[], char name[]);
int64_t milliseconds_now(void);
void initTimer(void);
void initTriggerComms(void);
void setTriggerFrequency(void);
static int config_handler(void* user, const char* section, const char* name,const char* value);
extern int _mkdir(const char *dirname);//Added this line
void initAcquisitionMode(void);//Added this line

typedef struct
{
	const char *primaryCamera;		// s/n of Primary camera
	const char *secondaryCamera;	// s/n of Secondary camera
	//const char imagePath[255];	// Directory to save images
	const char *imagePath;			// Changed this!
	int imageType;					// Saved image format: 0 = RAW, 1 = JPEG, 2 = PNG
	int gainAuto;					// 0 = off, 1 = once, 2 = continuous
	//const char pixelFormat[20];		// Pixel format - see Blackfly S Technical Reference for details
	char *pixelFormat;		// Changed this!
	const char *captureFrequency;	// in Hz
	int exposureTime;				// in us, 0 = auto
	int xDecimation;				// Horizontal decimation window in pixels
	int yDecimation;				// Vertical decimation window in pixels
	int xRoi;						// Width of image ROI in pixels
	int yRoi;						// Height of image ROI in pixels
	int xOffset;					// Offset from X origin of ROI in pixels
	int yOffset;					// Offset from Y origin of ROI in pixels
	int exposureAuto;				// Set the automatic exposure mode, 0=off, 1=once, 2=continuous
	int autoExposureLightingMode;	// 0=auto detect, 1=backlight, 2=frontlight, 3=normal
	int autoExposureMeteringMode;	// 0=average, 1=spot, 2=partial, 3=CentreWeighted, 4=HistgramPeak
	int autoExposureTimeLowerLimit; // microseconds
	int autoExposureTimeUpperLimit; // microseconds
	int autoExposureControlPriority;	//  0=Gain, 1=ExposureTime
	const char *triggerPortName;
	int balanceWhiteAuto;			//ADDED THIS: Set the white balance mode. 0 = off, 1 = once, 2 = continuous //BalanceWhiteAutoProfile is set to Outdoor if used.
	int manual_wb_rg;				//ADDED THIS: is the white balance of red relative to green multiplied by 1000 for typing as an integer in config
	int manual_wb_bg;				//ADDED THIS: is the white balance of blue relative to green multiplied by 1000 for typing as an integer in config
	int auto_GV_on;					//ADDED THIS: 0=off, 1=continuous.   This needs to be on for the target_GV to apply
	int target_GV;					//ADDED THIS: set as a percentage. I.e. 40%. Is before gamma correction.
	int gamma_correction_on;		//ADDED THIS: 0=off, 1=on.
	int gamma_value;				//ADDED THIS: Gamma correction value: x 10000 for integer output. I.e. 0.4545x1000=4545 (where 0.4545 is recommended for sRGB).
} configuration;
