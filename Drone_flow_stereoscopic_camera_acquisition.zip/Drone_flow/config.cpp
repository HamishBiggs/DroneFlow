
#include "Drone_flow.h"

configuration config;

static int config_handler(void* user, const char* section, const char* name,
	const char* value)
{
	configuration *pconfig = (configuration*)user;

#define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
	if (MATCH("", "primary_camera")) 
	{
		pconfig->primaryCamera = strdup(value);
	}
	else if (MATCH("", "secondary_camera")) 
	{
		pconfig->secondaryCamera = strdup(value);
	}
	else if (MATCH("", "capture_frequency")) 
	{
		pconfig->captureFrequency = strdup(value);//Why is this a string not a number? To do with the external triggering?
	}
	else if (MATCH("", "exposure_time"))
	{
		pconfig->exposureTime = 0;
		pconfig->exposureTime = atoi(value);
	}
	else if (MATCH("", "gain_auto"))
	{
		pconfig->gainAuto = atoi(value);
	}
	else if (MATCH("", "x_decimation"))
	{
		pconfig->xDecimation = atoi(value);
	}
	else if (MATCH("", "y_decimation"))
	{
		pconfig->yDecimation = atoi(value);
	}
	else if (MATCH("", "x_roi"))
	{
		pconfig->xRoi = atoi(value);
	}
	else if (MATCH("", "y_roi"))
	{
		pconfig->yRoi = atoi(value);
	}
	else if (MATCH("", "x_offset"))
	{
		pconfig->xOffset = atoi(value);
	}
	else if (MATCH("", "y_offset"))
	{
		pconfig->yOffset = atoi(value);
	}
	else if (MATCH("", "image_path"))
	{
		//Create new folder with current system time in seconds since January 1, 1970
		char filePath[255];
		sprintf(filePath, "%s%lli\\", value, time(NULL));
		int dirMakeStatus = 0;
		dirMakeStatus = _mkdir(filePath);
		if (dirMakeStatus != 0)//Zero is success for _mkdir()
		{
			printf("Error in config_handler() couldn't create output directory %s \n", filePath);
		}
		else
		{
			printf("Output folder %s%s", filePath, " created.\n");
		}
		//strcpy(pconfig->imagePath, filePath);//Changed this!
		pconfig->imagePath = strdup(filePath);//Changed this!
	}
	else if (MATCH("", "image_type"))
	{
		pconfig->imageType = atoi(value);
	}
	else if (MATCH("", "pixel_format"))
	{
		//strcpy(pconfig->pixelFormat, value);//Changed this!
		pconfig->pixelFormat = strdup(value);//Changed this!
	}
	else if (MATCH("", "exposure_auto"))
	{
		pconfig->exposureAuto = atoi(value);
	}
	else if (MATCH("", "auto_elm"))
	{
		pconfig->autoExposureLightingMode = atoi(value);
	}
	else if (MATCH("", "auto_emm"))
	{
		pconfig->autoExposureMeteringMode = atoi(value);
	}
	else if (MATCH("", "auto_etll"))
	{
		pconfig->autoExposureTimeLowerLimit = atoi(value);
	}
	else if (MATCH("", "auto_etul"))
	{
		pconfig->autoExposureTimeUpperLimit = atoi(value);
	}
	else if (MATCH("", "auto_ecp"))
	{
		pconfig->autoExposureControlPriority = atoi(value);
	}
	else if (MATCH("", "trigger_port"))
	{
		pconfig->triggerPortName = strdup(value);
	}
	else if (MATCH("", "auto_wb"))//Added this
	{
		pconfig->balanceWhiteAuto = atoi(value);
	}
	else if (MATCH("", "manual_wb_rg"))//Added this
	{
	pconfig->manual_wb_rg = atoi(value);
	}
	else if (MATCH("", "manual_wb_bg"))//Added this
	{
	pconfig->manual_wb_bg = atoi(value);
	}
	else if (MATCH("", "auto_GV_on"))//Added this
	{
	pconfig->auto_GV_on = atoi(value);
	}
	else if (MATCH("", "target_GV"))//Added this
	{
	pconfig->target_GV = atoi(value);
	}
	else if (MATCH("", "gamma_correction_on"))//Added this
	{
	pconfig->gamma_correction_on = atoi(value);
	}
	else if (MATCH("", "gamma_value"))//Added this
	{
	pconfig->gamma_value = atoi(value);
	}
	else
	{
		return 0;  /* unknown section/name, error */
	}
	return 1;
}

void readConfig(void)
{
	if (ini_parse("config.txt", config_handler, &config) < 0) {
		printf("Failed to load configuration.\n");
		printf("Press Enter to exit...\n");
		getchar();
	}
	printf("Config loaded from 'config.txt': \n\tPrimary Camera\t\t%s\n\tSecondary Camera\t%s\n\tCapture Frequency\t%s Hz\n\n", config.primaryCamera, config.secondaryCamera, config.captureFrequency);
}